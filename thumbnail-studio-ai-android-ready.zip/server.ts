import 'dotenv/config';
import express, { type Request, type Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

const PORT = 3000;

function getRuntimeEnvKey(): string | null {
  const raw = process.env.GEMINI_API_KEY;
  if (!raw) return null;
  const trimmed = raw.trim();
  if (!trimmed || trimmed === 'MY_GEMINI_API_KEY') return null;
  return trimmed;
}

function getOptionalTextAi(): GoogleGenAI | null {
  const key = getRuntimeEnvKey();
  if (!key) return null;
  return new GoogleGenAI({
    apiKey: key,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function assertCsrfHeader(req: Request, res: Response): boolean {
  if (req.headers['x-requested-with'] !== 'ThumbnailPromptArchitectAI') {
    res.status(403).json({ error: 'Forbidden' });
    return false;
  }
  return true;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '4mb' }));

  // Check if optional runtime text model is available (NEVER required, NEVER blocks app)
  app.get('/api/architect/status', (_req: Request, res: Response) => {
    const hasRuntimeTextModel = Boolean(getRuntimeEnvKey());
    res.json({
      hasRuntimeTextModel,
      mode: hasRuntimeTextModel ? 'hybrid-optional-llm' : 'local-architect-only',
      imageGenerationInsideApp: false,
    });
  });

  // Optional Text-Only Art Director Analysis via gemini-4-hydrogen when runtime key exists
  app.post('/api/architect/analyze-idea', async (req: Request, res: Response) => {
    if (!assertCsrfHeader(req, res)) return;
    const ai = getOptionalTextAi();
    if (!ai) {
      res.json({ available: false });
      return;
    }

    const {
      videoTitle = '',
      ideaDescription = '',
      contentType = '',
      participantsDescription = '',
      coreMessage = '',
      styleSummary = '',
      lang = 'ar',
    } = req.body ?? {};

    if (!String(videoTitle).trim() && !String(ideaDescription).trim()) {
      res.status(400).json({ error: 'Video title or idea description is required.' });
      return;
    }

    const targetLang = lang === 'en' ? 'English' : 'Arabic';

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `You are an elite YouTube Thumbnail Art Director & Prompt Architect.
Analyze this YouTube video idea (which may be written in colloquial Arabic like Egyptian, Gulf, or Levantine, or English) and produce:
1) A sharp art-director breakdown in ${targetLang}.
2) 4 genuinely distinct, non-repetitive visual thumbnail concepts tailored specifically to this video.

Video Title: "${String(videoTitle).slice(0, 300)}"
Idea Explanation: "${String(ideaDescription).slice(0, 1000)}"
Content Type: "${String(contentType).slice(0, 120)}"
Participants: "${String(participantsDescription).slice(0, 300)}"
Core Message to Convey: "${String(coreMessage).slice(0, 400)}"
Selected Visual Inspiration Blend: "${String(styleSummary).slice(0, 400)}"

RULES:
- Never copy celebrity faces or copy designs verbatim; extract artistic principles (framing, lighting, facial intensity, contrast, clarity).
- Every user-facing field must be in ${targetLang}.
- Every "*TokensEn" field must be rich, specific English visual art-direction tokens ready to assemble into an image prompt.`,
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              mostExcitingElement: { type: Type.STRING },
              attentionMoment: { type: Type.STRING },
              targetEmotions: { type: Type.STRING },
              viewerQuestion: { type: Type.STRING },
              bestVisualAngle: { type: Type.STRING },
              detectedCategory: { type: Type.STRING },
              concepts: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    name: { type: Type.STRING },
                    sceneDescription: { type: Type.STRING },
                    peoplePose: { type: Type.STRING },
                    facialExpressions: { type: Type.STRING },
                    background: { type: Type.STRING },
                    extraElements: { type: Type.STRING },
                    colors: { type: Type.STRING },
                    lighting: { type: Type.STRING },
                    whyItFits: { type: Type.STRING },
                    inspiredBy: { type: Type.STRING },
                    sceneTokensEn: { type: Type.STRING },
                    poseTokensEn: { type: Type.STRING },
                    expressionTokensEn: { type: Type.STRING },
                    backgroundTokensEn: { type: Type.STRING },
                    colorTokensEn: { type: Type.STRING },
                    lightingTokensEn: { type: Type.STRING },
                    elementsTokensEn: { type: Type.STRING },
                  },
                  required: [
                    'id',
                    'name',
                    'sceneDescription',
                    'peoplePose',
                    'facialExpressions',
                    'background',
                    'extraElements',
                    'colors',
                    'lighting',
                    'whyItFits',
                    'inspiredBy',
                    'sceneTokensEn',
                    'poseTokensEn',
                    'expressionTokensEn',
                    'backgroundTokensEn',
                    'colorTokensEn',
                    'lightingTokensEn',
                    'elementsTokensEn',
                  ],
                },
              },
            },
            required: [
              'mostExcitingElement',
              'attentionMoment',
              'targetEmotions',
              'viewerQuestion',
              'bestVisualAngle',
              'detectedCategory',
              'concepts',
            ],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim());
      res.json({
        available: true,
        analysis: {
          mostExcitingElement: parsed.mostExcitingElement,
          attentionMoment: parsed.attentionMoment,
          targetEmotions: parsed.targetEmotions,
          viewerQuestion: parsed.viewerQuestion,
          bestVisualAngle: parsed.bestVisualAngle,
          detectedCategory: parsed.detectedCategory,
          analysisSource: 'gemini-text',
        },
        concepts: Array.isArray(parsed.concepts) ? parsed.concepts.slice(0, 5) : [],
      });
    } catch {
      res.json({ available: false });
    }
  });

  // Vite dev middleware or static production build
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      const indexPath = path.join(distDir, 'index.html');
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(404).send('Build not found');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Thumbnail Prompt Architect AI server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
