import React, { useMemo, useState } from 'react';
import {
  Check,
  Columns,
  Copy,
  Cpu,
  Edit3,
  Plus,
  Search,
  Sliders,
  Sparkles,
  Trash2,
} from 'lucide-react';
import { getAllGeneratorTools } from '../data/externalGenerators';
import { synthesizePromptForTool } from '../engine/generatorPromptEngines';
import { getT } from '../i18n/translations';
import type {
  AppSettings,
  ArchitectProject,
  ExternalGeneratorTool,
  GoogleFlowConfig,
  GoogleFlowMode,
  TargetGenerator,
} from '../types/architect';

interface ExternalGeneratorsPageProps {
  settings: AppSettings;
  activeProject: ArchitectProject | null;
  initialTab?: 'library' | 'flow' | 'compare' | 'custom';
  onUpdateSettings: (next: AppSettings) => void;
  onApplyToolToProject: (toolId: TargetGenerator, flowConfig?: GoogleFlowConfig) => void;
}

const SAMPLE_COMPARE_PROJECT: ArchitectProject = {
  id: 'compare-sample',
  name: 'Challenge Comparison Preview',
  createdAt: 0,
  updatedAt: 0,
  phase: 'result',
  wizardStepIndex: 7,
  selectedCreatorIds: ['ahmed-aburob'],
  selectedGeneralIds: ['versus'],
  ideaInputs: {
    videoTitle: 'Who Knows Each Other Better? Impossible Challenge',
    ideaDescription: 'Two best friends test how well they know each other with dramatic surprises.',
    contentType: 'Challenge',
    participantsDescription: 'Ahmed and Omar',
    coreMessage: 'Can friendship survive the ultimate test?',
  },
  concepts: [
    {
      id: 'concept-clash',
      name: 'Dramatic Split Showdown',
      sceneDescription: 'Split-frame showdown between two friends.',
      peoplePose: 'Two subjects angled on opposing sides.',
      facialExpressions: 'Shocked vs confident',
      background: 'Dual neon studio',
      extraElements: 'Question mark',
      colors: 'Blue vs crimson',
      lighting: 'Rim light',
      whyItFits: 'Instant tension',
      inspiredBy: 'Ahmed Aburob',
      sceneTokensEn:
        'dramatic split-composition YouTube thumbnail showdown between two friends answering a tough challenge',
      poseTokensEn: 'two foreground subjects framed on left and right thirds gesturing expressively',
      expressionTokensEn: 'one friend shocked wide-eyed while the second smirks confidently',
      backgroundTokensEn: 'dark YouTube studio split with electric blue and crimson rim glow',
      colorTokensEn: 'electric cobalt blue and vivid crimson contrast',
      lightingTokensEn: 'sculpted softbox key light and crisp opposing rim lights',
      elementsTokensEn: 'sleek glowing central question mark',
    },
  ],
  wizardAnswers: {
    selectedConceptId: 'concept-clash',
    expressionChoice: 'contrast-duo',
    poseChoice: 'side-by-side-duel',
    backgroundChoice: 'studio-dual-neon',
    colorChoice: 'electric-blue-crimson',
    textMode: 'suggest',
    thumbnailText: 'WHO WINS?!',
    elementsSelected: ['question-mark'],
    targetGenerator: 'google-flow',
    identityMode: 'max-priority',
  },
  referenceImages: [
    {
      id: 'sample-1',
      personGroupId: 'p1',
      personLabel: 'Ahmed',
      role: 'person',
      fileName: 'ahmed_front.jpg',
      dataUrl: '',
      mimeType: 'image/jpeg',
      isPrimary: true,
    },
    {
      id: 'sample-2',
      personGroupId: 'p2',
      personLabel: 'Omar',
      role: 'person',
      fileName: 'omar_front.jpg',
      dataUrl: '',
      mimeType: 'image/jpeg',
      isPrimary: true,
    },
  ],
  personProfiles: {
    p1: {
      groupId: 'p1',
      label: 'Ahmed',
      visibleTraits: 'short curly dark hair, light beard, warm olive skin',
      thumbnailRole: 'Left competitor reacting with shock',
    },
    p2: {
      groupId: 'p2',
      label: 'Omar',
      visibleTraits: 'neat dark hair, clean-shaven, dark jacket',
      thumbnailRole: 'Right competitor smirking confidently',
    },
  },
};

export const ExternalGeneratorsPage: React.FC<ExternalGeneratorsPageProps> = ({
  settings,
  activeProject,
  initialTab = 'library',
  onUpdateSettings,
  onApplyToolToProject,
}) => {
  const lang = settings.language;
  const t = getT(lang);
  const isAr = lang === 'ar';

  const [tab, setTab] = useState<'library' | 'flow' | 'compare' | 'custom'>(initialTab);
  const [catFilter, setCatFilter] = useState<'all' | 'google' | 'other' | 'custom'>('all');
  const [search, setSearch] = useState('');
  const [compareIds, setCompareIds] = useState<TargetGenerator[]>([
    'google-flow',
    'chatgpt',
    'midjourney',
  ]);
  const [compareSource, setCompareSource] = useState<'active' | 'sample'>(
    activeProject ? 'active' : 'sample'
  );
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Custom tool / edit form state
  const [editingToolId, setEditingToolId] = useState<string | null>(null);
  const [newToolName, setNewToolName] = useState('');
  const [newToolDesc, setNewToolDesc] = useState('');
  const [newToolRef, setNewToolRef] = useState('');
  const [newToolTemplate, setNewToolTemplate] = useState('');

  const tools = useMemo(() => getAllGeneratorTools(settings), [settings]);

  const filteredTools = useMemo(() => {
    const q = search.trim().toLowerCase();
    return tools.filter((tool) => {
      if (catFilter !== 'all' && tool.category !== catFilter) return false;
      if (!q) return true;
      return (
        tool.name.toLowerCase().includes(q) ||
        tool.shortDescAr.toLowerCase().includes(q) ||
        tool.shortDescEn.toLowerCase().includes(q) ||
        tool.usageTypeAr.toLowerCase().includes(q) ||
        tool.usageTypeEn.toLowerCase().includes(q)
      );
    });
  }, [tools, catFilter, search]);

  const flowConfig: GoogleFlowConfig =
    activeProject?.wizardAnswers.googleFlowConfig ?? settings.googleFlowDefaults;

  const updateFlowConfig = (patch: Partial<GoogleFlowConfig>) => {
    const nextCfg = { ...flowConfig, ...patch };
    onUpdateSettings({
      ...settings,
      googleFlowDefaults: nextCfg,
    });
    if (activeProject) {
      onApplyToolToProject(activeProject.wizardAnswers.targetGenerator, nextCfg);
    }
  };

  const toggleCompareTool = (id: TargetGenerator) => {
    setCompareIds((prev) => {
      if (prev.includes(id)) {
        return prev.length > 1 ? prev.filter((x) => x !== id) : prev;
      }
      if (prev.length >= 3) {
        return [...prev.slice(1), id];
      }
      return [...prev, id];
    });
  };

  const handleCopy = async (key: string, value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 1600);
    } catch {
      // ignore
    }
  };

  const handleSaveCustomTool = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newToolName.trim()) return;

    if (editingToolId) {
      const isBuiltIn = !settings.customTools.some((c) => c.id === editingToolId);
      if (isBuiltIn) {
        onUpdateSettings({
          ...settings,
          toolOverrides: {
            ...settings.toolOverrides,
            [editingToolId]: {
              name: newToolName.trim(),
              shortDescAr: newToolDesc.trim() || undefined,
              shortDescEn: newToolDesc.trim() || undefined,
              referenceHandlingAr: newToolRef.trim() || undefined,
              referenceHandlingEn: newToolRef.trim() || undefined,
              customTemplate: newToolTemplate.trim() || undefined,
            },
          },
        });
      } else {
        onUpdateSettings({
          ...settings,
          customTools: settings.customTools.map((c) =>
            c.id === editingToolId
              ? {
                  ...c,
                  name: newToolName.trim(),
                  shortDescAr: newToolDesc.trim() || c.shortDescAr,
                  shortDescEn: newToolDesc.trim() || c.shortDescEn,
                  referenceHandlingAr: newToolRef.trim() || c.referenceHandlingAr,
                  referenceHandlingEn: newToolRef.trim() || c.referenceHandlingEn,
                  customTemplate: newToolTemplate.trim() || undefined,
                }
              : c
          ),
        });
      }
    } else {
      const id = `custom-${Date.now()}`;
      const newTool: ExternalGeneratorTool = {
        id,
        category: 'custom',
        isCustom: true,
        name: newToolName.trim(),
        badgeText: newToolName.trim().slice(0, 3).toUpperCase(),
        shortDescAr: newToolDesc.trim() || 'أداة توليد صور خارجية مخصصة',
        shortDescEn: newToolDesc.trim() || 'Custom external AI image generator',
        usageTypeAr: 'توليد صور مخصص',
        usageTypeEn: 'Custom image generation',
        referenceHandlingAr:
          newToolRef.trim() || 'ارفع صور الأشخاص المرجعية بالترتيب في واجهة الأداة.',
        referenceHandlingEn:
          newToolRef.trim() || 'Upload numbered portrait references inside the tool UI.',
        promptStyleAr: 'توجيه مخصص قابل للتعديل عبر القالب',
        promptStyleEn: 'Custom prompt formatting template',
        identitySupportSummaryAr: 'يعتمد على قدرات الأداة المخصصة',
        identitySupportSummaryEn: 'Depends on the custom generator capabilities',
        supportsSeparateNegative: true,
        negativeHandlingAr: 'يدعم قائمة الاستبعاد المنفصلة عند توفرها',
        negativeHandlingEn: 'Includes separate exclusion terms if supported',
        recommendedSettingsAr: '16:9 Landscape | 1280×720',
        recommendedSettingsEn: '16:9 Landscape | 1280×720',
        customTemplate: newToolTemplate.trim() || undefined,
      };
      onUpdateSettings({
        ...settings,
        customTools: [...settings.customTools, newTool],
      });
    }

    setEditingToolId(null);
    setNewToolName('');
    setNewToolDesc('');
    setNewToolRef('');
    setNewToolTemplate('');
  };

  const startEditTool = (tool: ExternalGeneratorTool) => {
    setEditingToolId(tool.id);
    setNewToolName(tool.name);
    setNewToolDesc(isAr ? tool.shortDescAr : tool.shortDescEn);
    setNewToolRef(isAr ? tool.referenceHandlingAr : tool.referenceHandlingEn);
    setNewToolTemplate(tool.customTemplate ?? '');
    setTab('custom');
  };

  const deleteCustomTool = (id: string) => {
    onUpdateSettings({
      ...settings,
      customTools: settings.customTools.filter((c) => c.id !== id),
      defaultGenerator: settings.defaultGenerator === id ? 'google-flow' : settings.defaultGenerator,
    });
  };

  const comparisonBrief =
    compareSource === 'active' && activeProject ? activeProject : SAMPLE_COMPARE_PROJECT;

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20 lg:pb-8">
      <div className="space-y-1.5">
        <h1 className="text-2xl font-bold text-white">{t.generators.title}</h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-3xl leading-relaxed">
          {t.generators.subtitle}
        </p>
      </div>

      {/* Sub-navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-white/10 pb-3">
        {(
          [
            { id: 'library', label: t.generators.tabLibrary, icon: <Cpu className="w-3.5 h-3.5" /> },
            { id: 'flow', label: t.generators.tabFlowStudio, icon: <Sliders className="w-3.5 h-3.5" /> },
            { id: 'compare', label: t.generators.tabCompare, icon: <Columns className="w-3.5 h-3.5" /> },
            { id: 'custom', label: t.generators.tabCustom, icon: <Plus className="w-3.5 h-3.5" /> },
          ] as const
        ).map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setTab(item.id)}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
              tab === item.id
                ? 'bg-violet-600 text-white'
                : 'bg-[#11131B] text-slate-300 border border-white/10 hover:bg-white/6'
            }`}
          >
            {item.icon}
            <span>{item.label}</span>
          </button>
        ))}
      </div>

      {/* ===================== TAB 1: TOOLS LIBRARY ===================== */}
      {tab === 'library' && (
        <div className="space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              {(
                [
                  { id: 'all', label: t.generators.catAll },
                  { id: 'google', label: t.generators.catGoogle },
                  { id: 'other', label: t.generators.catOther },
                  { id: 'custom', label: t.generators.catCustom },
                ] as const
              ).map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setCatFilter(c.id)}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                    catFilter === c.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-[#11131B] text-slate-300 border border-white/10'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 start-3 pointer-events-none" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t.common.search}
                className="w-full ps-9 pe-3 py-2 rounded-xl bg-[#11131B] border border-white/10 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500"
              />
            </div>
          </div>

          {filteredTools.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400 bg-[#11131B] rounded-2xl border border-white/8">
              {t.common.noResults}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredTools.map((tool) => {
                const isDefault = settings.defaultGenerator === tool.id;
                const isGoogleFlow = tool.id === 'google-flow';
                return (
                  <div
                    key={tool.id}
                    className={`rounded-2xl p-5 border flex flex-col justify-between gap-4 ${
                      isGoogleFlow
                        ? 'bg-gradient-to-br from-[#16192B] to-[#11131B] border-violet-500/45'
                        : isDefault
                        ? 'bg-[#11131B] border-blue-500/45'
                        : 'bg-[#11131B] border-white/8'
                    }`}
                  >
                    <div className="space-y-3">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-10 h-10 rounded-xl flex items-center justify-center text-xs font-bold font-mono-nums shrink-0 ${
                              tool.category === 'google'
                                ? 'bg-violet-500/20 text-violet-200 border border-violet-500/35'
                                : 'bg-blue-500/15 text-blue-200 border border-blue-500/25'
                            }`}
                          >
                            {tool.badgeText}
                          </div>
                          <div>
                            <h3 className="text-base font-bold text-white">{tool.name}</h3>
                            <div className="text-[11px] text-slate-400">
                              {tool.category === 'google'
                                ? 'Google'
                                : tool.category === 'custom'
                                ? 'Custom'
                                : 'External AI'}
                              {tool.isFeatured ? ` · ${t.generators.featuredLabel}` : ''}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => startEditTool(tool)}
                            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/12 text-slate-300 cursor-pointer"
                            title={t.common.rename}
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          {tool.isCustom && (
                            <button
                              type="button"
                              onClick={() => deleteCustomTool(tool.id)}
                              className="p-1.5 rounded-lg bg-white/5 hover:bg-red-500/20 text-slate-400 hover:text-red-300 cursor-pointer"
                              title={t.common.delete}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>

                      <p className="text-xs text-slate-200 leading-relaxed">
                        {isAr ? tool.shortDescAr : tool.shortDescEn}
                      </p>

                      <div className="space-y-2 text-[11px] text-slate-300 pt-1">
                        <div>
                          <span className="text-violet-300 font-semibold">
                            {t.generators.usageTypeLabel}:{' '}
                          </span>
                          {isAr ? tool.usageTypeAr : tool.usageTypeEn}
                        </div>
                        <div>
                          <span className="text-blue-300 font-semibold">
                            {t.generators.refHandlingLabel}:{' '}
                          </span>
                          {isAr ? tool.referenceHandlingAr : tool.referenceHandlingEn}
                        </div>
                        <div>
                          <span className="text-indigo-300 font-semibold">
                            {t.generators.promptPropsLabel}:{' '}
                          </span>
                          {isAr ? tool.promptStyleAr : tool.promptStyleEn}
                        </div>
                        <div>
                          <span className="text-slate-200 font-semibold">
                            {t.generators.negativeSupportLabel}:{' '}
                          </span>
                          {isAr ? tool.negativeHandlingAr : tool.negativeHandlingEn}
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 pt-3 border-t border-white/8">
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateSettings({ ...settings, defaultGenerator: tool.id })
                        }
                        className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold cursor-pointer ${
                          isDefault
                            ? 'bg-emerald-600/20 border border-emerald-500/40 text-emerald-200'
                            : 'bg-white/6 hover:bg-white/12 text-white border border-white/10'
                        }`}
                      >
                        {isDefault ? t.generators.activeDefaultBadge : t.generators.useThisToolBtn}
                      </button>

                      {activeProject && (
                        <button
                          type="button"
                          onClick={() => onApplyToolToProject(tool.id)}
                          className="py-2 px-3 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold cursor-pointer"
                        >
                          {t.generators.applyToActiveProjectBtn}
                        </button>
                      )}

                      {isGoogleFlow && (
                        <button
                          type="button"
                          onClick={() => setTab('flow')}
                          className="py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold cursor-pointer"
                        >
                          {t.generators.tabFlowStudio}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ===================== TAB 2: GOOGLE FLOW STUDIO ===================== */}
      {tab === 'flow' && (
        <div className="rounded-2xl bg-[#11131B] border border-violet-500/35 p-5 sm:p-6 space-y-6">
          <div className="space-y-1">
            <h2 className="text-lg font-bold text-white">{t.generators.flow.title}</h2>
            <p className="text-xs text-slate-400">{t.generators.flow.modelHint}</p>
          </div>

          {/* Usage Mode */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-violet-300">
              {t.generators.flow.modeLabel}
            </label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {(
                [
                  { id: 'image', label: t.generators.flow.modeImage },
                  { id: 'agent', label: t.generators.flow.modeAgent },
                  { id: 'editing', label: t.generators.flow.modeEditing },
                ] as Array<{ id: GoogleFlowMode; label: string }>
              ).map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => updateFlowConfig({ mode: m.id })}
                  className={`p-3.5 rounded-xl border text-xs font-bold text-start cursor-pointer transition ${
                    flowConfig.mode === m.id
                      ? 'bg-violet-600/20 border-violet-500 text-white'
                      : 'bg-[#090A0F] border-white/10 text-slate-300 hover:border-white/25'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          {/* Model Choice inside Flow */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-blue-300 mb-1.5">
                {t.generators.flow.modelLabel}
              </label>
              <select
                value={flowConfig.modelChoice}
                onChange={(e) => updateFlowConfig({ modelChoice: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white focus:outline-none focus:border-violet-500"
              >
                {settings.flowModelsCatalog.map((m) => (
                  <option key={m} value={m}>
                    {m === 'auto-available'
                      ? isAr
                        ? 'عام متوافق (النموذج المتاح داخل Flow)'
                        : 'General Compatible (Available Flow Model)'
                      : m}
                  </option>
                ))}
                <option value="custom">
                  {isAr ? 'تحديد اسم نموذج آخر يدوياً...' : 'Specify custom Flow model...'}
                </option>
              </select>
            </div>

            {flowConfig.modelChoice === 'custom' && (
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  {t.generators.flow.customModelPlaceholder}
                </label>
                <input
                  type="text"
                  value={flowConfig.customModelName ?? ''}
                  onChange={(e) => updateFlowConfig({ customModelName: e.target.value })}
                  placeholder={t.generators.flow.customModelPlaceholder}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white focus:outline-none focus:border-violet-500"
                />
              </div>
            )}
          </div>

          {/* Flow Image Specs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {t.generators.flow.qualityLabel}
              </label>
              <select
                value={flowConfig.qualityLevel}
                onChange={(e) =>
                  updateFlowConfig({ qualityLevel: e.target.value as 'high' | 'ultra-crisp' })
                }
                className="w-full px-3 py-2 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white"
              >
                <option value="high">{isAr ? 'جودة عالية متوازنة' : 'High Quality'}</option>
                <option value="ultra-crisp">{isAr ? 'تفاصيل فائقة الحدّة' : 'Ultra-Crisp Detail'}</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {t.generators.flow.compositionLabel}
              </label>
              <select
                value={flowConfig.compositionFocus}
                onChange={(e) =>
                  updateFlowConfig({
                    compositionFocus: e.target.value as 'high-ctr' | 'balanced-story',
                  })
                }
                className="w-full px-3 py-2 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white"
              >
                <option value="high-ctr">{isAr ? 'وضوح نقر فائق (High CTR)' : 'High-CTR Clarity'}</option>
                <option value="balanced-story">{isAr ? 'سرد سينمائي متزن' : 'Balanced Story'}</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {t.generators.flow.textSpaceLabel}
              </label>
              <select
                value={flowConfig.textSpace}
                onChange={(e) =>
                  updateFlowConfig({
                    textSpace: e.target.value as 'none' | 'clean-negative-space',
                  })
                }
                className="w-full px-3 py-2 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white"
              >
                <option value="clean-negative-space">
                  {isAr ? 'ترك مساحة نظيفة للنص' : 'Clean Negative Space'}
                </option>
                <option value="none">{isAr ? 'بدون مساحة نص' : 'No Text Space'}</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {t.generators.flow.realismLabel}
              </label>
              <select
                value={flowConfig.realismLevel}
                onChange={(e) =>
                  updateFlowConfig({
                    realismLevel: e.target.value as
                      | 'photorealistic'
                      | 'natural-cinematic'
                      | 'stylized-ctr',
                  })
                }
                className="w-full px-3 py-2 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white"
              >
                <option value="photorealistic">{isAr ? 'فوتوغرافي واقعي 100%' : 'Photorealistic'}</option>
                <option value="natural-cinematic">{isAr ? 'سينمائي طبيعي' : 'Natural Cinematic'}</option>
                <option value="stylized-ctr">{isAr ? 'استوديو يوتيوب مشبع' : 'Bold YouTube Studio'}</option>
              </select>
            </div>
          </div>

          {activeProject && (
            <button
              type="button"
              onClick={() => onApplyToolToProject('google-flow', flowConfig)}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 text-white text-xs font-bold cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>{t.generators.applyToActiveProjectBtn} (Google Flow)</span>
            </button>
          )}
        </div>
      )}

      {/* ===================== TAB 3: TOOL COMPARISON ===================== */}
      {tab === 'compare' && (
        <div className="space-y-5">
          <div className="rounded-2xl bg-[#11131B] border border-white/8 p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-white">{t.generators.compare.title}</h2>
                <p className="text-xs text-slate-400 mt-0.5">{t.generators.compare.subtitle}</p>
              </div>
              {activeProject && (
                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-slate-400">
                    {t.generators.compare.previewSourceLabel}
                  </span>
                  <button
                    type="button"
                    onClick={() => setCompareSource('active')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                      compareSource === 'active'
                        ? 'bg-violet-600 text-white'
                        : 'bg-[#090A0F] text-slate-300 border border-white/10'
                    }`}
                  >
                    {t.generators.compare.activeProjectSource}
                  </button>
                  <button
                    type="button"
                    onClick={() => setCompareSource('sample')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                      compareSource === 'sample'
                        ? 'bg-violet-600 text-white'
                        : 'bg-[#090A0F] text-slate-300 border border-white/10'
                    }`}
                  >
                    {t.generators.compare.sampleSource}
                  </button>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <div className="text-xs font-semibold text-slate-300">
                {t.generators.compare.selectToolsHint}
              </div>
              <div className="flex flex-wrap gap-2">
                {tools.map((tool) => {
                  const active = compareIds.includes(tool.id);
                  return (
                    <button
                      key={tool.id}
                      type="button"
                      onClick={() => toggleCompareTool(tool.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer transition ${
                        active
                          ? 'bg-violet-600/25 border-violet-500 text-white'
                          : 'bg-[#090A0F] border-white/10 text-slate-400 hover:text-white'
                      }`}
                    >
                      {active ? <Check className="w-3 h-3 inline me-1" /> : null}
                      {tool.name}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {compareIds.map((toolId) => {
              const tool = tools.find((x) => x.id === toolId) ?? tools[0];
              const bundle = synthesizePromptForTool(comparisonBrief, tool.id, 0, lang, settings);
              return (
                <div
                  key={tool.id}
                  className="rounded-2xl bg-[#11131B] border border-white/10 p-4 flex flex-col justify-between gap-4"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-2 pb-2 border-b border-white/8">
                      <h3 className="text-sm font-bold text-white">{tool.name}</h3>
                      <span className="text-[11px] font-mono-nums text-violet-300">
                        {bundle.mainPrompt.length} chars
                      </span>
                    </div>

                    <div className="space-y-2 text-[11px]">
                      <div>
                        <span className="text-blue-300 font-semibold">
                          {t.generators.refHandlingLabel}:{' '}
                        </span>
                        <span className="text-slate-300">
                          {isAr ? tool.referenceHandlingAr : tool.referenceHandlingEn}
                        </span>
                      </div>
                      <div>
                        <span className="text-violet-300 font-semibold">
                          {t.generators.identitySupportLabel}:{' '}
                        </span>
                        <span className="text-slate-300">
                          {isAr ? tool.identitySupportSummaryAr : tool.identitySupportSummaryEn}
                        </span>
                      </div>
                      <div>
                        <span className="text-rose-300 font-semibold">
                          {t.generators.negativeSupportLabel}:{' '}
                        </span>
                        <span className="text-slate-300">
                          {isAr ? tool.negativeHandlingAr : tool.negativeHandlingEn}
                        </span>
                      </div>
                      <div>
                        <span className="text-emerald-300 font-semibold">Settings: </span>
                        <span className="text-slate-300">
                          {isAr ? bundle.recommendedSettingsAr : bundle.recommendedSettingsEn}
                        </span>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <div className="text-[11px] font-bold text-slate-200">
                        {t.generators.compare.promptLabel}
                      </div>
                      <pre
                        dir="ltr"
                        className="p-3 rounded-xl bg-[#090A0F] border border-white/8 text-[11px] text-slate-200 font-mono whitespace-pre-wrap max-h-64 overflow-y-auto leading-relaxed"
                      >
                        {bundle.mainPrompt}
                      </pre>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => void handleCopy(`cmp-${tool.id}`, bundle.mainPrompt)}
                    className="w-full py-2 px-3 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {copiedKey === `cmp-${tool.id}` ? (
                      <Check className="w-3.5 h-3.5" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span>
                      {copiedKey === `cmp-${tool.id}` ? t.common.copied : t.common.copy}
                    </span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ===================== TAB 4: ADD / EDIT CUSTOM TOOLS ===================== */}
      {tab === 'custom' && (
        <form
          onSubmit={handleSaveCustomTool}
          className="rounded-2xl bg-[#11131B] border border-white/10 p-5 sm:p-6 space-y-4 max-w-3xl"
        >
          <h2 className="text-base font-bold text-white">
            {editingToolId ? `${t.generators.customTools.saveChanges} (${newToolName})` : t.generators.customTools.addTitle}
          </h2>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {t.generators.customTools.toolName}
            </label>
            <input
              type="text"
              required
              value={newToolName}
              onChange={(e) => setNewToolName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white focus:outline-none focus:border-violet-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {t.generators.customTools.toolDesc}
            </label>
            <input
              type="text"
              value={newToolDesc}
              onChange={(e) => setNewToolDesc(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white focus:outline-none focus:border-violet-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {t.generators.customTools.refMethod}
            </label>
            <input
              type="text"
              value={newToolRef}
              onChange={(e) => setNewToolRef(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white focus:outline-none focus:border-violet-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {t.generators.customTools.templateLabel}
            </label>
            <p className="text-[11px] text-slate-400 mb-1.5">{t.generators.customTools.templateHint}</p>
            <textarea
              rows={5}
              dir="ltr"
              value={newToolTemplate}
              onChange={(e) => setNewToolTemplate(e.target.value)}
              placeholder="16:9 YouTube thumbnail: {SCENE}. Identity: {IDENTITY}. Pose: {POSE}, Expression: {EXPRESSION}, Background: {BACKGROUND}, Colors: {COLORS}. {TEXT}"
              className="w-full p-3.5 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white font-mono focus:outline-none focus:border-violet-500"
            />
          </div>

          <div className="flex items-center gap-3">
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 text-white text-xs font-bold cursor-pointer"
            >
              {editingToolId ? t.generators.customTools.saveChanges : t.generators.customTools.addBtn}
            </button>
            {editingToolId && (
              <button
                type="button"
                onClick={() => {
                  setEditingToolId(null);
                  setNewToolName('');
                  setNewToolDesc('');
                  setNewToolRef('');
                  setNewToolTemplate('');
                }}
                className="px-4 py-2.5 rounded-xl bg-white/8 text-slate-300 text-xs font-semibold cursor-pointer"
              >
                {t.common.cancel}
              </button>
            )}
          </div>
        </form>
      )}
    </div>
  );
};
