import React, { useMemo, useState } from 'react';
import { Check, Layers, Palette, Plus, Search, Sparkles, Wand2 } from 'lucide-react';
import {
  CREATOR_REFERENCES,
  GENERAL_STYLE_DIRECTIONS,
  getCreatorById,
  getGeneralStyleById,
} from '../data/visualDirections';
import { getT } from '../i18n/translations';
import type { CreatorReference, GeneralStyleDirection, Language } from '../types/architect';

interface VisualLibraryPageProps {
  lang: Language;
  selectedCreatorIds: string[];
  selectedGeneralIds: string[];
  hasActiveProject: boolean;
  onToggleCreator: (id: string) => void;
  onToggleGeneral: (id: string) => void;
  onClearBlend: () => void;
  onStartProjectWithBlend: () => void;
  onApplyBlendToActiveProject: () => void;
}

export const VisualLibraryPage: React.FC<VisualLibraryPageProps> = ({
  lang,
  selectedCreatorIds,
  selectedGeneralIds,
  hasActiveProject,
  onToggleCreator,
  onToggleGeneral,
  onClearBlend,
  onStartProjectWithBlend,
  onApplyBlendToActiveProject,
}) => {
  const t = getT(lang);
  const [tab, setTab] = useState<'arab' | 'global' | 'general'>('arab');
  const [search, setSearch] = useState('');

  const filteredCreators = useMemo(() => {
    const q = search.trim().toLowerCase();
    return CREATOR_REFERENCES.filter((c) => {
      if (c.region !== (tab === 'arab' ? 'arab' : 'global')) return false;
      if (!q) return true;
      return (
        c.nameAr.toLowerCase().includes(q) ||
        c.nameEn.toLowerCase().includes(q) ||
        c.styleDescAr.toLowerCase().includes(q) ||
        c.styleDescEn.toLowerCase().includes(q) ||
        c.bestContentAr.toLowerCase().includes(q) ||
        c.bestContentEn.toLowerCase().includes(q)
      );
    });
  }, [tab, search]);

  const filteredGeneral = useMemo(() => {
    const q = search.trim().toLowerCase();
    return GENERAL_STYLE_DIRECTIONS.filter((g) => {
      if (!q) return true;
      return (
        g.nameAr.toLowerCase().includes(q) ||
        g.nameEn.toLowerCase().includes(q) ||
        g.descAr.toLowerCase().includes(q) ||
        g.descEn.toLowerCase().includes(q)
      );
    });
  }, [search]);

  const activeBlendLabels = [
    ...selectedCreatorIds
      .map((id) => getCreatorById(id))
      .filter(Boolean)
      .map((c) => (lang === 'ar' ? c!.nameAr : c!.nameEn)),
    ...selectedGeneralIds
      .map((id) => getGeneralStyleById(id))
      .filter(Boolean)
      .map((g) => (lang === 'ar' ? g!.nameAr : g!.nameEn)),
  ];

  const renderCreatorCard = (creator: CreatorReference) => {
    const isSelected = selectedCreatorIds.includes(creator.id);
    const isAr = lang === 'ar';
    return (
      <div
        key={creator.id}
        className={`rounded-2xl p-5 border transition flex flex-col justify-between gap-4 ${
          isSelected
            ? 'bg-violet-500/10 border-violet-500/50 shadow-lg shadow-violet-950/30'
            : 'bg-[#11131B] border-white/8 hover:border-white/18'
        }`}
      >
        <div className="space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-white">
                {isAr ? creator.nameAr : creator.nameEn}
              </h3>
              <span className="text-[11px] text-slate-400">
                {isAr ? creator.nameEn : creator.nameAr}
              </span>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              {creator.paletteSwatches.map((hex) => (
                <span
                  key={hex}
                  className="w-3.5 h-3.5 rounded-full border border-white/20"
                  style={{ backgroundColor: hex }}
                  title={hex}
                />
              ))}
            </div>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            {isAr ? creator.styleDescAr : creator.styleDescEn}
          </p>

          <div className="space-y-2 text-[11px] pt-1">
            <div className="p-2.5 rounded-xl bg-[#090A0F]/80 border border-white/6">
              <span className="text-violet-300 font-semibold">{t.library.fields.colors}: </span>
              <span className="text-slate-300">{isAr ? creator.colorsAr : creator.colorsEn}</span>
            </div>
            <div className="p-2.5 rounded-xl bg-[#090A0F]/80 border border-white/6">
              <span className="text-blue-300 font-semibold">{t.library.fields.expressions}: </span>
              <span className="text-slate-300">
                {isAr ? creator.expressionStyleAr : creator.expressionStyleEn}
              </span>
            </div>
            <div className="p-2.5 rounded-xl bg-[#090A0F]/80 border border-white/6">
              <span className="text-indigo-300 font-semibold">{t.library.fields.placement}: </span>
              <span className="text-slate-300">
                {isAr ? creator.placementAr : creator.placementEn}
              </span>
            </div>
            <div className="p-2.5 rounded-xl bg-[#090A0F]/80 border border-white/6">
              <span className="text-slate-200 font-semibold">{t.library.fields.background}: </span>
              <span className="text-slate-400">
                {isAr ? creator.backgroundNatureAr : creator.backgroundNatureEn}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="p-2 rounded-xl bg-white/[0.03] border border-white/6">
                <div className="text-slate-400">{t.library.fields.exaggeration}</div>
                <div className="text-white font-semibold mt-0.5">
                  {t.library.exaggerationMap[creator.exaggerationLevel]}
                </div>
              </div>
              <div className="p-2 rounded-xl bg-white/[0.03] border border-white/6">
                <div className="text-slate-400">{t.library.fields.bestFor}</div>
                <div className="text-slate-200 font-medium mt-0.5 line-clamp-2">
                  {isAr ? creator.bestContentAr : creator.bestContentEn}
                </div>
              </div>
            </div>
            <div className="p-2.5 rounded-xl bg-violet-500/[0.07] border border-violet-500/20">
              <div className="text-violet-300 font-semibold mb-0.5">{t.library.fields.example}:</div>
              <div className="text-slate-200 leading-relaxed">
                {isAr ? creator.exampleCompositionAr : creator.exampleCompositionEn}
              </div>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={() => onToggleCreator(creator.id)}
          className={`w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold transition cursor-pointer ${
            isSelected
              ? 'bg-violet-600 text-white'
              : 'bg-white/6 hover:bg-white/12 text-slate-200 border border-white/10'
          }`}
        >
          {isSelected ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          <span>{isSelected ? t.library.selectedBadge : t.library.selectStyle}</span>
        </button>
      </div>
    );
  };

  const renderGeneralCard = (style: GeneralStyleDirection) => {
    const isSelected = selectedGeneralIds.includes(style.id);
    const isAr = lang === 'ar';
    return (
      <div
        key={style.id}
        className={`rounded-2xl p-5 border transition flex flex-col justify-between gap-4 ${
          isSelected
            ? 'bg-blue-500/10 border-blue-500/50 shadow-lg shadow-blue-950/30'
            : 'bg-[#11131B] border-white/8 hover:border-white/18'
        }`}
      >
        <div className="space-y-2.5">
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-sm font-bold text-white">{isAr ? style.nameAr : style.nameEn}</h3>
            <div className="flex items-center gap-1">
              {style.paletteSwatches.map((hex) => (
                <span
                  key={hex}
                  className="w-3 h-3 rounded-full border border-white/20"
                  style={{ backgroundColor: hex }}
                />
              ))}
            </div>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            {isAr ? style.descAr : style.descEn}
          </p>
          <div className="text-[11px] text-slate-400">
            <span className="text-blue-300 font-semibold">{t.library.fields.colors}: </span>
            {isAr ? style.colorsHintAr : style.colorsHintEn}
          </div>
        </div>

        <button
          type="button"
          onClick={() => onToggleGeneral(style.id)}
          className={`w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-bold transition cursor-pointer ${
            isSelected
              ? 'bg-blue-600 text-white'
              : 'bg-white/6 hover:bg-white/12 text-slate-200 border border-white/10'
          }`}
        >
          {isSelected ? <Check className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
          <span>{isSelected ? t.library.selectedBadge : t.library.selectStyle}</span>
        </button>
      </div>
    );
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20 lg:pb-8">
      {/* Header */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-violet-300 text-xs font-semibold">
          <Palette className="w-4 h-4" />
          <span>{t.nav.library}</span>
        </div>
        <h1 className="text-2xl font-bold text-white">{t.library.title}</h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-3xl leading-relaxed">
          {t.library.subtitle}
        </p>
      </div>

      {/* Multi-Style Blend Sticky Tray */}
      <div className="rounded-2xl bg-[#11131B] border border-violet-500/30 p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1.5 min-w-0">
          <div className="flex items-center gap-2 text-xs font-bold text-violet-300">
            <Layers className="w-4 h-4" />
            <span>{t.library.blendBarTitle}</span>
          </div>
          {activeBlendLabels.length === 0 ? (
            <p className="text-xs text-slate-400">{t.library.blendEmpty}</p>
          ) : (
            <div className="flex flex-wrap items-center gap-1.5">
              {activeBlendLabels.map((lbl, idx) => (
                <span
                  key={`${lbl}-${idx}`}
                  className="px-2.5 py-1 rounded-lg bg-violet-500/20 border border-violet-500/30 text-violet-200 text-xs font-semibold"
                >
                  {lbl}
                </span>
              ))}
              <button
                type="button"
                onClick={onClearBlend}
                className="text-[11px] text-slate-400 hover:text-white underline px-2 cursor-pointer"
              >
                {t.common.cancel}
              </button>
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {hasActiveProject && (
            <button
              type="button"
              onClick={onApplyBlendToActiveProject}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white/8 hover:bg-white/14 border border-white/12 text-white text-xs font-bold transition cursor-pointer"
            >
              <Wand2 className="w-3.5 h-3.5 text-blue-400" />
              <span>{t.library.applyToCurrent}</span>
            </button>
          )}
          <button
            type="button"
            onClick={onStartProjectWithBlend}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 text-white text-xs font-bold transition cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t.library.startWithBlend}</span>
          </button>
        </div>
      </div>

      {/* Category Tabs & Search */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setTab('arab')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              tab === 'arab'
                ? 'bg-violet-600 text-white'
                : 'bg-[#11131B] text-slate-300 border border-white/8 hover:bg-white/6'
            }`}
          >
            {t.library.arabCreators}
          </button>
          <button
            type="button"
            onClick={() => setTab('global')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              tab === 'global'
                ? 'bg-violet-600 text-white'
                : 'bg-[#11131B] text-slate-300 border border-white/8 hover:bg-white/6'
            }`}
          >
            {t.library.globalCreators}
          </button>
          <button
            type="button"
            onClick={() => setTab('general')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              tab === 'general'
                ? 'bg-blue-600 text-white'
                : 'bg-[#11131B] text-slate-300 border border-white/8 hover:bg-white/6'
            }`}
          >
            {t.library.generalStyles}
          </button>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 start-3 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t.common.search}
            className="w-full ps-9 pe-3 py-2 rounded-xl bg-[#11131B] border border-white/10 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500"
          />
        </div>
      </div>

      {/* Cards Grid */}
      {tab === 'general' ? (
        filteredGeneral.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-400 bg-[#11131B] rounded-2xl border border-white/8">
            {t.common.noResults}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredGeneral.map(renderGeneralCard)}
          </div>
        )
      ) : filteredCreators.length === 0 ? (
        <div className="p-8 text-center text-xs text-slate-400 bg-[#11131B] rounded-2xl border border-white/8">
          {t.common.noResults}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredCreators.map(renderCreatorCard)}
        </div>
      )}
    </div>
  );
};
