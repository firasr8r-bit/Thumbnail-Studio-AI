import React, { useEffect, useState } from 'react';
import { ShieldCheck, Sparkles, X } from 'lucide-react';
import { getAllGeneratorTools } from '../data/externalGenerators';
import { getT } from '../i18n/translations';
import type {
  AppSettings,
  GoogleFlowMode,
  IdentityMode,
  TargetGenerator,
} from '../types/architect';

export interface NewProjectCreationConfig {
  name: string;
  targetGenerator: TargetGenerator;
  flowMode: GoogleFlowMode;
  flowModel: string;
  identityMode: IdentityMode;
}

interface NewProjectModalProps {
  isOpen: boolean;
  settings: AppSettings;
  onClose: () => void;
  onCreate: (config: NewProjectCreationConfig) => void;
}

export const NewProjectModal: React.FC<NewProjectModalProps> = ({
  isOpen,
  settings,
  onClose,
  onCreate,
}) => {
  const lang = settings.language;
  const t = getT(lang);
  const tools = getAllGeneratorTools(settings);

  const [name, setName] = useState('');
  const [targetGenerator, setTargetGenerator] = useState<TargetGenerator>(
    settings.defaultGenerator
  );
  const [flowMode, setFlowMode] = useState<GoogleFlowMode>(settings.googleFlowDefaults.mode);
  const [flowModel, setFlowModel] = useState<string>(settings.googleFlowDefaults.modelChoice);
  const [identityMode, setIdentityMode] = useState<IdentityMode>(settings.defaultIdentityMode);

  useEffect(() => {
    if (isOpen) {
      setTargetGenerator(settings.defaultGenerator);
      setFlowMode(settings.googleFlowDefaults.mode);
      setFlowModel(settings.googleFlowDefaults.modelChoice);
      setIdentityMode(settings.defaultIdentityMode);
    }
  }, [isOpen, settings]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean =
      name.trim() ||
      (lang === 'ar'
        ? `مشروع صورة مصغّرة ${new Date().toLocaleDateString('ar')}`
        : `Thumbnail Project ${new Date().toLocaleDateString('en-US')}`);
    onCreate({
      name: clean,
      targetGenerator,
      flowMode,
      flowModel,
      identityMode,
    });
    setName('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="w-full max-w-lg rounded-2xl bg-[#11131B] border border-white/10 p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-violet-500/20 border border-violet-500/30 flex items-center justify-center text-violet-300">
              <Sparkles className="w-4 h-4" />
            </div>
            <h2 className="text-base font-bold text-white">{t.newProjectModal.title}</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/8 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {t.newProjectModal.nameLabel}
            </label>
            <input
              type="text"
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={t.newProjectModal.namePlaceholder}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#090A0F] border border-white/12 text-white text-sm placeholder:text-slate-500 focus:outline-none focus:border-violet-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {t.newProjectModal.generatorLabel}
            </label>
            <select
              value={targetGenerator}
              onChange={(e) => setTargetGenerator(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#090A0F] border border-white/12 text-white text-xs focus:outline-none focus:border-violet-500"
            >
              {tools.map((tool) => (
                <option key={tool.id} value={tool.id}>
                  {tool.name} {tool.isFeatured ? (lang === 'ar' ? '(الأساسي)' : '(Primary)') : ''}
                </option>
              ))}
            </select>
          </div>

          {targetGenerator === 'google-flow' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 rounded-xl bg-[#090A0F] border border-violet-500/30">
              <div>
                <label className="block text-[11px] font-semibold text-violet-300 mb-1">
                  {t.newProjectModal.flowModeQuickLabel}
                </label>
                <select
                  value={flowMode}
                  onChange={(e) => setFlowMode(e.target.value as GoogleFlowMode)}
                  className="w-full px-3 py-2 rounded-lg bg-[#11131B] border border-white/12 text-xs text-white focus:outline-none"
                >
                  <option value="image">Image Mode</option>
                  <option value="agent">Agent Mode</option>
                  <option value="editing">Image Editing</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-blue-300 mb-1">
                  {t.generators.flow.modelLabel}
                </label>
                <select
                  value={flowModel}
                  onChange={(e) => setFlowModel(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#11131B] border border-white/12 text-xs text-white focus:outline-none"
                >
                  {settings.flowModelsCatalog.map((m) => (
                    <option key={m} value={m}>
                      {m === 'auto-available'
                        ? lang === 'ar'
                          ? 'النموذج المتاح تلقائياً'
                          : 'Auto-Available Model'
                        : m}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {t.newProjectModal.identityQuickLabel}
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setIdentityMode('max-priority')}
                className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl border text-xs font-bold cursor-pointer ${
                  identityMode === 'max-priority'
                    ? 'bg-violet-600/20 border-violet-500 text-white'
                    : 'bg-[#090A0F] border-white/10 text-slate-400'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5 text-violet-300" />
                <span>Maximum Priority</span>
              </button>
              <button
                type="button"
                onClick={() => setIdentityMode('creative-transform')}
                className={`py-2.5 px-3 rounded-xl border text-xs font-bold cursor-pointer ${
                  identityMode === 'creative-transform'
                    ? 'bg-blue-600/20 border-blue-500 text-white'
                    : 'bg-[#090A0F] border-white/10 text-slate-400'
                }`}
              >
                Creative Transform
              </button>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-white/6 hover:bg-white/10 text-slate-300 text-sm font-medium cursor-pointer"
            >
              {t.common.cancel}
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 text-white text-sm font-bold cursor-pointer"
            >
              {t.newProjectModal.createBtn}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
