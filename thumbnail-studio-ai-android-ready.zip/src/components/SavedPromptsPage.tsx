import React, { useMemo, useState } from 'react';
import { BookmarkCheck, Check, Copy, ExternalLink, Search, Trash2 } from 'lucide-react';
import { getT } from '../i18n/translations';
import type { Language, SavedPromptEntry } from '../types/architect';

interface SavedPromptsPageProps {
  lang: Language;
  savedPrompts: SavedPromptEntry[];
  onDeletePrompt: (id: string) => void;
  onOpenProject: (projectId: string) => void;
}

export const SavedPromptsPage: React.FC<SavedPromptsPageProps> = ({
  lang,
  savedPrompts,
  onDeletePrompt,
  onOpenProject,
}) => {
  const t = getT(lang);
  const [search, setSearch] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return savedPrompts;
    return savedPrompts.filter(
      (p) =>
        p.projectName.toLowerCase().includes(q) ||
        p.videoTitle.toLowerCase().includes(q) ||
        p.mainPrompt.toLowerCase().includes(q) ||
        p.targetGenerator.toLowerCase().includes(q)
    );
  }, [savedPrompts, search]);

  const handleCopy = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(key);
      setTimeout(() => setCopiedId(null), 1600);
    } catch {
      // ignore clipboard errors
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-20 lg:pb-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">{t.savedPrompts.title}</h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">{t.savedPrompts.subtitle}</p>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 start-3 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t.common.search}
            className="w-full ps-9 pe-3 py-2 rounded-xl bg-[#11131B] border border-white/10 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500"
          />
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-2xl bg-[#11131B] border border-dashed border-white/12 p-10 text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-white/5 text-slate-400 flex items-center justify-center mx-auto">
            <BookmarkCheck className="w-6 h-6" />
          </div>
          <h2 className="text-base font-bold text-white">{t.savedPrompts.emptyTitle}</h2>
          <p className="text-xs text-slate-400 max-w-md mx-auto">{t.savedPrompts.emptyDesc}</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map((entry) => (
            <div
              key={entry.id}
              className="rounded-2xl bg-[#11131B] border border-white/8 p-5 space-y-4"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-base font-bold text-white">{entry.projectName}</h3>
                    <span className="text-[11px] px-2.5 py-0.5 rounded-md bg-violet-500/20 text-violet-300 font-mono-nums">
                      {entry.targetGenerator}
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 mt-1">
                    {entry.videoTitle} • {entry.visualDirectionLabel}
                  </div>
                </div>
                <span className="text-[11px] text-slate-500 font-mono-nums shrink-0">
                  {new Date(entry.createdAt).toLocaleString(lang === 'ar' ? 'ar' : 'en-US')}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-[#090A0F] border border-white/8 text-xs text-slate-200 font-mono leading-relaxed max-h-40 overflow-y-auto whitespace-pre-wrap" dir="ltr">
                {entry.mainPrompt}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleCopy(`main-${entry.id}`, entry.mainPrompt)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold cursor-pointer"
                  >
                    {copiedId === `main-${entry.id}` ? (
                      <Check className="w-3.5 h-3.5" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span>
                      {copiedId === `main-${entry.id}` ? t.common.copied : t.savedPrompts.copyMain}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleCopy(`neg-${entry.id}`, entry.negativePrompt)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/6 hover:bg-white/12 border border-white/10 text-slate-200 text-xs font-semibold cursor-pointer"
                  >
                    {copiedId === `neg-${entry.id}` ? (
                      <Check className="w-3.5 h-3.5" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span>
                      {copiedId === `neg-${entry.id}`
                        ? t.common.copied
                        : t.savedPrompts.copyNegative}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onOpenProject(entry.projectId)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-500/15 hover:bg-blue-500/25 border border-blue-500/30 text-blue-200 text-xs font-semibold cursor-pointer"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>{t.savedPrompts.openSourceProject}</span>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => onDeletePrompt(entry.id)}
                  className="p-2 rounded-xl bg-white/5 hover:bg-red-500/20 text-slate-400 hover:text-red-300 cursor-pointer"
                  title={t.common.delete}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
