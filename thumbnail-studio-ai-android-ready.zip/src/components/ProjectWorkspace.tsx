import React, { useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  BookmarkCheck,
  Check,
  Columns,
  Copy,
  Edit3,
  ImagePlus,
  Info,
  Languages,
  Layers,
  Palette,
  RefreshCw,
  RotateCcw,
  ShieldCheck,
  SkipForward,
  Sparkles,
  Star,
  Trash2,
  UserPlus,
  Users,
  Wand2,
} from 'lucide-react';
import { getAllGeneratorTools } from '../data/externalGenerators';
import { analyzeReferencesPreflight } from '../engine/generatorPromptEngines';
import {
  analyzeIdeaLocally,
  applyRefinementToProject,
  buildAdaptiveWizardSteps,
  buildStyleSummaryLabel,
  synthesizePromptBundle,
} from '../engine/localArchitectEngine';
import { getT } from '../i18n/translations';
import { tryOptionalServerIdeaAnalysis } from '../services/architectClient';
import type {
  AppSettings,
  ArchitectProject,
  GoogleFlowConfig,
  GoogleFlowMode,
  IdeaInputs,
  Language,
  PersonProfile,
  ProjectPhase,
  ReferenceImageItem,
  ReferenceRole,
  RefinementAction,
  TargetGenerator,
} from '../types/architect';
import { fileToOptimizedDataUrl } from '../utils/imageUpload';

interface ProjectWorkspaceProps {
  project: ArchitectProject | null;
  lang: Language;
  settings: AppSettings;
  useOptionalServerAI: boolean;
  onUpdateProject: (updated: ArchitectProject) => void;
  onOpenLibrary: () => void;
  onOpenGeneratorsTab: (tab: 'library' | 'flow' | 'compare' | 'custom') => void;
  onNewProject: () => void;
  onSavePromptToLibrary: (project: ArchitectProject) => Promise<void>;
}

export const ProjectWorkspace: React.FC<ProjectWorkspaceProps> = ({
  project,
  lang,
  settings,
  useOptionalServerAI,
  onUpdateProject,
  onOpenLibrary,
  onOpenGeneratorsTab,
  onNewProject,
  onSavePromptToLibrary,
}) => {
  const t = getT(lang);
  const NextIcon = lang === 'ar' ? ArrowLeft : ArrowRight;
  const BackIcon = lang === 'ar' ? ArrowRight : ArrowLeft;

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [newPersonName, setNewPersonName] = useState('');
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [showArabicTrans, setShowArabicTrans] = useState(true);
  const [isEditingPrompt, setIsEditingPrompt] = useState(false);
  const [savedPromptSuccess, setSavedPromptSuccess] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [pendingUploadTarget, setPendingUploadTarget] = useState<{
    groupId: string;
    label: string;
    role: ReferenceRole;
    replaceId?: string;
  } | null>(null);

  const allTools = useMemo(() => getAllGeneratorTools(settings), [settings]);

  const personGroups = useMemo(() => {
    if (!project) return [];
    const map = new Map<
      string,
      { groupId: string; label: string; items: ReferenceImageItem[]; profile: PersonProfile }
    >();

    const profiles = project.personProfiles ?? {};

    Object.values(profiles).forEach((prof) => {
      map.set(prof.groupId, {
        groupId: prof.groupId,
        label: prof.label,
        items: [],
        profile: prof,
      });
    });

    project.referenceImages
      .filter((r) => r.role === 'person')
      .forEach((item) => {
        const existing = map.get(item.personGroupId);
        if (existing) {
          existing.items.push(item);
          if (!existing.label && item.personLabel) {
            existing.label = item.personLabel;
          }
        } else {
          const prof = profiles[item.personGroupId];
          map.set(item.personGroupId, {
            groupId: item.personGroupId,
            label: prof?.label || item.personLabel,
            items: [item],
            profile: prof ?? {
              groupId: item.personGroupId,
              label: item.personLabel,
              visibleTraits: '',
              thumbnailRole: '',
              primaryImageId: item.id,
            },
          });
        }
      });

    if (map.size === 0) {
      const defaultLabel = lang === 'ar' ? 'الشخص 1' : 'Person 1';
      map.set('person-group-1', {
        groupId: 'person-group-1',
        label: defaultLabel,
        items: [],
        profile: {
          groupId: 'person-group-1',
          label: defaultLabel,
          visibleTraits: '',
          thumbnailRole: '',
        },
      });
    }

    return Array.from(map.values());
  }, [project, lang]);

  const assetRefs = useMemo(
    () => (project ? project.referenceImages.filter((r) => r.role !== 'person') : []),
    [project]
  );

  const preflightReport = useMemo(
    () =>
      project
        ? analyzeReferencesPreflight(project, settings.referenceMinResolution)
        : null,
    [project, settings.referenceMinResolution]
  );

  if (!project) {
    return (
      <div className="max-w-3xl mx-auto py-16 text-center space-y-4">
        <div className="w-14 h-14 rounded-2xl bg-violet-500/15 border border-violet-500/30 text-violet-300 flex items-center justify-center mx-auto">
          <Wand2 className="w-7 h-7" />
        </div>
        <h2 className="text-xl font-bold text-white">{t.workspace.noActiveProjectTitle}</h2>
        <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto">
          {t.workspace.noActiveProjectDesc}
        </p>
        <button
          type="button"
          onClick={onNewProject}
          className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 text-white text-sm font-bold cursor-pointer"
        >
          <Sparkles className="w-4 h-4" />
          <span>{t.common.newProject}</span>
        </button>
      </div>
    );
  }

  const activeStyleLabel = buildStyleSummaryLabel(
    project.selectedCreatorIds,
    project.selectedGeneralIds,
    lang
  );

  const activeFlowConfig: GoogleFlowConfig =
    project.wizardAnswers.googleFlowConfig ?? settings.googleFlowDefaults;
  const activeIdentityMode =
    project.wizardAnswers.identityMode ?? settings.defaultIdentityMode;

  const wizardSteps = buildAdaptiveWizardSteps(project, lang, settings);
  const currentStepIdx = Math.min(
    Math.max(0, project.wizardStepIndex),
    Math.max(0, wizardSteps.length - 1)
  );
  const currentStep = wizardSteps[currentStepIdx];

  const updateIdeaField = (field: keyof IdeaInputs, value: string) => {
    onUpdateProject({
      ...project,
      updatedAt: Date.now(),
      ideaInputs: {
        ...project.ideaInputs,
        [field]: value,
      },
    });
  };

  const runAnalysis = async (moveToWizardAfter = false) => {
    setIsAnalyzing(true);
    try {
      const localResult = analyzeIdeaLocally(
        project.ideaInputs,
        project.selectedCreatorIds,
        project.selectedGeneralIds,
        lang
      );

      let finalAnalysis = localResult.analysis;
      let finalConcepts = localResult.concepts;

      if (useOptionalServerAI && project.ideaInputs.videoTitle.trim()) {
        const serverRes = await tryOptionalServerIdeaAnalysis({
          inputs: project.ideaInputs,
          styleSummary: activeStyleLabel,
          lang,
        });
        if (serverRes.available && serverRes.analysis && serverRes.concepts) {
          finalAnalysis = serverRes.analysis;
          finalConcepts = serverRes.concepts;
        }
      }

      const selectedId =
        finalConcepts.find((c) => c.id === project.wizardAnswers.selectedConceptId)?.id ||
        finalConcepts[0]?.id ||
        'concept-clash';

      onUpdateProject({
        ...project,
        updatedAt: Date.now(),
        analysis: finalAnalysis,
        concepts: finalConcepts,
        wizardAnswers: {
          ...project.wizardAnswers,
          selectedConceptId: selectedId,
        },
        phase: moveToWizardAfter ? 'wizard' : project.phase,
        wizardStepIndex: moveToWizardAfter ? 0 : project.wizardStepIndex,
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const triggerUpload = (
    groupId: string,
    label: string,
    role: ReferenceRole,
    replaceId?: string
  ) => {
    setUploadError(null);
    setPendingUploadTarget({ groupId, label, role, replaceId });
    fileInputRef.current?.click();
  };

  const handleFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || !pendingUploadTarget) return;

    try {
      const nextRefs = [...project.referenceImages];
      const nextProfiles = { ...(project.personProfiles ?? {}) };

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const optimized = await fileToOptimizedDataUrl(file);
        const existingInGroup = nextRefs.filter(
          (r) => r.role === 'person' && r.personGroupId === pendingUploadTarget.groupId
        );
        const isFirstForGroup =
          pendingUploadTarget.role === 'person' && existingInGroup.length === 0 && i === 0;

        const newItem: ReferenceImageItem = {
          id:
            pendingUploadTarget.replaceId ||
            `ref-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          personGroupId: pendingUploadTarget.groupId,
          personLabel: pendingUploadTarget.label,
          role: pendingUploadTarget.role,
          fileName: file.name,
          dataUrl: optimized.dataUrl,
          mimeType: optimized.mimeType,
          isPrimary: isFirstForGroup,
          diagnostics: optimized.diagnostics,
        };

        if (pendingUploadTarget.replaceId && i === 0) {
          const idx = nextRefs.findIndex((r) => r.id === pendingUploadTarget.replaceId);
          if (idx !== -1) {
            newItem.isPrimary = nextRefs[idx].isPrimary;
            newItem.manualWarnings = nextRefs[idx].manualWarnings;
            nextRefs[idx] = newItem;
          } else {
            nextRefs.push(newItem);
          }
        } else {
          nextRefs.push(newItem);
        }

        if (pendingUploadTarget.role === 'person') {
          const curProf = nextProfiles[pendingUploadTarget.groupId] ?? {
            groupId: pendingUploadTarget.groupId,
            label: pendingUploadTarget.label,
            visibleTraits: '',
            thumbnailRole: '',
          };
          nextProfiles[pendingUploadTarget.groupId] = {
            ...curProf,
            label: pendingUploadTarget.label,
            primaryImageId: curProf.primaryImageId ?? newItem.id,
          };
        }
      }

      onUpdateProject({
        ...project,
        updatedAt: Date.now(),
        referenceImages: nextRefs,
        personProfiles: nextProfiles,
      });
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Failed to load image');
    } finally {
      e.target.value = '';
      setPendingUploadTarget(null);
    }
  };

  const updatePersonProfile = (
    groupId: string,
    defaultLabel: string,
    patch: Partial<PersonProfile>
  ) => {
    const cur = project.personProfiles?.[groupId] ?? {
      groupId,
      label: defaultLabel,
      visibleTraits: '',
      thumbnailRole: '',
    };
    const merged: PersonProfile = { ...cur, ...patch, groupId };
    const updatedRefs =
      patch.label !== undefined
        ? project.referenceImages.map((r) =>
            r.personGroupId === groupId ? { ...r, personLabel: patch.label! } : r
          )
        : project.referenceImages;

    onUpdateProject({
      ...project,
      updatedAt: Date.now(),
      referenceImages: updatedRefs,
      personProfiles: {
        ...(project.personProfiles ?? {}),
        [groupId]: merged,
      },
    });
  };

  const handleSetPrimaryImage = (groupId: string, defaultLabel: string, refId: string) => {
    const updatedRefs = project.referenceImages.map((r) =>
      r.role === 'person' && r.personGroupId === groupId
        ? { ...r, isPrimary: r.id === refId }
        : r
    );
    const cur = project.personProfiles?.[groupId] ?? {
      groupId,
      label: defaultLabel,
      visibleTraits: '',
      thumbnailRole: '',
    };
    onUpdateProject({
      ...project,
      updatedAt: Date.now(),
      referenceImages: updatedRefs,
      personProfiles: {
        ...(project.personProfiles ?? {}),
        [groupId]: { ...cur, primaryImageId: refId },
      },
    });
  };

  const handleToggleManualWarning = (
    refId: string,
    flag: 'faceSmall' | 'faceObscured' | 'angleMismatch'
  ) => {
    const updatedRefs = project.referenceImages.map((r) => {
      if (r.id !== refId) return r;
      const curFlags = r.manualWarnings ?? {};
      return {
        ...r,
        manualWarnings: {
          ...curFlags,
          [flag]: !curFlags[flag],
        },
      };
    });
    onUpdateProject({
      ...project,
      updatedAt: Date.now(),
      referenceImages: updatedRefs,
    });
  };

  const handleDeleteReference = (refId: string) => {
    const nextRefs = project.referenceImages.filter((r) => r.id !== refId);
    const nextProfiles = { ...(project.personProfiles ?? {}) };
    Object.keys(nextProfiles).forEach((gid) => {
      if (nextProfiles[gid].primaryImageId === refId) {
        const replacement = nextRefs.find((r) => r.role === 'person' && r.personGroupId === gid);
        nextProfiles[gid] = {
          ...nextProfiles[gid],
          primaryImageId: replacement?.id,
        };
      }
    });

    onUpdateProject({
      ...project,
      updatedAt: Date.now(),
      referenceImages: nextRefs,
      personProfiles: nextProfiles,
    });
  };

  const handleAddPersonGroup = () => {
    const clean =
      newPersonName.trim() ||
      (lang === 'ar'
        ? `الشخص ${personGroups.length + 1}`
        : `Person ${personGroups.length + 1}`);
    const newId = `person-group-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`;
    onUpdateProject({
      ...project,
      updatedAt: Date.now(),
      personProfiles: {
        ...(project.personProfiles ?? {}),
        [newId]: {
          groupId: newId,
          label: clean,
          visibleTraits: '',
          thumbnailRole: '',
        },
      },
    });
    setNewPersonName('');
  };

  const handleDeletePersonGroup = (groupId: string) => {
    const nextRefs = project.referenceImages.filter(
      (r) => !(r.role === 'person' && r.personGroupId === groupId)
    );
    const nextProfiles = { ...(project.personProfiles ?? {}) };
    delete nextProfiles[groupId];
    onUpdateProject({
      ...project,
      updatedAt: Date.now(),
      referenceImages: nextRefs,
      personProfiles: nextProfiles,
    });
  };

  const setPhase = async (phase: ProjectPhase) => {
    if (phase === 'wizard' && project.concepts.length === 0) {
      await runAnalysis(true);
      return;
    }
    if (phase === 'result' && !project.promptResult) {
      const ensuredConcepts =
        project.concepts.length > 0
          ? project
          : (() => {
              const local = analyzeIdeaLocally(
                project.ideaInputs,
                project.selectedCreatorIds,
                project.selectedGeneralIds,
                lang
              );
              return {
                ...project,
                analysis: local.analysis,
                concepts: local.concepts,
              };
            })();
      const bundle = synthesizePromptBundle(ensuredConcepts, 0, lang, undefined, settings);
      onUpdateProject({
        ...ensuredConcepts,
        phase: 'result',
        promptResult: bundle,
        updatedAt: Date.now(),
      });
      return;
    }

    onUpdateProject({
      ...project,
      phase,
      updatedAt: Date.now(),
    });
  };

  const handleWizardOptionSelect = (optionId: string) => {
    const a = { ...project.wizardAnswers };
    switch (currentStep.id) {
      case 'concept':
        a.selectedConceptId = optionId;
        break;
      case 'expressions':
        a.expressionChoice = optionId;
        break;
      case 'pose':
        a.poseChoice = optionId;
        break;
      case 'background':
        a.backgroundChoice = optionId;
        break;
      case 'colors':
        a.colorChoice = optionId;
        break;
      case 'text':
        a.textMode = optionId as 'yes' | 'no' | 'suggest';
        if (optionId === 'suggest' && !a.thumbnailText.trim()) {
          const suggested = currentStep.options.find((o) => o.id === 'suggest');
          const match = (lang === 'ar' ? suggested?.labelAr : suggested?.labelEn)?.match(/"([^"]+)"/);
          a.thumbnailText = match?.[1] || (lang === 'ar' ? 'من الأذكى؟!' : 'WHO WINS?!');
        }
        break;
      case 'elements': {
        if (optionId === 'none') {
          a.elementsSelected = ['none'];
        } else {
          const cleaned = a.elementsSelected.filter((id) => id !== 'none');
          a.elementsSelected = cleaned.includes(optionId)
            ? cleaned.filter((id) => id !== optionId)
            : [...cleaned, optionId];
          if (a.elementsSelected.length === 0) {
            a.elementsSelected = ['none'];
          }
        }
        break;
      }
      case 'generator':
        a.targetGenerator = optionId as TargetGenerator;
        break;
    }

    onUpdateProject({
      ...project,
      updatedAt: Date.now(),
      wizardAnswers: a,
    });
  };

  const isOptionSelected = (optionId: string): boolean => {
    const a = project.wizardAnswers;
    switch (currentStep.id) {
      case 'concept':
        return a.selectedConceptId === optionId;
      case 'expressions':
        return a.expressionChoice === optionId;
      case 'pose':
        return a.poseChoice === optionId;
      case 'background':
        return a.backgroundChoice === optionId;
      case 'colors':
        return a.colorChoice === optionId;
      case 'text':
        return a.textMode === optionId;
      case 'elements':
        return a.elementsSelected.includes(optionId);
      case 'generator':
        return a.targetGenerator === optionId;
    }
  };

  const updateProjectFlowConfig = (patch: Partial<GoogleFlowConfig>, resynthesize = false) => {
    const nextCfg: GoogleFlowConfig = {
      ...activeFlowConfig,
      ...patch,
    };
    const nextProject: ArchitectProject = {
      ...project,
      updatedAt: Date.now(),
      wizardAnswers: {
        ...project.wizardAnswers,
        googleFlowConfig: nextCfg,
      },
    };
    if (resynthesize) {
      nextProject.promptResult = synthesizePromptBundle(
        nextProject,
        nextProject.promptResult?.variationSeed ?? 0,
        lang,
        undefined,
        settings
      );
      nextProject.customEditedPrompt = undefined;
    }
    onUpdateProject(nextProject);
  };

  const updateIdentityMode = (
    mode: 'max-priority' | 'creative-transform',
    resynthesize = false
  ) => {
    const nextProject: ArchitectProject = {
      ...project,
      updatedAt: Date.now(),
      wizardAnswers: {
        ...project.wizardAnswers,
        identityMode: mode,
      },
    };
    if (resynthesize) {
      nextProject.promptResult = synthesizePromptBundle(
        nextProject,
        nextProject.promptResult?.variationSeed ?? 0,
        lang,
        undefined,
        settings
      );
      nextProject.customEditedPrompt = undefined;
    }
    onUpdateProject(nextProject);
  };

  const switchGeneratorInResult = (nextToolId: TargetGenerator) => {
    const nextProject: ArchitectProject = {
      ...project,
      updatedAt: Date.now(),
      wizardAnswers: {
        ...project.wizardAnswers,
        targetGenerator: nextToolId,
      },
      customEditedPrompt: undefined,
    };
    nextProject.promptResult = synthesizePromptBundle(
      nextProject,
      nextProject.promptResult?.variationSeed ?? 0,
      lang,
      undefined,
      settings
    );
    onUpdateProject(nextProject);
    setIsEditingPrompt(false);
    setSavedPromptSuccess(false);
  };

  const handleWizardNext = () => {
    if (currentStepIdx < wizardSteps.length - 1) {
      onUpdateProject({
        ...project,
        wizardStepIndex: currentStepIdx + 1,
        updatedAt: Date.now(),
      });
    } else {
      const bundle = synthesizePromptBundle(project, 0, lang, undefined, settings);
      onUpdateProject({
        ...project,
        phase: 'result',
        promptResult: bundle,
        customEditedPrompt: undefined,
        updatedAt: Date.now(),
      });
      setIsEditingPrompt(false);
    }
  };

  const handleWizardBack = () => {
    if (currentStepIdx > 0) {
      onUpdateProject({
        ...project,
        wizardStepIndex: currentStepIdx - 1,
        updatedAt: Date.now(),
      });
    } else {
      onUpdateProject({
        ...project,
        phase: 'idea',
        updatedAt: Date.now(),
      });
    }
  };

  const handleRefinement = (action: RefinementAction) => {
    const refined = applyRefinementToProject(project, action, lang, settings);
    onUpdateProject(refined);
    setIsEditingPrompt(false);
    setSavedPromptSuccess(false);
  };

  const copyText = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 1800);
    } catch {
      // ignore clipboard restrictions
    }
  };

  const displayedMainPrompt =
    project.customEditedPrompt ?? project.promptResult?.mainPrompt ?? '';

  const copyAllResults = () => {
    if (!project.promptResult) return;
    const pr = project.promptResult;
    const fs = pr.flowSections;
    const bundleText = fs
      ? [
          `=== ${project.name} (${pr.targetGeneratorName}) ===`,
          `\n[A. MAIN FLOW PROMPT]\n${displayedMainPrompt}`,
          `\n[B. IDENTITY PROTECTION INSTRUCTIONS]\n${fs.identityProtectionInstructions}`,
          `\n[C. COMPOSITION INSTRUCTIONS]\n${fs.compositionInstructions}`,
          `\n[D. TEXT INSTRUCTIONS]\n${fs.textInstructions}`,
          `\n[E. AVOID INSTRUCTIONS]\n${fs.avoidInstructions}`,
          `\n[F. REFERENCE UPLOAD GUIDE & FLOW STEPS]\n${fs.referenceUploadGuide}\n\n${lang === 'ar' ? pr.usageInstructionsAr : pr.usageInstructionsEn}`,
          `\n[ARABIC SUMMARY]\n${pr.arabicTranslation}`,
        ].join('\n')
      : [
          `=== ${project.name} (${pr.targetGeneratorName}) ===`,
          `\n[MAIN PROMPT]\n${displayedMainPrompt}`,
          `\n[NEGATIVE PROMPT]\n${pr.negativePrompt}`,
          `\n[ARABIC SUMMARY]\n${pr.arabicTranslation}`,
          `\n[REFERENCE UPLOAD ORDER]\n${lang === 'ar' ? pr.referenceUploadGuideAr : pr.referenceUploadGuideEn}`,
          `\n[USAGE & SETTINGS]\n${lang === 'ar' ? pr.usageInstructionsAr : pr.usageInstructionsEn}\n${lang === 'ar' ? pr.recommendedSettingsAr : pr.recommendedSettingsEn}`,
        ].join('\n');
    void copyText('copy-all', bundleText);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-24 lg:pb-10">
      {/* Hidden shared file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleFileSelected}
        className="hidden"
      />

      {/* Project Header & 3-Phase Stepper */}
      <div className="rounded-2xl bg-[#11131B] border border-white/10 p-4 sm:p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h1 className="text-lg sm:text-xl font-bold text-white">{project.name}</h1>
            <div className="text-xs text-slate-400 mt-0.5">
              {t.workspace.styleMixLabel}:{' '}
              <span className="text-violet-300">{activeStyleLabel}</span>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenLibrary}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/6 hover:bg-white/12 border border-white/10 text-xs font-semibold text-slate-200 cursor-pointer self-start whitespace-nowrap"
          >
            <Palette className="w-3.5 h-3.5 text-blue-400" />
            <span>{t.workspace.changeStylesBtn}</span>
          </button>
        </div>

        {/* Phase Tabs */}
        <div className="grid grid-cols-3 gap-2">
          {(
            [
              { id: 'idea', label: t.workspace.phase1 },
              { id: 'wizard', label: t.workspace.phase2 },
              { id: 'result', label: t.workspace.phase3 },
            ] as const
          ).map((ph) => {
            const active = project.phase === ph.id;
            return (
              <button
                key={ph.id}
                type="button"
                onClick={() => void setPhase(ph.id)}
                className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition cursor-pointer ${
                  active
                    ? 'bg-gradient-to-r from-violet-600/25 to-blue-600/25 border-violet-500/50 text-white'
                    : 'bg-[#090A0F]/60 border-white/8 text-slate-400 hover:text-slate-200'
                }`}
              >
                {ph.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* ===================== PHASE 1: IDEA & REFERENCES ===================== */}
      {project.phase === 'idea' && (
        <div className="space-y-6">
          {/* Video Idea Form */}
          <section className="rounded-2xl bg-[#11131B] border border-white/8 p-5 sm:p-6 space-y-4">
            <div className="space-y-1">
              <h2 className="text-base font-bold text-white">{t.workspace.ideaFormTitle}</h2>
              <p className="text-xs text-slate-400">{t.workspace.ideaFormHint}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  {t.workspace.videoTitleLabel}
                </label>
                <input
                  type="text"
                  value={project.ideaInputs.videoTitle}
                  onChange={(e) => updateIdeaField('videoTitle', e.target.value)}
                  placeholder={t.workspace.videoTitlePlaceholder}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#090A0F] border border-white/12 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  {t.workspace.ideaDescLabel}
                </label>
                <textarea
                  rows={3}
                  value={project.ideaInputs.ideaDescription}
                  onChange={(e) => updateIdeaField('ideaDescription', e.target.value)}
                  placeholder={t.workspace.ideaDescPlaceholder}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#090A0F] border border-white/12 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  {t.workspace.contentTypeLabel}
                </label>
                <input
                  type="text"
                  value={project.ideaInputs.contentType}
                  onChange={(e) => updateIdeaField('contentType', e.target.value)}
                  placeholder={t.workspace.contentTypePlaceholder}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#090A0F] border border-white/12 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  {t.workspace.participantsLabel}
                </label>
                <input
                  type="text"
                  value={project.ideaInputs.participantsDescription}
                  onChange={(e) => updateIdeaField('participantsDescription', e.target.value)}
                  placeholder={t.workspace.participantsPlaceholder}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#090A0F] border border-white/12 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  {t.workspace.coreMessageLabel}
                </label>
                <input
                  type="text"
                  value={project.ideaInputs.coreMessage}
                  onChange={(e) => updateIdeaField('coreMessage', e.target.value)}
                  placeholder={t.workspace.coreMessagePlaceholder}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#090A0F] border border-white/12 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                type="button"
                disabled={isAnalyzing}
                onClick={() => void runAnalysis(false)}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 disabled:opacity-60 text-white text-xs sm:text-sm font-bold cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>{isAnalyzing ? t.workspace.analyzingBtn : t.workspace.analyzeBtn}</span>
              </button>

              {project.concepts.length > 0 && (
                <button
                  type="button"
                  onClick={() => void setPhase('wizard')}
                  className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-white/8 hover:bg-white/14 border border-white/12 text-white text-xs sm:text-sm font-bold cursor-pointer"
                >
                  <span>{t.workspace.proceedToWizard}</span>
                  <NextIcon className="w-4 h-4" />
                </button>
              )}
            </div>
          </section>

          {/* Idea Breakdown + Proposed Concepts */}
          {project.analysis && (
            <section className="rounded-2xl bg-[#11131B] border border-violet-500/30 p-5 sm:p-6 space-y-5">
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-base font-bold text-white">{t.workspace.analysisCardTitle}</h2>
                <span className="text-[11px] px-2.5 py-1 rounded-lg bg-violet-500/20 text-violet-300 font-semibold">
                  {project.analysis.detectedCategory}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div className="p-3.5 rounded-xl bg-[#090A0F] border border-white/8 space-y-1">
                  <div className="text-violet-300 font-bold">{t.workspace.mostExciting}</div>
                  <p className="text-slate-200 leading-relaxed">
                    {project.analysis.mostExcitingElement}
                  </p>
                </div>
                <div className="p-3.5 rounded-xl bg-[#090A0F] border border-white/8 space-y-1">
                  <div className="text-blue-300 font-bold">{t.workspace.attentionMoment}</div>
                  <p className="text-slate-200 leading-relaxed">
                    {project.analysis.attentionMoment}
                  </p>
                </div>
                <div className="p-3.5 rounded-xl bg-[#090A0F] border border-white/8 space-y-1">
                  <div className="text-indigo-300 font-bold">{t.workspace.targetEmotions}</div>
                  <p className="text-slate-200 leading-relaxed">
                    {project.analysis.targetEmotions}
                  </p>
                </div>
                <div className="p-3.5 rounded-xl bg-[#090A0F] border border-white/8 space-y-1">
                  <div className="text-emerald-300 font-bold">{t.workspace.viewerQuestion}</div>
                  <p className="text-slate-200 leading-relaxed">
                    {project.analysis.viewerQuestion}
                  </p>
                </div>
                <div className="md:col-span-2 p-3.5 rounded-xl bg-[#090A0F] border border-white/8 space-y-1">
                  <div className="text-slate-100 font-bold">{t.workspace.bestVisualAngle}</div>
                  <p className="text-slate-300 leading-relaxed">
                    {project.analysis.bestVisualAngle}
                  </p>
                </div>
              </div>

              {/* 4 Visual Concepts */}
              <div className="space-y-3 pt-2">
                <h3 className="text-sm font-bold text-white">{t.workspace.conceptsTitle}</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {project.concepts.map((c) => {
                    const selected = project.wizardAnswers.selectedConceptId === c.id;
                    return (
                      <div
                        key={c.id}
                        onClick={() =>
                          onUpdateProject({
                            ...project,
                            updatedAt: Date.now(),
                            wizardAnswers: {
                              ...project.wizardAnswers,
                              selectedConceptId: c.id,
                            },
                          })
                        }
                        className={`p-4 rounded-2xl border cursor-pointer transition space-y-2.5 ${
                          selected
                            ? 'bg-violet-500/12 border-violet-500/50'
                            : 'bg-[#090A0F]/90 border-white/8 hover:border-white/20'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <h4 className="text-sm font-bold text-white">{c.name}</h4>
                          {selected && (
                            <span className="text-[11px] px-2 py-0.5 rounded-md bg-violet-600 text-white font-semibold">
                              {t.library.selectedBadge}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-300 leading-relaxed">{c.sceneDescription}</p>
                        <div className="text-[11px] text-slate-400 space-y-1 pt-1">
                          <div>• {c.peoplePose}</div>
                          <div>• {c.facialExpressions}</div>
                          <div>• {c.background}</div>
                          <div>• {c.colors}</div>
                          <div className="text-blue-300 pt-1">{c.whyItFits}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => void setPhase('wizard')}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 text-white text-sm font-bold cursor-pointer"
                >
                  <span>{t.workspace.proceedToWizard}</span>
                  <NextIcon className="w-4 h-4" />
                </button>
              </div>
            </section>
          )}

          {/* Reference Images & Independent Person Cards Section */}
          <section className="rounded-2xl bg-[#11131B] border border-white/8 p-5 sm:p-6 space-y-5">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/15 text-blue-400 flex items-center justify-center shrink-0">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-white">{t.workspace.refsTitle}</h2>
                <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                  {t.workspace.refsSubtitle}
                </p>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-blue-500/10 border border-blue-500/25 flex items-start gap-2.5 text-xs text-blue-100 leading-relaxed">
              <ShieldCheck className="w-4 h-4 text-blue-300 shrink-0 mt-0.5" />
              <span>{t.workspace.identityNotice}</span>
            </div>

            {uploadError && (
              <div className="p-3 rounded-xl bg-red-500/15 border border-red-500/30 text-xs text-red-200">
                {uploadError}
              </div>
            )}

            {/* Add New Person Card */}
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={newPersonName}
                onChange={(e) => setNewPersonName(e.target.value)}
                placeholder={t.workspace.addPersonGroupPlaceholder}
                className="flex-1 px-3.5 py-2.5 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500"
              />
              <button
                type="button"
                onClick={handleAddPersonGroup}
                className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-white/8 hover:bg-white/14 border border-white/12 text-xs font-bold text-white cursor-pointer whitespace-nowrap"
              >
                <UserPlus className="w-4 h-4 text-violet-300" />
                <span>{t.workspace.addPersonBtn}</span>
              </button>
            </div>

            {/* Independent Person Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {personGroups.map((group, idx) => {
                const resolvedPrimaryId =
                  group.profile.primaryImageId ||
                  group.items.find((i) => i.isPrimary)?.id ||
                  group.items[0]?.id;

                return (
                  <div
                    key={group.groupId}
                    className="p-4 rounded-2xl bg-[#090A0F] border border-white/10 space-y-3"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-mono-nums text-violet-300 font-bold shrink-0">
                        Person {idx + 1}
                      </span>
                      <input
                        type="text"
                        value={group.label}
                        onChange={(e) =>
                          updatePersonProfile(group.groupId, group.label, {
                            label: e.target.value,
                          })
                        }
                        className="flex-1 min-w-0 px-2.5 py-1.5 rounded-lg bg-[#11131B] border border-white/10 text-xs font-bold text-white focus:outline-none focus:border-violet-500"
                      />
                      <button
                        type="button"
                        onClick={() => triggerUpload(group.groupId, group.label, 'person')}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-violet-600 hover:bg-violet-500 text-white text-[11px] font-bold cursor-pointer shrink-0 whitespace-nowrap"
                      >
                        <ImagePlus className="w-3.5 h-3.5" />
                        <span>{t.workspace.uploadBtn}</span>
                      </button>
                      {personGroups.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleDeletePersonGroup(group.groupId)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-red-300 hover:bg-red-500/15 cursor-pointer"
                          title={t.common.delete}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>

                    {/* Visible Traits & Thumbnail Role */}
                    <div className="space-y-2">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                          {t.workspace.personTraitsLabel}
                        </label>
                        <input
                          type="text"
                          value={group.profile.visibleTraits}
                          onChange={(e) =>
                            updatePersonProfile(group.groupId, group.label, {
                              visibleTraits: e.target.value,
                            })
                          }
                          placeholder={t.workspace.personTraitsPlaceholder}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-[#11131B] border border-white/10 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                          {t.workspace.personRoleLabel}
                        </label>
                        <input
                          type="text"
                          value={group.profile.thumbnailRole}
                          onChange={(e) =>
                            updatePersonProfile(group.groupId, group.label, {
                              thumbnailRole: e.target.value,
                            })
                          }
                          placeholder={t.workspace.personRolePlaceholder}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-[#11131B] border border-white/10 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500"
                        />
                      </div>
                    </div>

                    {group.items.length === 0 ? (
                      <div className="py-5 text-center text-[11px] text-slate-500 border border-dashed border-white/10 rounded-xl">
                        {t.workspace.uploadRolePerson}
                      </div>
                    ) : (
                      <div className="space-y-2.5">
                        {group.items.map((img) => {
                          const isPrimary = img.id === resolvedPrimaryId;
                          return (
                            <div
                              key={img.id}
                              className={`p-2.5 rounded-xl border bg-[#11131B] space-y-2 ${
                                isPrimary ? 'border-violet-500/50' : 'border-white/10'
                              }`}
                            >
                              <div className="flex items-start gap-3">
                                <img
                                  src={img.dataUrl}
                                  alt={img.personLabel}
                                  className="w-16 h-16 rounded-lg object-cover shrink-0 border border-white/10"
                                />
                                <div className="flex-1 min-w-0 space-y-1">
                                  <div className="flex flex-wrap items-center justify-between gap-1.5">
                                    <span className="text-[11px] font-semibold text-white truncate">
                                      {img.fileName}
                                    </span>
                                    <span
                                      className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                                        isPrimary
                                          ? 'bg-violet-600/25 text-violet-200 border border-violet-500/40'
                                          : 'bg-white/6 text-slate-300'
                                      }`}
                                    >
                                      {isPrimary
                                        ? t.workspace.primaryBadge
                                        : t.workspace.additionalBadge}
                                    </span>
                                  </div>

                                  {img.diagnostics && (
                                    <div className="text-[10px] text-slate-400 font-mono-nums">
                                      {img.diagnostics.width}×{img.diagnostics.height}px · Luma{' '}
                                      {img.diagnostics.avgBrightness}/255 · Sharp{' '}
                                      {img.diagnostics.sharpnessScore}%
                                    </div>
                                  )}

                                  <div className="flex flex-wrap items-center gap-2 pt-0.5">
                                    {!isPrimary && (
                                      <button
                                        type="button"
                                        onClick={() =>
                                          handleSetPrimaryImage(group.groupId, group.label, img.id)
                                        }
                                        className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-300 hover:text-amber-200 cursor-pointer"
                                      >
                                        <Star className="w-3 h-3" />
                                        <span>{t.workspace.setPrimaryBtn}</span>
                                      </button>
                                    )}
                                    <button
                                      type="button"
                                      onClick={() =>
                                        triggerUpload(group.groupId, group.label, 'person', img.id)
                                      }
                                      className="text-[10px] font-semibold text-blue-300 hover:text-white cursor-pointer"
                                    >
                                      {t.workspace.replaceBtn}
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteReference(img.id)}
                                      className="text-[10px] text-red-400 hover:text-red-300 cursor-pointer"
                                    >
                                      {t.common.delete}
                                    </button>
                                  </div>
                                </div>
                              </div>

                              {/* Manual Face Quality Flags */}
                              <div className="pt-1.5 border-t border-white/6 flex flex-wrap items-center gap-1.5">
                                <span className="text-[10px] text-slate-500 me-1">
                                  {t.workspace.manualFlagsTitle}
                                </span>
                                {(
                                  [
                                    { key: 'faceSmall', label: t.workspace.flagSmallFace },
                                    { key: 'faceObscured', label: t.workspace.flagObscuredFace },
                                    { key: 'angleMismatch', label: t.workspace.flagAngleMismatch },
                                  ] as const
                                ).map((flag) => {
                                  const active = Boolean(img.manualWarnings?.[flag.key]);
                                  return (
                                    <button
                                      key={flag.key}
                                      type="button"
                                      onClick={() => handleToggleManualWarning(img.id, flag.key)}
                                      className={`px-2 py-0.5 rounded-md text-[10px] border cursor-pointer transition ${
                                        active
                                          ? 'bg-amber-500/20 border-amber-500/50 text-amber-200 font-semibold'
                                          : 'bg-white/4 border-white/10 text-slate-400 hover:text-slate-200'
                                      }`}
                                    >
                                      {flag.label}
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Optional Clothing / Pose / Scene Asset References */}
            <div className="pt-2 border-t border-white/8 space-y-3">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() =>
                    triggerUpload(
                      `clothing-${Date.now()}`,
                      lang === 'ar' ? 'مرجع ملابس' : 'Clothing Ref',
                      'clothing'
                    )
                  }
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/6 hover:bg-white/12 border border-white/10 text-xs text-slate-200 cursor-pointer"
                >
                  <ImagePlus className="w-3.5 h-3.5 text-violet-300" />
                  <span>{t.workspace.uploadRoleClothing}</span>
                </button>
                <button
                  type="button"
                  onClick={() =>
                    triggerUpload(
                      `pose-${Date.now()}`,
                      lang === 'ar' ? 'مرجع وقفة' : 'Pose Ref',
                      'pose'
                    )
                  }
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/6 hover:bg-white/12 border border-white/10 text-xs text-slate-200 cursor-pointer"
                >
                  <ImagePlus className="w-3.5 h-3.5 text-blue-300" />
                  <span>{t.workspace.uploadRolePose}</span>
                </button>
                <button
                  type="button"
                  onClick={() =>
                    triggerUpload(
                      `scene-${Date.now()}`,
                      lang === 'ar' ? 'مرجع خلفية' : 'Scene Ref',
                      'scene'
                    )
                  }
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/6 hover:bg-white/12 border border-white/10 text-xs text-slate-200 cursor-pointer"
                >
                  <ImagePlus className="w-3.5 h-3.5 text-indigo-300" />
                  <span>{t.workspace.uploadRoleScene}</span>
                </button>
              </div>

              {assetRefs.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {assetRefs.map((asset) => (
                    <div
                      key={asset.id}
                      className="rounded-xl overflow-hidden border border-white/12 bg-[#090A0F]"
                    >
                      <img
                        src={asset.dataUrl}
                        alt={asset.fileName}
                        className="w-full h-24 object-cover"
                      />
                      <div className="p-2 flex items-center justify-between gap-2 text-[11px]">
                        <span className="text-slate-300 truncate">{asset.personLabel}</span>
                        <button
                          type="button"
                          onClick={() => handleDeleteReference(asset.id)}
                          className="text-red-400 hover:text-red-300 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Pre-Flight Reference Analyzer */}
            {preflightReport && (
              <div className="pt-4 border-t border-white/8 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h3 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>{t.workspace.preflightTitle}</span>
                  </h3>
                  <span className="text-[11px] font-mono-nums text-slate-400">
                    {preflightReport.totalImages}{' '}
                    {lang === 'ar' ? 'صور مرفوعة' : 'images'} · {preflightReport.personGroupCount}{' '}
                    {lang === 'ar' ? 'بطاقات أشخاص' : 'person cards'}
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-[#090A0F] border border-white/10 text-[11px] text-slate-400 flex items-start gap-2 leading-relaxed">
                  <Info className="w-3.5 h-3.5 text-blue-300 shrink-0 mt-0.5" />
                  <span>{t.workspace.preflightDisclaimer}</span>
                </div>

                {preflightReport.alerts.length === 0 ? (
                  <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-xs text-emerald-200 flex items-center gap-2">
                    <Check className="w-4 h-4 shrink-0" />
                    <span>{t.workspace.preflightOk}</span>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {preflightReport.alerts.map((alert) => (
                      <div
                        key={alert.id}
                        className={`p-3 rounded-xl border text-xs flex items-start gap-2 leading-relaxed ${
                          alert.severity === 'warning'
                            ? 'bg-amber-500/10 border-amber-500/30 text-amber-100'
                            : 'bg-blue-500/10 border-blue-500/25 text-blue-100'
                        }`}
                      >
                        <AlertTriangle
                          className={`w-4 h-4 shrink-0 mt-0.5 ${
                            alert.severity === 'warning' ? 'text-amber-300' : 'text-blue-300'
                          }`}
                        />
                        <span>{lang === 'ar' ? alert.messageAr : alert.messageEn}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            <div className="pt-2">
              <button
                type="button"
                onClick={() => void setPhase('wizard')}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 text-white text-sm font-bold cursor-pointer"
              >
                <span>{t.workspace.proceedToWizard}</span>
                <NextIcon className="w-4 h-4" />
              </button>
            </div>
          </section>
        </div>
      )}

      {/* ===================== PHASE 2: ONE-QUESTION-AT-A-TIME WIZARD ===================== */}
      {project.phase === 'wizard' && currentStep && (
        <section className="rounded-2xl bg-[#11131B] border border-white/10 p-5 sm:p-8 space-y-6">
          {/* Progress Header */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-violet-300">
                {t.workspace.wizardStepPrefix} {currentStepIdx + 1} {t.workspace.wizardOf}{' '}
                {wizardSteps.length}
              </span>
              <span className="text-slate-400">
                {lang === 'ar' ? currentStep.titleAr : currentStep.titleEn}
              </span>
            </div>
            <div className="w-full h-2 rounded-full bg-white/8 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-violet-500 to-blue-500 transition-all duration-300"
                style={{ width: `${((currentStepIdx + 1) / wizardSteps.length) * 100}%` }}
              />
            </div>
          </div>

          {/* Single Focused Question */}
          <h2 className="text-lg sm:text-xl font-bold text-white leading-snug">
            {lang === 'ar' ? currentStep.questionAr : currentStep.questionEn}
          </h2>

          {/* Options Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {currentStep.options.map((opt) => {
              const selected = isOptionSelected(opt.id);
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => handleWizardOptionSelect(opt.id)}
                  className={`text-start p-4 rounded-2xl border transition cursor-pointer space-y-1.5 ${
                    selected
                      ? 'bg-violet-500/15 border-violet-500 text-white'
                      : 'bg-[#090A0F] border-white/10 hover:border-white/25 text-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-bold">
                      {lang === 'ar' ? opt.labelAr : opt.labelEn}
                    </span>
                    {selected && <Check className="w-4 h-4 text-violet-300 shrink-0" />}
                  </div>
                  {(opt.descAr || opt.descEn) && (
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {lang === 'ar' ? opt.descAr : opt.descEn}
                    </p>
                  )}
                </button>
              );
            })}
          </div>

          {/* Google Flow & Identity Priority Configuration on Final Wizard Step */}
          {currentStep.id === 'generator' && (
            <div className="space-y-4">
              {project.wizardAnswers.targetGenerator === 'google-flow' && (
                <div className="p-4 sm:p-5 rounded-2xl bg-[#090A0F] border border-violet-500/35 space-y-4">
                  <div className="text-xs font-bold text-violet-300">
                    {t.generators.flow.title}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {(
                      [
                        { id: 'image', label: t.generators.flow.modeImage },
                        { id: 'agent', label: t.generators.flow.modeAgent },
                        { id: 'editing', label: t.generators.flow.modeEditing },
                      ] as Array<{ id: GoogleFlowMode; label: string }>
                    ).map((m) => (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => updateProjectFlowConfig({ mode: m.id })}
                        className={`p-3 rounded-xl border text-xs font-bold text-start cursor-pointer ${
                          activeFlowConfig.mode === m.id
                            ? 'bg-violet-600/20 border-violet-500 text-white'
                            : 'bg-[#11131B] border-white/10 text-slate-300'
                        }`}
                      >
                        {m.label}
                      </button>
                    ))}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-blue-300 mb-1">
                        {t.generators.flow.modelLabel}
                      </label>
                      <select
                        value={activeFlowConfig.modelChoice}
                        onChange={(e) => updateProjectFlowConfig({ modelChoice: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl bg-[#11131B] border border-white/12 text-xs text-white"
                      >
                        {settings.flowModelsCatalog.map((m) => (
                          <option key={m} value={m}>
                            {m === 'auto-available'
                              ? lang === 'ar'
                                ? 'النموذج المتاح تلقائياً'
                                : 'Auto-Available Model'
                              : m}
                          </option>
                        ))}
                        <option value="custom">
                          {lang === 'ar' ? 'نموذج مخصص...' : 'Custom model...'}
                        </option>
                      </select>
                    </div>

                    {activeFlowConfig.modelChoice === 'custom' && (
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          {t.generators.flow.customModelPlaceholder}
                        </label>
                        <input
                          type="text"
                          value={activeFlowConfig.customModelName ?? ''}
                          onChange={(e) =>
                            updateProjectFlowConfig({ customModelName: e.target.value })
                          }
                          placeholder={t.generators.flow.customModelPlaceholder}
                          className="w-full px-3 py-2 rounded-xl bg-[#11131B] border border-white/12 text-xs text-white"
                        />
                      </div>
                    )}

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                        {t.generators.flow.qualityLabel}
                      </label>
                      <select
                        value={activeFlowConfig.qualityLevel}
                        onChange={(e) =>
                          updateProjectFlowConfig({
                            qualityLevel: e.target.value as 'high' | 'ultra-crisp',
                          })
                        }
                        className="w-full px-3 py-2 rounded-xl bg-[#11131B] border border-white/12 text-xs text-white"
                      >
                        <option value="high">
                          {lang === 'ar' ? 'جودة عالية' : 'High Quality'}
                        </option>
                        <option value="ultra-crisp">
                          {lang === 'ar' ? 'تفاصيل فائقة' : 'Ultra-Crisp'}
                        </option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                        {t.generators.flow.realismLabel}
                      </label>
                      <select
                        value={activeFlowConfig.realismLevel}
                        onChange={(e) =>
                          updateProjectFlowConfig({
                            realismLevel: e.target.value as
                              | 'photorealistic'
                              | 'natural-cinematic'
                              | 'stylized-ctr',
                          })
                        }
                        className="w-full px-3 py-2 rounded-xl bg-[#11131B] border border-white/12 text-xs text-white"
                      >
                        <option value="photorealistic">
                          {lang === 'ar' ? 'فوتوغرافي واقعي' : 'Photorealistic'}
                        </option>
                        <option value="natural-cinematic">
                          {lang === 'ar' ? 'سينمائي طبيعي' : 'Natural Cinematic'}
                        </option>
                        <option value="stylized-ctr">
                          {lang === 'ar' ? 'استوديو مشبع' : 'Bold YouTube Studio'}
                        </option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* Identity Protection Mode Selector */}
              <div className="p-4 rounded-2xl bg-[#090A0F] border border-white/10 space-y-3">
                <div className="text-xs font-bold text-blue-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4" />
                  <span>{t.workspace.identityModeTitle}</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => updateIdentityMode('max-priority')}
                    className={`p-3.5 rounded-xl border text-start cursor-pointer space-y-1 ${
                      activeIdentityMode === 'max-priority'
                        ? 'bg-violet-600/20 border-violet-500 text-white'
                        : 'bg-[#11131B] border-white/10 text-slate-300'
                    }`}
                  >
                    <div className="text-xs font-bold">{t.workspace.identityMaxTitle}</div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      {t.workspace.identityMaxDesc}
                    </p>
                  </button>
                  <button
                    type="button"
                    onClick={() => updateIdentityMode('creative-transform')}
                    className={`p-3.5 rounded-xl border text-start cursor-pointer space-y-1 ${
                      activeIdentityMode === 'creative-transform'
                        ? 'bg-blue-600/20 border-blue-500 text-white'
                        : 'bg-[#11131B] border-white/10 text-slate-300'
                    }`}
                  >
                    <div className="text-xs font-bold">{t.workspace.identityCreativeTitle}</div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      {t.workspace.identityCreativeDesc}
                    </p>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Per-person Expression Overrides (if >1 person group) */}
          {currentStep.id === 'expressions' && personGroups.length > 1 && (
            <div className="p-4 rounded-2xl bg-[#090A0F] border border-white/10 space-y-3">
              <div className="text-xs font-bold text-blue-300">{t.workspace.perPersonExprTitle}</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {personGroups.map((g) => (
                  <div key={g.groupId} className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300">{g.label}</label>
                    <input
                      type="text"
                      value={project.wizardAnswers.perPersonExpressions?.[g.groupId] ?? ''}
                      onChange={(e) =>
                        onUpdateProject({
                          ...project,
                          updatedAt: Date.now(),
                          wizardAnswers: {
                            ...project.wizardAnswers,
                            perPersonExpressions: {
                              ...(project.wizardAnswers.perPersonExpressions ?? {}),
                              [g.groupId]: e.target.value,
                            },
                          },
                        })
                      }
                      placeholder={
                        lang === 'ar'
                          ? 'مثال: مصدوم وفاتح فمه / يضحك بثقة'
                          : 'e.g. wide-eyed shocked / confident smirk'
                      }
                      className="w-full px-3 py-2 rounded-xl bg-[#11131B] border border-white/10 text-xs text-white focus:outline-none focus:border-violet-500"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Custom Text Inside Thumbnail Input */}
          {currentStep.id === 'text' && project.wizardAnswers.textMode !== 'no' && (
            <div className="p-4 rounded-2xl bg-[#090A0F] border border-violet-500/30 space-y-2">
              <label className="block text-xs font-semibold text-violet-200">
                {t.workspace.customTextInputPlaceholder}
              </label>
              <input
                type="text"
                value={project.wizardAnswers.thumbnailText}
                onChange={(e) =>
                  onUpdateProject({
                    ...project,
                    updatedAt: Date.now(),
                    wizardAnswers: {
                      ...project.wizardAnswers,
                      thumbnailText: e.target.value,
                    },
                  })
                }
                placeholder={t.workspace.customTextInputPlaceholder}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#11131B] border border-white/12 text-sm text-white focus:outline-none focus:border-violet-500"
              />
            </div>
          )}

          {/* Optional Clothing Note on Elements Step */}
          {currentStep.id === 'elements' && (
            <div className="p-4 rounded-2xl bg-[#090A0F] border border-white/10 space-y-2">
              <label className="block text-xs font-semibold text-slate-300">
                {t.workspace.clothingNoteLabel}
              </label>
              <input
                type="text"
                value={project.wizardAnswers.clothingNote ?? ''}
                onChange={(e) =>
                  onUpdateProject({
                    ...project,
                    updatedAt: Date.now(),
                    wizardAnswers: {
                      ...project.wizardAnswers,
                      clothingNote: e.target.value,
                    },
                  })
                }
                placeholder={t.workspace.clothingNotePlaceholder}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#11131B] border border-white/12 text-xs text-white focus:outline-none focus:border-violet-500"
              />
            </div>
          )}

          {/* Custom Answer Box */}
          {(currentStep.id === 'concept' || currentStep.id === 'elements') && (
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-400">
                {t.workspace.customAnswerLabel}
              </label>
              <input
                type="text"
                value={
                  currentStep.id === 'concept'
                    ? project.wizardAnswers.customConceptNote ?? ''
                    : project.wizardAnswers.customElementNote ?? ''
                }
                onChange={(e) =>
                  onUpdateProject({
                    ...project,
                    updatedAt: Date.now(),
                    wizardAnswers: {
                      ...project.wizardAnswers,
                      ...(currentStep.id === 'concept'
                        ? { customConceptNote: e.target.value }
                        : { customElementNote: e.target.value }),
                    },
                  })
                }
                placeholder={t.workspace.customAnswerPlaceholder}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#090A0F] border border-white/10 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500"
              />
            </div>
          )}

          {/* Wizard Navigation */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-white/8">
            <button
              type="button"
              onClick={handleWizardBack}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/6 hover:bg-white/12 border border-white/10 text-xs font-bold text-slate-200 cursor-pointer"
            >
              <BackIcon className="w-4 h-4" />
              <span>{t.common.back}</span>
            </button>

            <div className="flex items-center gap-2.5">
              {currentStepIdx < wizardSteps.length - 1 && (
                <button
                  type="button"
                  onClick={handleWizardNext}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white/6 hover:bg-white/12 text-xs font-semibold text-slate-300 cursor-pointer"
                >
                  <SkipForward className="w-3.5 h-3.5" />
                  <span>{t.common.skip}</span>
                </button>
              )}

              <button
                type="button"
                onClick={handleWizardNext}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 text-white text-xs sm:text-sm font-bold cursor-pointer"
              >
                <span>
                  {currentStepIdx === wizardSteps.length - 1
                    ? t.workspace.generateFinalPromptBtn
                    : t.common.next}
                </span>
                <NextIcon className="w-4 h-4" />
              </button>
            </div>
          </div>
        </section>
      )}

      {/* ===================== PHASE 3: FINAL ART-DIRECTOR PROMPT SCREEN ===================== */}
      {project.phase === 'result' && project.promptResult && (
        <div className="space-y-6">
          {/* Top Action & Instant Controls Bar */}
          <div className="rounded-2xl bg-[#11131B] border border-violet-500/30 p-4 sm:p-5 space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div>
                <h2 className="text-base sm:text-lg font-bold text-white">
                  {t.workspace.resultTitle}
                </h2>
                <div className="text-xs text-violet-300 font-mono-nums mt-0.5">
                  {project.promptResult.targetGeneratorName} · 16:9 (1280×720) ·{' '}
                  {project.promptResult.identityMode === 'max-priority'
                    ? t.workspace.identityMaxTitle
                    : t.workspace.identityCreativeTitle}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={copyAllResults}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 text-white text-xs font-bold cursor-pointer whitespace-nowrap"
                >
                  {copiedKey === 'copy-all' ? (
                    <Check className="w-4 h-4" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                  <span>{copiedKey === 'copy-all' ? t.common.copied : t.workspace.copyAllBtn}</span>
                </button>

                <button
                  type="button"
                  onClick={async () => {
                    await onSavePromptToLibrary(project);
                    setSavedPromptSuccess(true);
                    setTimeout(() => setSavedPromptSuccess(false), 2200);
                  }}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white/8 hover:bg-white/14 border border-white/12 text-white text-xs font-bold cursor-pointer whitespace-nowrap"
                >
                  <BookmarkCheck className="w-4 h-4 text-emerald-400" />
                  <span>
                    {savedPromptSuccess ? t.workspace.promptSavedDone : t.workspace.savePromptBtn}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => onOpenGeneratorsTab('compare')}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/35 text-blue-200 text-xs font-bold cursor-pointer whitespace-nowrap"
                >
                  <Columns className="w-3.5 h-3.5" />
                  <span>{t.workspace.compareToolsBtn}</span>
                </button>

                <button
                  type="button"
                  onClick={() => void setPhase('wizard')}
                  className="px-3.5 py-2.5 rounded-xl bg-white/6 hover:bg-white/12 text-xs text-slate-200 font-semibold cursor-pointer whitespace-nowrap"
                >
                  {t.workspace.editPhase2Btn}
                </button>
              </div>
            </div>

            {/* Instant Generator Switcher + Identity Priority Switcher */}
            <div className="pt-3 border-t border-white/8 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[11px] text-slate-400 font-semibold">
                  {t.newProjectModal.generatorLabel}:
                </span>
                <select
                  value={project.promptResult.targetGenerator}
                  onChange={(e) => switchGeneratorInResult(e.target.value)}
                  className="px-3 py-1.5 rounded-lg bg-[#090A0F] border border-white/12 text-xs text-white focus:outline-none focus:border-violet-500"
                >
                  {allTools.map((tool) => (
                    <option key={tool.id} value={tool.id}>
                      {tool.name}
                    </option>
                  ))}
                </select>

                {project.promptResult.targetGenerator === 'google-flow' && (
                  <select
                    value={activeFlowConfig.mode}
                    onChange={(e) =>
                      updateProjectFlowConfig({ mode: e.target.value as GoogleFlowMode }, true)
                    }
                    className="px-3 py-1.5 rounded-lg bg-[#090A0F] border border-violet-500/35 text-xs text-violet-200 focus:outline-none"
                  >
                    <option value="image">Image Mode</option>
                    <option value="agent">Agent Mode</option>
                    <option value="editing">Image Editing</option>
                  </select>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => updateIdentityMode('max-priority', true)}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-bold border cursor-pointer ${
                    activeIdentityMode === 'max-priority'
                      ? 'bg-violet-600/25 border-violet-500 text-white'
                      : 'bg-[#090A0F] border-white/10 text-slate-400 hover:text-white'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-violet-300" />
                  <span>{t.workspace.identityMaxTitle}</span>
                </button>
                <button
                  type="button"
                  onClick={() => updateIdentityMode('creative-transform', true)}
                  className={`px-3 py-1.5 rounded-lg text-[11px] font-bold border cursor-pointer ${
                    activeIdentityMode === 'creative-transform'
                      ? 'bg-blue-600/25 border-blue-500 text-white'
                      : 'bg-[#090A0F] border-white/10 text-slate-400 hover:text-white'
                  }`}
                >
                  {t.workspace.identityCreativeTitle}
                </button>
              </div>
            </div>
          </div>

          {/* Section 1: Design Summary */}
          <section className="rounded-2xl bg-[#11131B] border border-white/8 p-5 space-y-3">
            <h3 className="text-sm font-bold text-violet-300 flex items-center gap-2">
              <Layers className="w-4 h-4" />
              <span>{t.workspace.sec1Summary}</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-[#090A0F] border border-white/8">
                <div className="text-slate-400 mb-1">{t.workspace.videoTitleLabel}</div>
                <div className="text-white font-semibold">
                  {project.promptResult.designSummary.ideaSummary}
                </div>
              </div>
              <div className="p-3 rounded-xl bg-[#090A0F] border border-white/8">
                <div className="text-slate-400 mb-1">{t.workspace.styleMixLabel}</div>
                <div className="text-violet-200 font-semibold">
                  {project.promptResult.designSummary.visualDirection}
                </div>
              </div>
              <div className="p-3 rounded-xl bg-[#090A0F] border border-white/8">
                <div className="text-slate-400 mb-1">{t.workspace.conceptsTitle.split(' ')[0]}</div>
                <div className="text-blue-200 font-semibold">
                  {project.promptResult.designSummary.sceneSummary}
                </div>
              </div>
              <div className="p-3 rounded-xl bg-[#090A0F] border border-white/8">
                <div className="text-slate-400 mb-1">{t.library.fields.colors}</div>
                <div className="text-slate-200 font-medium">
                  {project.promptResult.designSummary.colorsSummary}
                </div>
              </div>
              <div className="sm:col-span-2 p-3 rounded-xl bg-[#090A0F] border border-white/8">
                <div className="text-slate-400 mb-1">{t.library.fields.expressions}</div>
                <div className="text-slate-200 font-medium">
                  {project.promptResult.designSummary.expressionsSummary}
                </div>
              </div>
            </div>
          </section>

          {/* GOOGLE FLOW SPECIALIZED 6-SECTION OUTPUT (A - F) */}
          {project.promptResult.targetGenerator === 'google-flow' &&
          project.promptResult.flowSections ? (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="text-sm sm:text-base font-bold text-white">
                  {t.workspace.flowSectionsTitle}
                </h3>
                <button
                  type="button"
                  onClick={() => void copyText('flow-full', displayedMainPrompt)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold cursor-pointer"
                >
                  {copiedKey === 'flow-full' ? (
                    <Check className="w-3.5 h-3.5" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>
                    {copiedKey === 'flow-full' ? t.common.copied : t.workspace.flowCopyFullBtn}
                  </span>
                </button>
              </div>

              {/* Section A: Main Flow Prompt */}
              <section className="rounded-2xl bg-[#11131B] border border-violet-500/35 p-5 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h4 className="text-sm font-bold text-violet-300">{t.workspace.flowSecA}</h4>
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowArabicTrans((v) => !v)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-500/15 border border-blue-500/30 text-blue-200 text-xs font-semibold cursor-pointer"
                    >
                      <Languages className="w-3.5 h-3.5" />
                      <span>
                        {showArabicTrans
                          ? t.workspace.hideArabicTranslation
                          : t.workspace.showArabicTranslation}
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsEditingPrompt((v) => !v)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/8 hover:bg-white/14 text-slate-200 text-xs font-semibold cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>{t.workspace.inlineEditPrompt}</span>
                    </button>
                    {project.customEditedPrompt !== undefined && (
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateProject({
                            ...project,
                            customEditedPrompt: undefined,
                            updatedAt: Date.now(),
                          })
                        }
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/6 text-slate-300 text-xs cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>{t.workspace.resetInlineEdit}</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => void copyText('flow-sec-a', displayedMainPrompt)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold cursor-pointer"
                    >
                      {copiedKey === 'flow-sec-a' ? (
                        <Check className="w-3.5 h-3.5" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                      <span>{copiedKey === 'flow-sec-a' ? t.common.copied : t.common.copy}</span>
                    </button>
                  </div>
                </div>

                {isEditingPrompt ? (
                  <textarea
                    rows={14}
                    dir="ltr"
                    value={displayedMainPrompt}
                    onChange={(e) =>
                      onUpdateProject({
                        ...project,
                        customEditedPrompt: e.target.value,
                        updatedAt: Date.now(),
                      })
                    }
                    className="w-full p-4 rounded-xl bg-[#090A0F] border border-violet-500/50 text-xs sm:text-sm text-slate-100 font-mono leading-relaxed focus:outline-none"
                  />
                ) : (
                  <pre
                    dir="ltr"
                    className="p-4 rounded-xl bg-[#090A0F] border border-white/10 text-xs sm:text-[13px] text-slate-100 font-mono leading-relaxed whitespace-pre-wrap overflow-x-auto"
                  >
                    {displayedMainPrompt}
                  </pre>
                )}

                {showArabicTrans && (
                  <div
                    className="p-4 rounded-xl bg-blue-500/[0.06] border border-blue-500/20 space-y-2"
                    dir="rtl"
                  >
                    <div className="text-xs font-bold text-blue-300">
                      {lang === 'ar'
                        ? 'الترجمة العربية وشرح بنية البرومبت:'
                        : 'Arabic Breakdown of Prompt Structure:'}
                    </div>
                    <div className="text-xs text-slate-200 leading-relaxed whitespace-pre-line">
                      {project.promptResult.arabicTranslation}
                    </div>
                  </div>
                )}
              </section>

              {/* Sections B - E */}
              {(
                [
                  {
                    key: 'flow-sec-b',
                    title: t.workspace.flowSecB,
                    content: project.promptResult.flowSections.identityProtectionInstructions,
                    tone: 'border-blue-500/30 text-blue-300',
                    textTone: 'text-blue-100',
                  },
                  {
                    key: 'flow-sec-c',
                    title: t.workspace.flowSecC,
                    content: project.promptResult.flowSections.compositionInstructions,
                    tone: 'border-white/10 text-slate-100',
                    textTone: 'text-slate-200',
                  },
                  {
                    key: 'flow-sec-d',
                    title: t.workspace.flowSecD,
                    content: project.promptResult.flowSections.textInstructions,
                    tone: 'border-white/10 text-indigo-300',
                    textTone: 'text-slate-200',
                  },
                  {
                    key: 'flow-sec-e',
                    title: t.workspace.flowSecE,
                    content: project.promptResult.flowSections.avoidInstructions,
                    tone: 'border-rose-500/25 text-rose-300',
                    textTone: 'text-rose-200/90',
                  },
                ] as const
              ).map((sec) => (
                <section
                  key={sec.key}
                  className={`rounded-2xl bg-[#11131B] border p-5 space-y-3 ${sec.tone.split(' ')[0]}`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <h4 className={`text-sm font-bold ${sec.tone.split(' ')[1]}`}>{sec.title}</h4>
                    <button
                      type="button"
                      onClick={() => void copyText(sec.key, sec.content)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/8 hover:bg-white/14 text-white text-xs font-bold cursor-pointer"
                    >
                      {copiedKey === sec.key ? (
                        <Check className="w-3.5 h-3.5" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                      <span>{copiedKey === sec.key ? t.common.copied : t.common.copy}</span>
                    </button>
                  </div>
                  <pre
                    dir="ltr"
                    className={`p-3.5 rounded-xl bg-[#090A0F] border border-white/10 text-xs font-mono leading-relaxed whitespace-pre-wrap ${sec.textTone}`}
                  >
                    {sec.content}
                  </pre>
                </section>
              ))}

              {/* Section F: Reference Upload Guide & Google Flow Steps */}
              <section className="rounded-2xl bg-[#11131B] border border-emerald-500/30 p-5 space-y-4">
                <div className="flex items-center justify-between gap-2">
                  <h4 className="text-sm font-bold text-emerald-300">{t.workspace.flowSecF}</h4>
                  <button
                    type="button"
                    onClick={() =>
                      void copyText(
                        'flow-sec-f',
                        `${project.promptResult!.flowSections!.referenceUploadGuide}\n\n${
                          lang === 'ar'
                            ? project.promptResult!.usageInstructionsAr
                            : project.promptResult!.usageInstructionsEn
                        }`
                      )
                    }
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/8 hover:bg-white/14 text-white text-xs font-bold cursor-pointer"
                  >
                    {copiedKey === 'flow-sec-f' ? (
                      <Check className="w-3.5 h-3.5" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span>{copiedKey === 'flow-sec-f' ? t.common.copied : t.common.copy}</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="p-4 rounded-xl bg-[#090A0F] border border-white/8 space-y-2">
                    <div className="text-violet-300 font-bold">
                      {lang === 'ar' ? 'خطوات التنفيذ داخل Google Flow:' : 'Google Flow Execution Steps:'}
                    </div>
                    <div className="text-slate-200 leading-relaxed whitespace-pre-line">
                      {lang === 'ar'
                        ? project.promptResult.usageInstructionsAr
                        : project.promptResult.usageInstructionsEn}
                    </div>
                    <div className="pt-2 border-t border-white/8 text-emerald-300 font-semibold">
                      {lang === 'ar'
                        ? project.promptResult.recommendedSettingsAr
                        : project.promptResult.recommendedSettingsEn}
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-[#090A0F] border border-white/8 space-y-2">
                    <div className="text-blue-300 font-bold">{t.workspace.uploadOrderTitle}</div>
                    <div className="text-slate-200 leading-relaxed whitespace-pre-line">
                      {lang === 'ar'
                        ? project.promptResult.referenceUploadGuideAr
                        : project.promptResult.referenceUploadGuideEn}
                    </div>
                    <div
                      dir="ltr"
                      className="pt-2 border-t border-white/8 text-[11px] font-mono text-slate-400 whitespace-pre-line"
                    >
                      {project.promptResult.flowSections.referenceUploadGuide}
                    </div>
                  </div>
                </div>
              </section>
            </div>
          ) : (
            /* STANDARD TOOL-TUNED PROMPT LAYOUT (ChatGPT, Midjourney, FLUX, SD, Gemini, Nano Banana, etc.) */
            <>
              {/* Section 2: Main Prompt + Inline Edit + Arabic Translation */}
              <section className="rounded-2xl bg-[#11131B] border border-white/10 p-5 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h3 className="text-sm font-bold text-white">{t.workspace.sec2MainPrompt}</h3>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowArabicTrans((v) => !v)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-500/15 border border-blue-500/30 text-blue-200 text-xs font-semibold cursor-pointer"
                    >
                      <Languages className="w-3.5 h-3.5" />
                      <span>
                        {showArabicTrans
                          ? t.workspace.hideArabicTranslation
                          : t.workspace.showArabicTranslation}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setIsEditingPrompt((v) => !v)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/8 hover:bg-white/14 text-slate-200 text-xs font-semibold cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>{t.workspace.inlineEditPrompt}</span>
                    </button>

                    {project.customEditedPrompt !== undefined && (
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateProject({
                            ...project,
                            customEditedPrompt: undefined,
                            updatedAt: Date.now(),
                          })
                        }
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/6 text-slate-300 text-xs cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>{t.workspace.resetInlineEdit}</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => void copyText('main-prompt', displayedMainPrompt)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold cursor-pointer"
                    >
                      {copiedKey === 'main-prompt' ? (
                        <Check className="w-3.5 h-3.5" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                      <span>{copiedKey === 'main-prompt' ? t.common.copied : t.common.copy}</span>
                    </button>
                  </div>
                </div>

                {isEditingPrompt ? (
                  <textarea
                    rows={14}
                    dir="ltr"
                    value={displayedMainPrompt}
                    onChange={(e) =>
                      onUpdateProject({
                        ...project,
                        customEditedPrompt: e.target.value,
                        updatedAt: Date.now(),
                      })
                    }
                    className="w-full p-4 rounded-xl bg-[#090A0F] border border-violet-500/50 text-xs sm:text-sm text-slate-100 font-mono leading-relaxed focus:outline-none"
                  />
                ) : (
                  <pre
                    dir="ltr"
                    className="p-4 rounded-xl bg-[#090A0F] border border-white/10 text-xs sm:text-[13px] text-slate-100 font-mono leading-relaxed whitespace-pre-wrap overflow-x-auto"
                  >
                    {displayedMainPrompt}
                  </pre>
                )}

                {showArabicTrans && (
                  <div
                    className="p-4 rounded-xl bg-blue-500/[0.06] border border-blue-500/20 space-y-2"
                    dir="rtl"
                  >
                    <div className="text-xs font-bold text-blue-300">
                      {lang === 'ar'
                        ? 'الترجمة العربية وشرح بنية البرومبت:'
                        : 'Arabic Breakdown of Prompt Structure:'}
                    </div>
                    <div className="text-xs text-slate-200 leading-relaxed whitespace-pre-line">
                      {project.promptResult.arabicTranslation}
                    </div>
                  </div>
                )}
              </section>

              {/* Section 3: Separate Negative Prompt */}
              <section className="rounded-2xl bg-[#11131B] border border-white/10 p-5 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-sm font-bold text-white">{t.workspace.sec3NegativePrompt}</h3>
                  <button
                    type="button"
                    onClick={() =>
                      void copyText('negative-prompt', project.promptResult!.negativePrompt)
                    }
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-white/8 hover:bg-white/14 border border-white/12 text-white text-xs font-bold cursor-pointer"
                  >
                    {copiedKey === 'negative-prompt' ? (
                      <Check className="w-3.5 h-3.5" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span>{copiedKey === 'negative-prompt' ? t.common.copied : t.common.copy}</span>
                  </button>
                </div>

                {!project.promptResult.supportsSeparateNegative && (
                  <p className="text-[11px] text-blue-300">{t.workspace.negativeNoteIntegrated}</p>
                )}

                <pre
                  dir="ltr"
                  className="p-3.5 rounded-xl bg-[#090A0F] border border-white/10 text-xs text-rose-200/90 font-mono leading-relaxed whitespace-pre-wrap"
                >
                  {project.promptResult.negativePrompt}
                </pre>
              </section>

              {/* Section 4: Usage Instructions & Upload Order */}
              <section className="rounded-2xl bg-[#11131B] border border-white/8 p-5 space-y-4">
                <h3 className="text-sm font-bold text-white">{t.workspace.sec4UsageGuide}</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="p-4 rounded-xl bg-[#090A0F] border border-white/8 space-y-2">
                    <div className="text-violet-300 font-bold">
                      {project.promptResult.targetGeneratorName}
                    </div>
                    <div className="text-slate-200 leading-relaxed whitespace-pre-line">
                      {lang === 'ar'
                        ? project.promptResult.usageInstructionsAr
                        : project.promptResult.usageInstructionsEn}
                    </div>
                    <div className="pt-2 border-t border-white/8 text-emerald-300 font-semibold">
                      {lang === 'ar'
                        ? project.promptResult.recommendedSettingsAr
                        : project.promptResult.recommendedSettingsEn}
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-[#090A0F] border border-white/8 space-y-2">
                    <div className="text-blue-300 font-bold">{t.workspace.uploadOrderTitle}</div>
                    <div className="text-slate-200 leading-relaxed whitespace-pre-line">
                      {lang === 'ar'
                        ? project.promptResult.referenceUploadGuideAr
                        : project.promptResult.referenceUploadGuideEn}
                    </div>
                  </div>
                </div>
              </section>
            </>
          )}

          {/* Section 5: 8 Instant Refinement Actions */}
          <section className="rounded-2xl bg-[#11131B] border border-white/8 p-5 space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-violet-400" />
              <span>{t.workspace.sec5Refinements}</span>
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {(
                [
                  { id: 'variation', label: t.workspace.refinements.variation },
                  { id: 'professional', label: t.workspace.refinements.professional },
                  { id: 'comedic', label: t.workspace.refinements.comedic },
                  { id: 'stronger-expression', label: t.workspace.refinements.strongerExpression },
                  { id: 'change-colors', label: t.workspace.refinements.changeColors },
                  { id: 'change-background', label: t.workspace.refinements.changeBackground },
                  { id: 'less-elements', label: t.workspace.refinements.lessElements },
                  { id: 'more-excitement', label: t.workspace.refinements.moreExcitement },
                ] as Array<{ id: RefinementAction; label: string }>
              ).map((btn) => (
                <button
                  key={btn.id}
                  type="button"
                  onClick={() => handleRefinement(btn.id)}
                  className="py-2.5 px-3 rounded-xl bg-[#090A0F] hover:bg-violet-500/15 border border-white/10 hover:border-violet-500/40 text-xs font-semibold text-slate-200 hover:text-white transition cursor-pointer"
                >
                  {btn.label}
                </button>
              ))}
            </div>
          </section>
        </div>
      )}
    </div>
  );
};
