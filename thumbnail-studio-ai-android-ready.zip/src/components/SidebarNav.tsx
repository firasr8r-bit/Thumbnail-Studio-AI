import React from 'react';
import {
  BookmarkCheck,
  Cpu,
  FolderKanban,
  Home,
  Languages,
  Palette,
  Plus,
  Settings,
  Sparkles,
  Wand2,
} from 'lucide-react';
import type { Language, NavSection } from '../types/architect';
import { getT } from '../i18n/translations';

interface SidebarNavProps {
  activeSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  onNewProject: () => void;
  lang: Language;
  onToggleLanguage: () => void;
  hasActiveProject: boolean;
  projectsCount: number;
  savedPromptsCount: number;
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  activeSection,
  onSelectSection,
  onNewProject,
  lang,
  onToggleLanguage,
  hasActiveProject,
  projectsCount,
  savedPromptsCount,
}) => {
  const t = getT(lang);

  const navItems: Array<{
    id: NavSection;
    label: string;
    icon: React.ReactNode;
    badge?: number | string;
  }> = [
    { id: 'dashboard', label: t.nav.dashboard, icon: <Home className="w-4 h-4" /> },
    {
      id: 'workspace',
      label: t.nav.workspace,
      icon: <Wand2 className="w-4 h-4" />,
      badge: hasActiveProject ? (lang === 'ar' ? 'نشط' : 'Active') : undefined,
    },
    {
      id: 'generators',
      label: t.nav.generators,
      icon: <Cpu className="w-4 h-4" />,
    },
    {
      id: 'library',
      label: t.nav.library,
      icon: <Palette className="w-4 h-4" />,
    },
    {
      id: 'projects',
      label: t.nav.projects,
      icon: <FolderKanban className="w-4 h-4" />,
      badge: projectsCount > 0 ? projectsCount : undefined,
    },
    {
      id: 'saved-prompts',
      label: t.nav.savedPrompts,
      icon: <BookmarkCheck className="w-4 h-4" />,
      badge: savedPromptsCount > 0 ? savedPromptsCount : undefined,
    },
    { id: 'settings', label: t.nav.settings, icon: <Settings className="w-4 h-4" /> },
  ];

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-72 shrink-0 bg-[#11131B] border-e border-white/8 min-h-screen p-4 justify-between">
        <div className="space-y-6">
          {/* Brand */}
          <div className="flex items-center gap-3 px-2 pt-1">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-blue-500 flex items-center justify-center shadow-lg shadow-violet-500/20 shrink-0">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div className="min-w-0">
              <div className="text-sm font-bold text-white truncate">{t.appName}</div>
              <div className="text-[11px] text-slate-400 truncate">{t.appTagline}</div>
            </div>
          </div>

          {/* Primary CTA */}
          <button
            type="button"
            onClick={onNewProject}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 text-white text-sm font-bold shadow-lg shadow-violet-600/20 transition cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>{t.common.newProject}</span>
          </button>

          {/* Navigation Links */}
          <nav className="space-y-1">
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onSelectSection(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition cursor-pointer ${
                    isActive
                      ? 'bg-violet-500/15 text-violet-200 border border-violet-500/30'
                      : 'text-slate-300 hover:bg-white/5 hover:text-white border border-transparent'
                  }`}
                >
                  <span className="flex items-center gap-3 min-w-0">
                    <span className={isActive ? 'text-violet-400' : 'text-slate-400'}>
                      {item.icon}
                    </span>
                    <span className="truncate">{item.label}</span>
                  </span>
                  {item.badge !== undefined && (
                    <span className="text-[11px] text-slate-400 font-mono-nums shrink-0">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Language Toggle & Note */}
        <div className="space-y-3 pt-4 border-t border-white/8">
          <div className="px-3 py-2.5 rounded-xl bg-white/[0.03] border border-white/6 text-[11px] text-slate-400 leading-relaxed">
            <div className="font-semibold text-blue-300 mb-0.5">{t.common.offlineReady}</div>
            <div>{t.common.noImageGenNote}</div>
          </div>

          <button
            type="button"
            onClick={onToggleLanguage}
            className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-200 text-xs font-medium border border-white/8 transition cursor-pointer"
          >
            <span className="flex items-center gap-2">
              <Languages className="w-4 h-4 text-blue-400" />
              <span>{lang === 'ar' ? 'العربية (RTL)' : 'English (LTR)'}</span>
            </span>
            <span className="text-violet-300 font-semibold">
              {lang === 'ar' ? 'EN' : 'AR'}
            </span>
          </button>
        </div>
      </aside>

      {/* Mobile Top Header + Bottom Bar */}
      <header className="lg:hidden sticky top-0 z-30 bg-[#11131B]/95 backdrop-blur border-b border-white/8 px-3 py-2.5 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-blue-500 flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <span className="text-sm font-bold text-white truncate">{t.appName}</span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onToggleLanguage}
            className="px-2.5 py-1.5 rounded-lg bg-white/6 text-xs font-semibold text-slate-200 border border-white/10 cursor-pointer"
          >
            {lang === 'ar' ? 'EN' : 'AR'}
          </button>
          <button
            type="button"
            onClick={onNewProject}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-gradient-to-r from-violet-600 to-blue-600 text-white text-xs font-bold cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{lang === 'ar' ? 'جديد' : 'New'}</span>
          </button>
        </div>
      </header>

      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-30 bg-[#11131B]/95 backdrop-blur border-t border-white/10 px-1 py-1.5 grid grid-cols-7 gap-0.5">
        {navItems.map((item) => {
          const isActive = activeSection === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectSection(item.id)}
              className={`flex flex-col items-center justify-center gap-1 py-1.5 px-0.5 rounded-lg text-[10px] font-medium transition cursor-pointer ${
                isActive ? 'text-violet-300 bg-violet-500/15' : 'text-slate-400'
              }`}
            >
              {item.icon}
              <span className="truncate max-w-full">{item.label.split(' ')[0]}</span>
            </button>
          );
        })}
      </nav>
    </>
  );
};
