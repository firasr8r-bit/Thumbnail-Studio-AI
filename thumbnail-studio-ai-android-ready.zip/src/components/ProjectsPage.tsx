import React, { useState } from 'react';
import { Copy, Edit3, FolderKanban, Plus, Trash2 } from 'lucide-react';
import { buildStyleSummaryLabel } from '../engine/localArchitectEngine';
import { getT } from '../i18n/translations';
import type { ArchitectProject, Language } from '../types/architect';

interface ProjectsPageProps {
  lang: Language;
  projects: ArchitectProject[];
  activeProjectId: string | null;
  onNewProject: () => void;
  onOpenProject: (id: string) => void;
  onRenameProject: (id: string, newName: string) => void;
  onDuplicateProject: (id: string) => void;
  onDeleteProject: (id: string) => void;
}

export const ProjectsPage: React.FC<ProjectsPageProps> = ({
  lang,
  projects,
  activeProjectId,
  onNewProject,
  onOpenProject,
  onRenameProject,
  onDuplicateProject,
  onDeleteProject,
}) => {
  const t = getT(lang);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const startRename = (proj: ArchitectProject) => {
    setEditingId(proj.id);
    setEditValue(proj.name);
  };

  const commitRename = (id: string) => {
    if (editValue.trim()) {
      onRenameProject(id, editValue.trim());
    }
    setEditingId(null);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20 lg:pb-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">{t.projects.title}</h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">{t.projects.subtitle}</p>
        </div>
        <button
          type="button"
          onClick={onNewProject}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 text-white text-xs font-bold cursor-pointer self-start"
        >
          <Plus className="w-4 h-4" />
          <span>{t.common.newProject}</span>
        </button>
      </div>

      {projects.length === 0 ? (
        <div className="rounded-2xl bg-[#11131B] border border-dashed border-white/12 p-10 text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-white/5 text-slate-400 flex items-center justify-center mx-auto">
            <FolderKanban className="w-6 h-6" />
          </div>
          <h2 className="text-base font-bold text-white">{t.projects.emptyTitle}</h2>
          <p className="text-xs text-slate-400 max-w-md mx-auto">{t.projects.emptyDesc}</p>
          <button
            type="button"
            onClick={onNewProject}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{t.common.newProject}</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {projects.map((proj) => {
            const isActive = proj.id === activeProjectId;
            const styleLabel = buildStyleSummaryLabel(
              proj.selectedCreatorIds,
              proj.selectedGeneralIds,
              lang
            );

            return (
              <div
                key={proj.id}
                className={`rounded-2xl p-5 border flex flex-col justify-between gap-4 transition ${
                  isActive
                    ? 'bg-violet-500/10 border-violet-500/45'
                    : 'bg-[#11131B] border-white/8 hover:border-white/18'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] px-2.5 py-0.5 rounded-md bg-blue-500/15 text-blue-300 font-semibold">
                      {t.projects.phaseLabels[proj.phase]}
                    </span>
                    <span className="text-[11px] text-slate-500 font-mono-nums">
                      {new Date(proj.updatedAt).toLocaleDateString(
                        lang === 'ar' ? 'ar' : 'en-US'
                      )}
                    </span>
                  </div>

                  {editingId === proj.id ? (
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        commitRename(proj.id);
                      }}
                      className="flex items-center gap-2"
                    >
                      <input
                        type="text"
                        autoFocus
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        onBlur={() => commitRename(proj.id)}
                        className="flex-1 px-2.5 py-1.5 rounded-lg bg-[#090A0F] border border-violet-500 text-sm text-white focus:outline-none"
                      />
                    </form>
                  ) : (
                    <h3 className="text-base font-bold text-white truncate">{proj.name}</h3>
                  )}

                  {proj.ideaInputs.videoTitle && (
                    <p className="text-xs text-slate-300 line-clamp-2">
                      {proj.ideaInputs.videoTitle}
                    </p>
                  )}

                  <div className="text-[11px] text-slate-400 truncate">{styleLabel}</div>

                  {proj.referenceImages.length > 0 && (
                    <div className="flex items-center gap-1.5 pt-1">
                      {proj.referenceImages.slice(0, 4).map((ref) => (
                        <img
                          key={ref.id}
                          src={ref.dataUrl}
                          alt={ref.personLabel}
                          className="w-8 h-8 rounded-lg object-cover border border-white/15"
                        />
                      ))}
                      {proj.referenceImages.length > 4 && (
                        <span className="text-[11px] text-slate-400">
                          +{proj.referenceImages.length - 4}
                        </span>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between gap-2 pt-3 border-t border-white/8">
                  <button
                    type="button"
                    onClick={() => onOpenProject(proj.id)}
                    className="flex-1 py-2 px-3 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold cursor-pointer"
                  >
                    {t.common.continueWork}
                  </button>

                  <button
                    type="button"
                    onClick={() => startRename(proj)}
                    title={t.common.rename}
                    className="p-2 rounded-xl bg-white/6 hover:bg-white/12 text-slate-300 cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    type="button"
                    onClick={() => onDuplicateProject(proj.id)}
                    title={t.common.duplicate}
                    className="p-2 rounded-xl bg-white/6 hover:bg-white/12 text-slate-300 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>

                  {confirmDeleteId === proj.id ? (
                    <button
                      type="button"
                      onClick={() => {
                        onDeleteProject(proj.id);
                        setConfirmDeleteId(null);
                      }}
                      className="px-2.5 py-2 rounded-xl bg-red-600 text-white text-[11px] font-bold cursor-pointer"
                    >
                      {t.common.delete}
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteId(proj.id)}
                      title={t.common.delete}
                      className="p-2 rounded-xl bg-white/6 hover:bg-red-500/20 text-slate-300 hover:text-red-300 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
