import React from 'react';
import {
  ArrowLeft,
  ArrowRight,
  BookmarkCheck,
  Cpu,
  FolderKanban,
  Palette,
  Plus,
  Settings,
  Sparkles,
  Wand2,
} from 'lucide-react';
import type { ArchitectProject, Language, NavSection } from '../types/architect';
import { getT } from '../i18n/translations';

interface HomePageProps {
  lang: Language;
  projects: ArchitectProject[];
  savedPromptsCount: number;
  onNewProject: () => void;
  onOpenProject: (id: string) => void;
  onNavigate: (section: NavSection) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  lang,
  projects,
  savedPromptsCount,
  onNewProject,
  onOpenProject,
  onNavigate,
}) => {
  const t = getT(lang);
  const ArrowIcon = lang === 'ar' ? ArrowLeft : ArrowRight;

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-20 lg:pb-8">
      {/* Studio Hero Banner */}
      <section className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#131624] via-[#11131B] to-[#0D101B] border border-white/10 p-6 sm:p-8">
        <div className="absolute -top-24 -end-24 w-72 h-72 rounded-full bg-violet-600/15 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -start-24 w-72 h-72 rounded-full bg-blue-600/15 blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="text-xs font-semibold text-violet-300">{t.home.heroBadge}</div>

          <h1 className="text-2xl sm:text-3xl font-bold text-white leading-snug">
            {t.home.heroTitle}
          </h1>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            {t.home.heroSubtitle}
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              type="button"
              onClick={onNewProject}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 text-white text-sm font-bold shadow-lg shadow-violet-600/25 transition cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{t.home.startBtn.replace('+ ', '')}</span>
            </button>

            <button
              type="button"
              onClick={() => onNavigate('generators')}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-white/8 hover:bg-white/14 border border-violet-500/35 text-slate-100 text-sm font-semibold transition cursor-pointer"
            >
              <Cpu className="w-4 h-4 text-violet-300" />
              <span>{t.home.exploreToolsBtn}</span>
            </button>

            <button
              type="button"
              onClick={() => onNavigate('library')}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-white/6 hover:bg-white/10 border border-white/12 text-slate-100 text-sm font-semibold transition cursor-pointer"
            >
              <Palette className="w-4 h-4 text-blue-400" />
              <span>{t.home.exploreLibBtn}</span>
            </button>
          </div>
        </div>
      </section>

      {/* Quick Navigation Cards */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <button
          type="button"
          onClick={() => onNavigate('projects')}
          className="text-start p-5 rounded-2xl bg-[#11131B] hover:bg-[#151824] border border-white/8 hover:border-violet-500/35 transition cursor-pointer"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-violet-500/15 text-violet-400 flex items-center justify-center">
              <FolderKanban className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono-nums text-slate-400">{projects.length}</span>
          </div>
          <h3 className="text-sm font-bold text-white mb-1">{t.home.cards.projectsTitle}</h3>
          <p className="text-xs text-slate-400 leading-relaxed">{t.home.cards.projectsDesc}</p>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('generators')}
          className="text-start p-5 rounded-2xl bg-[#11131B] hover:bg-[#151824] border border-white/8 hover:border-violet-500/35 transition cursor-pointer"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-violet-500/15 text-violet-300 flex items-center justify-center">
              <Cpu className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono-nums text-slate-400">13+</span>
          </div>
          <h3 className="text-sm font-bold text-white mb-1">{t.home.cards.generatorsTitle}</h3>
          <p className="text-xs text-slate-400 leading-relaxed">{t.home.cards.generatorsDesc}</p>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('library')}
          className="text-start p-5 rounded-2xl bg-[#11131B] hover:bg-[#151824] border border-white/8 hover:border-blue-500/35 transition cursor-pointer"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/15 text-blue-400 flex items-center justify-center">
              <Palette className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono-nums text-slate-400">31</span>
          </div>
          <h3 className="text-sm font-bold text-white mb-1">{t.home.cards.libraryTitle}</h3>
          <p className="text-xs text-slate-400 leading-relaxed">{t.home.cards.libraryDesc}</p>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('saved-prompts')}
          className="text-start p-5 rounded-2xl bg-[#11131B] hover:bg-[#151824] border border-white/8 hover:border-violet-500/35 transition cursor-pointer"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/15 text-indigo-400 flex items-center justify-center">
              <BookmarkCheck className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono-nums text-slate-400">{savedPromptsCount}</span>
          </div>
          <h3 className="text-sm font-bold text-white mb-1">{t.home.cards.savedTitle}</h3>
          <p className="text-xs text-slate-400 leading-relaxed">{t.home.cards.savedDesc}</p>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('settings')}
          className="text-start p-5 rounded-2xl bg-[#11131B] hover:bg-[#151824] border border-white/8 hover:border-blue-500/35 transition cursor-pointer"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-slate-500/15 text-slate-300 flex items-center justify-center">
              <Settings className="w-5 h-5" />
            </div>
          </div>
          <h3 className="text-sm font-bold text-white mb-1">{t.home.cards.settingsTitle}</h3>
          <p className="text-xs text-slate-400 leading-relaxed">{t.home.cards.settingsDesc}</p>
        </button>
      </section>

      {/* Clean Empty State vs Recent Projects */}
      {projects.length === 0 ? (
        <section className="rounded-2xl bg-[#11131B] border border-dashed border-white/12 p-8 text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-violet-500/15 border border-violet-500/25 text-violet-300 flex items-center justify-center mx-auto">
            <Wand2 className="w-6 h-6" />
          </div>
          <h2 className="text-base font-bold text-white">{t.home.emptyWorkspaceTitle}</h2>
          <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto leading-relaxed">
            {t.home.emptyWorkspaceDesc}
          </p>
          <div className="pt-2">
            <button
              type="button"
              onClick={onNewProject}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold transition cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>{t.common.newProject}</span>
            </button>
          </div>
        </section>
      ) : (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white">{t.home.recentProjectsTitle}</h2>
            <button
              type="button"
              onClick={() => onNavigate('projects')}
              className="inline-flex items-center gap-1 text-xs font-semibold text-violet-300 hover:text-violet-200 cursor-pointer"
            >
              <span>{t.home.viewAllProjects}</span>
              <ArrowIcon className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {projects.slice(0, 3).map((proj) => (
              <div
                key={proj.id}
                onClick={() => onOpenProject(proj.id)}
                className="p-4 rounded-2xl bg-[#11131B] hover:bg-[#151824] border border-white/8 hover:border-violet-500/35 transition cursor-pointer space-y-2"
              >
                <div className="flex items-center justify-between gap-2 text-[11px] text-slate-400">
                  <span className="text-violet-300 font-semibold">
                    {t.projects.phaseLabels[proj.phase]}
                  </span>
                  <span className="font-mono-nums">
                    {new Date(proj.updatedAt).toLocaleDateString(lang === 'ar' ? 'ar' : 'en-US')}
                  </span>
                </div>
                <h3 className="text-sm font-bold text-white truncate">{proj.name}</h3>
                <p className="text-xs text-slate-400 line-clamp-2">
                  {proj.ideaInputs.videoTitle || proj.ideaInputs.ideaDescription || t.common.continueWork}
                </p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 3-Phase Architecture Summary */}
      <section className="space-y-4">
        <h2 className="text-base font-bold text-white">{t.home.workflowTitle}</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-5 rounded-2xl bg-[#11131B] border border-white/8 space-y-2">
            <div className="text-xs font-bold text-violet-400">{t.home.step1Title}</div>
            <p className="text-xs text-slate-300 leading-relaxed">{t.home.step1Desc}</p>
          </div>
          <div className="p-5 rounded-2xl bg-[#11131B] border border-white/8 space-y-2">
            <div className="text-xs font-bold text-blue-400">{t.home.step2Title}</div>
            <p className="text-xs text-slate-300 leading-relaxed">{t.home.step2Desc}</p>
          </div>
          <div className="p-5 rounded-2xl bg-[#11131B] border border-white/8 space-y-2">
            <div className="text-xs font-bold text-indigo-400">{t.home.step3Title}</div>
            <p className="text-xs text-slate-300 leading-relaxed">{t.home.step3Desc}</p>
          </div>
        </div>
      </section>
    </div>
  );
};
