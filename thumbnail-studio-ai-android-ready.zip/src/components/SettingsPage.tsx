import React, { useEffect, useState } from 'react';
import {
  Check,
  Cpu,
  FileText,
  Globe,
  Image,
  Plus,
  Save,
  ShieldCheck,
  Sliders,
  Trash2,
} from 'lucide-react';
import { getAllGeneratorTools } from '../data/externalGenerators';
import { getT } from '../i18n/translations';
import { getOptionalArchitectStatus, type ServerArchitectStatus } from '../services/architectClient';
import type {
  AppSettings,
  CustomPromptTemplate,
  GoogleFlowMode,
  IdentityMode,
  Language,
  NavSection,
} from '../types/architect';

interface SettingsPageProps {
  settings: AppSettings;
  onUpdateSettings: (next: AppSettings) => void;
  onClearAllData: () => Promise<void>;
  onNavigate?: (section: NavSection) => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  settings,
  onUpdateSettings,
  onClearAllData,
  onNavigate,
}) => {
  const lang = settings.language;
  const t = getT(lang);
  const isAr = lang === 'ar';

  const [serverStatus, setServerStatus] = useState<ServerArchitectStatus | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);
  const [clearedBanner, setClearedBanner] = useState(false);
  const [newFlowModel, setNewFlowModel] = useState('');
  const [tplName, setTplName] = useState('');
  const [tplToolId, setTplToolId] = useState<string>('google-flow');
  const [tplBody, setTplBody] = useState('');

  useEffect(() => {
    void getOptionalArchitectStatus().then(setServerStatus);
  }, []);

  const allTools = getAllGeneratorTools(settings);

  const handleLanguageChange = (nextLang: Language) => {
    onUpdateSettings({ ...settings, language: nextLang });
  };

  const addFlowModel = () => {
    const clean = newFlowModel.trim();
    if (!clean || settings.flowModelsCatalog.includes(clean)) return;
    onUpdateSettings({
      ...settings,
      flowModelsCatalog: [...settings.flowModelsCatalog, clean],
    });
    setNewFlowModel('');
  };

  const removeFlowModel = (model: string) => {
    if (model === 'auto-available') return;
    const nextList = settings.flowModelsCatalog.filter((m) => m !== model);
    onUpdateSettings({
      ...settings,
      flowModelsCatalog: nextList,
      googleFlowDefaults: {
        ...settings.googleFlowDefaults,
        modelChoice:
          settings.googleFlowDefaults.modelChoice === model
            ? 'auto-available'
            : settings.googleFlowDefaults.modelChoice,
      },
    });
  };

  const handleAddTemplate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tplName.trim() || !tplBody.trim()) return;
    const item: CustomPromptTemplate = {
      id: `tpl-${Date.now()}`,
      name: tplName.trim(),
      toolId: tplToolId,
      template: tplBody.trim(),
      createdAt: Date.now(),
    };
    onUpdateSettings({
      ...settings,
      promptTemplates: [item, ...settings.promptTemplates],
    });
    setTplName('');
    setTplBody('');
  };

  const deleteTemplate = (id: string) => {
    onUpdateSettings({
      ...settings,
      promptTemplates: settings.promptTemplates.filter((x) => x.id !== id),
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20 lg:pb-8">
      <div>
        <h1 className="text-2xl font-bold text-white">{t.settings.title}</h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">{t.settings.subtitle}</p>
      </div>

      {/* 1. Language Switcher */}
      <section className="rounded-2xl bg-[#11131B] border border-white/8 p-5 space-y-4">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-blue-500/15 text-blue-400 flex items-center justify-center shrink-0">
            <Globe className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white">{t.settings.languageLabel}</h2>
            <p className="text-xs text-slate-400 mt-0.5">{t.settings.languageDesc}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => handleLanguageChange('ar')}
            className={`py-2.5 px-4 rounded-xl text-xs font-bold border transition cursor-pointer ${
              lang === 'ar'
                ? 'bg-violet-600 border-violet-500 text-white'
                : 'bg-[#090A0F] border-white/10 text-slate-300 hover:bg-white/5'
            }`}
          >
            العربية (RTL)
          </button>
          <button
            type="button"
            onClick={() => handleLanguageChange('en')}
            className={`py-2.5 px-4 rounded-xl text-xs font-bold border transition cursor-pointer ${
              lang === 'en'
                ? 'bg-violet-600 border-violet-500 text-white'
                : 'bg-[#090A0F] border-white/10 text-slate-300 hover:bg-white/5'
            }`}
          >
            English (LTR)
          </button>
        </div>
      </section>

      {/* 2. External AI Tools & Default Generator */}
      <section className="rounded-2xl bg-[#11131B] border border-white/8 p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <Cpu className="w-4 h-4 text-violet-400" />
            <h2 className="text-sm font-bold text-white">
              {t.settings.tabs.externalTools} & {t.settings.tabs.defaultGen}
            </h2>
          </div>
          {onNavigate && (
            <button
              type="button"
              onClick={() => onNavigate('generators')}
              className="px-3 py-1.5 rounded-lg bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold cursor-pointer"
            >
              {t.generators.tabLibrary}
            </button>
          )}
        </div>
        <p className="text-xs text-slate-400">{t.settings.defaultGeneratorDesc}</p>
        <select
          value={settings.defaultGenerator}
          onChange={(e) =>
            onUpdateSettings({
              ...settings,
              defaultGenerator: e.target.value,
            })
          }
          className="w-full px-3.5 py-2.5 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white focus:outline-none focus:border-violet-500"
        >
          {allTools.map((g) => (
            <option key={g.id} value={g.id}>
              {g.name}
            </option>
          ))}
        </select>
      </section>

      {/* 3. Google Flow Settings */}
      <section className="rounded-2xl bg-[#11131B] border border-violet-500/30 p-5 space-y-4">
        <div className="flex items-center gap-2.5">
          <Sliders className="w-4 h-4 text-violet-400" />
          <h2 className="text-sm font-bold text-white">{t.settings.tabs.flowSettings}</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {t.generators.flow.modeLabel}
            </label>
            <select
              value={settings.googleFlowDefaults.mode}
              onChange={(e) =>
                onUpdateSettings({
                  ...settings,
                  googleFlowDefaults: {
                    ...settings.googleFlowDefaults,
                    mode: e.target.value as GoogleFlowMode,
                  },
                })
              }
              className="w-full px-3 py-2.5 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white"
            >
              <option value="image">{t.generators.flow.modeImage}</option>
              <option value="agent">{t.generators.flow.modeAgent}</option>
              <option value="editing">{t.generators.flow.modeEditing}</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {t.generators.flow.modelLabel}
            </label>
            <select
              value={settings.googleFlowDefaults.modelChoice}
              onChange={(e) =>
                onUpdateSettings({
                  ...settings,
                  googleFlowDefaults: {
                    ...settings.googleFlowDefaults,
                    modelChoice: e.target.value,
                  },
                })
              }
              className="w-full px-3 py-2.5 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white"
            >
              {settings.flowModelsCatalog.map((m) => (
                <option key={m} value={m}>
                  {m === 'auto-available'
                    ? isAr
                      ? 'عام متوافق (النموذج المتاح)'
                      : 'General Compatible (Available Model)'
                    : m}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="space-y-2 pt-2 border-t border-white/8">
          <label className="block text-xs font-semibold text-slate-300">
            {t.settings.flowModelsManageTitle}
          </label>
          <div className="flex flex-wrap gap-2">
            {settings.flowModelsCatalog.map((model) => (
              <span
                key={model}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#090A0F] border border-white/10 text-xs text-slate-200"
              >
                <span>{model}</span>
                {model !== 'auto-available' && (
                  <button
                    type="button"
                    onClick={() => removeFlowModel(model)}
                    className="text-red-400 hover:text-red-300 cursor-pointer"
                  >
                    ×
                  </button>
                )}
              </span>
            ))}
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              value={newFlowModel}
              onChange={(e) => setNewFlowModel(e.target.value)}
              placeholder={t.settings.addFlowModelPlaceholder}
              className="flex-1 px-3 py-2 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white focus:outline-none focus:border-violet-500"
            />
            <button
              type="button"
              onClick={addFlowModel}
              className="px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold cursor-pointer"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* 4. Identity Protection & 5. Reference Images */}
      <section className="rounded-2xl bg-[#11131B] border border-white/8 p-5 space-y-5">
        <div className="space-y-3">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-4 h-4 text-blue-400" />
            <h2 className="text-sm font-bold text-white">{t.settings.tabs.identity}</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {(
              [
                {
                  id: 'max-priority',
                  title: t.workspace.identityMaxTitle,
                  desc: t.workspace.identityMaxDesc,
                },
                {
                  id: 'creative-transform',
                  title: t.workspace.identityCreativeTitle,
                  desc: t.workspace.identityCreativeDesc,
                },
              ] as Array<{ id: IdentityMode; title: string; desc: string }>
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => onUpdateSettings({ ...settings, defaultIdentityMode: opt.id })}
                className={`text-start p-3.5 rounded-xl border cursor-pointer space-y-1 ${
                  settings.defaultIdentityMode === opt.id
                    ? 'bg-violet-500/15 border-violet-500 text-white'
                    : 'bg-[#090A0F] border-white/10 text-slate-300'
                }`}
              >
                <div className="text-xs font-bold">{opt.title}</div>
                <p className="text-[11px] text-slate-400 leading-relaxed">{opt.desc}</p>
              </button>
            ))}
          </div>
        </div>

        <div className="pt-4 border-t border-white/8 space-y-2">
          <div className="flex items-center gap-2">
            <Image className="w-4 h-4 text-violet-400" />
            <h2 className="text-sm font-bold text-white">{t.settings.tabs.references}</h2>
          </div>
          <label className="block text-xs text-slate-400">{t.settings.refMinResTitle}</label>
          <input
            type="number"
            min={240}
            max={2048}
            step={40}
            value={settings.referenceMinResolution}
            onChange={(e) =>
              onUpdateSettings({
                ...settings,
                referenceMinResolution: Math.max(240, Number(e.target.value) || 480),
              })
            }
            className="w-40 px-3 py-2 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white font-mono-nums"
          />
        </div>
      </section>

      {/* 6. Prompt Templates */}
      <section className="rounded-2xl bg-[#11131B] border border-white/8 p-5 space-y-4">
        <div className="flex items-center gap-2.5">
          <FileText className="w-4 h-4 text-violet-400" />
          <h2 className="text-sm font-bold text-white">{t.settings.tabs.templates}</h2>
        </div>

        <form onSubmit={handleAddTemplate} className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              type="text"
              value={tplName}
              onChange={(e) => setTplName(e.target.value)}
              placeholder={isAr ? 'اسم القالب...' : 'Template name...'}
              className="px-3 py-2 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white"
            />
            <select
              value={tplToolId}
              onChange={(e) => setTplToolId(e.target.value)}
              className="px-3 py-2 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white"
            >
              {allTools.map((tool) => (
                <option key={tool.id} value={tool.id}>
                  {tool.name}
                </option>
              ))}
            </select>
          </div>
          <textarea
            rows={3}
            dir="ltr"
            value={tplBody}
            onChange={(e) => setTplBody(e.target.value)}
            placeholder="Use placeholders: {SCENE}, {IDENTITY}, {POSE}, {EXPRESSION}, {BACKGROUND}, {COLORS}, {TEXT}, {ELEMENTS}, {STYLE}"
            className="w-full p-3 rounded-xl bg-[#090A0F] border border-white/12 text-xs text-white font-mono"
          />
          <button
            type="submit"
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold cursor-pointer"
          >
            {t.common.save}
          </button>
        </form>

        {settings.promptTemplates.length > 0 && (
          <div className="space-y-2 pt-2">
            {settings.promptTemplates.map((tpl) => (
              <div
                key={tpl.id}
                className="p-3 rounded-xl bg-[#090A0F] border border-white/8 flex items-center justify-between gap-3 text-xs"
              >
                <div className="min-w-0">
                  <div className="font-bold text-white">{tpl.name}</div>
                  <div className="text-[11px] text-violet-300 font-mono-nums">{tpl.toolId}</div>
                </div>
                <button
                  type="button"
                  onClick={() => deleteTemplate(tpl.id)}
                  className="p-1.5 rounded-lg text-red-400 hover:bg-red-500/20 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Auto Save & Optional Server Text Engine */}
      <section className="rounded-2xl bg-[#11131B] border border-white/8 p-5 space-y-5">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-violet-500/15 text-violet-400 flex items-center justify-center shrink-0">
              <Save className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">{t.settings.autoSaveLabel}</h2>
              <p className="text-xs text-slate-400 mt-0.5">{t.settings.autoSaveDesc}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() =>
              onUpdateSettings({ ...settings, autoSaveEnabled: !settings.autoSaveEnabled })
            }
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
              settings.autoSaveEnabled ? 'bg-violet-600 text-white' : 'bg-white/8 text-slate-400'
            }`}
          >
            {settings.autoSaveEnabled ? (isAr ? 'مفعّل' : 'ON') : 'OFF'}
          </button>
        </div>

        <div className="pt-4 border-t border-white/8 space-y-3">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-blue-500/15 text-blue-400 flex items-center justify-center shrink-0">
                <Cpu className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-sm font-bold text-white">{t.settings.optionalServerAiLabel}</h2>
                <p className="text-xs text-slate-400 mt-0.5">{t.settings.optionalServerAiDesc}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() =>
                onUpdateSettings({
                  ...settings,
                  useOptionalServerAI: !settings.useOptionalServerAI,
                })
              }
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                settings.useOptionalServerAI
                  ? 'bg-blue-600 text-white'
                  : 'bg-white/8 text-slate-400'
              }`}
            >
              {settings.useOptionalServerAI ? (isAr ? 'مفعّل' : 'ON') : 'OFF'}
            </button>
          </div>

          <div className="px-3.5 py-2.5 rounded-xl bg-[#090A0F] border border-white/8 text-xs text-slate-300 flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              {serverStatus?.hasRuntimeTextModel
                ? t.settings.serverStatusReady
                : t.settings.serverStatusLocal}
            </span>
          </div>
        </div>
      </section>

      {/* Clear Local Data */}
      <section className="rounded-2xl bg-[#11131B] border border-red-500/20 p-5 space-y-3">
        <h2 className="text-sm font-bold text-red-300">{t.settings.dangerZoneTitle}</h2>
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={async () => {
              if (!confirmClear) {
                setConfirmClear(true);
                return;
              }
              await onClearAllData();
              setConfirmClear(false);
              setClearedBanner(true);
              setTimeout(() => setClearedBanner(false), 2500);
            }}
            className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold cursor-pointer ${
              confirmClear
                ? 'bg-red-600 text-white'
                : 'bg-red-500/15 hover:bg-red-500/25 border border-red-500/30 text-red-300'
            }`}
          >
            <Trash2 className="w-4 h-4" />
            <span>{confirmClear ? t.settings.clearDataConfirm : t.settings.clearDataBtn}</span>
          </button>

          {confirmClear && (
            <button
              type="button"
              onClick={() => setConfirmClear(false)}
              className="px-3 py-2 rounded-xl bg-white/6 text-xs text-slate-300 cursor-pointer"
            >
              {t.common.cancel}
            </button>
          )}
        </div>
        {clearedBanner && (
          <div className="text-xs text-emerald-400 font-semibold">{t.settings.dataCleared}</div>
        )}
      </section>
    </div>
  );
};
