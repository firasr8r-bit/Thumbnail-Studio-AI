import type { AppSettings, ExternalGeneratorTool } from '../types/architect';

export const BUILTIN_GENERATOR_TOOLS: ExternalGeneratorTool[] = [
  // ===================== GOOGLE TOOLS =====================
  {
    id: 'google-flow',
    category: 'google',
    isFeatured: true,
    name: 'Google Flow',
    badgeText: 'GF',
    shortDescAr:
      'بيئة Google الإبداعية الأساسية لإنشاء وتعديل المشاهد البصرية عبر صور مرجعية متعددة مع دعم أوضاع Image وAgent وImage Editing.',
    shortDescEn:
      'Google’s primary creative studio supporting multi-image visual references across Image Mode, Flow Agent Mode, and Image Editing.',
    usageTypeAr: 'توليد صور ثابتة + وضع وكيل Flow + تعديل بالصور المرجعية',
    usageTypeEn: 'Static Image Generation + Flow Agent Mode + Reference Image Editing',
    referenceHandlingAr:
      'ترفع صور كل شخص عبر Add Image (أو داخل مربع Agent Prompt) وتُربط صراحةً داخل البرومبت برقم الصورة المرجعية والاسم.',
    referenceHandlingEn:
      'Upload each person’s portrait via Add Image (or inside the Agent Prompt box) and bind each image number explicitly in English.',
    promptStyleAr:
      'وصف إنجليزي منظم بالفقرات يبدأ بتأمين الهوية، ثم المشهد والتكوين، ثم النص، ثم قواعد التجنّب بصياغة نثرية واضحة.',
    promptStyleEn:
      'Structured natural-language paragraphs prioritizing identity preservation first, followed by composition, text, and clear prose avoidance rules.',
    identitySupportSummaryAr:
      'عالي جداً عند ربط كل صورة مرجعية برقمها وسماتها الظاهرة مع منع خلط الوجوه (مع تفاوت حسب النموذج المختار داخل Flow).',
    identitySupportSummaryEn:
      'High when each reference image and visible facial trait is bound explicitly (final likeness still depends on the active Flow model).',
    supportsSeparateNegative: false,
    negativeHandlingAr:
      'لا يعتمد حقل Negative Prompt منفصلاً في أغلب أوضاعه؛ يتم إدراج قسم Avoid Instructions بصياغة إنجليزية نثرية واضحة.',
    negativeHandlingEn:
      'Uses prose Avoid Instructions rather than a separate Negative Prompt input box.',
    recommendedSettingsAr: 'Aspect Ratio: 16:9 | Mode: Image / Agent / Editing | دقة YouTube 1280×720',
    recommendedSettingsEn: 'Aspect Ratio: 16:9 | Mode: Image / Agent / Editing | YouTube 1280×720',
  },
  {
    id: 'gemini',
    category: 'google',
    name: 'Google Gemini',
    badgeText: 'GM',
    shortDescAr:
      'توليد الصور مباشرة داخل محادثة Gemini مع قدرة عالية على فهم السياق العربي والإنجليزي واتباع عدة صور مرفقة.',
    shortDescEn:
      'Conversational image generation inside Google Gemini with strong contextual comprehension across multiple attached reference images.',
    usageTypeAr: 'توليد مباشر بالمحادثة + إرفاق صور مرجعية متعددة',
    usageTypeEn: 'Conversational generation + multiple attached portrait references',
    referenceHandlingAr:
      'أرفق صور الأشخاص بالترتيب داخل نفس الرسالة وعرّف كل صورة بالترتيب (Reference Image #1, #2).',
    referenceHandlingEn:
      'Attach person photos in sequence in the same prompt message and map each via Reference Image #1, #2.',
    promptStyleAr:
      'لغة طبيعية مفصلة ومتماسكة تصف التفاعل، الإضاءة، والنص المطلوب مع تجنّب الوسوم الرقمية أو أكواد Midjourney.',
    promptStyleEn:
      'Detailed cohesive natural language specifying interaction, lighting, and text without SD weights or Midjourney flags.',
    identitySupportSummaryAr:
      'ممتاز في فهم الأوامر الموصوفة لكل شخص مع إمكانية التعديل التفاعلي بالمحادثة.',
    identitySupportSummaryEn:
      'Strong at interpreting per-person instructions and supporting follow-up conversational tweaks.',
    supportsSeparateNegative: false,
    negativeHandlingAr: 'تُدمج قواعد التجنّب في فقرة واضحة بنهاية البرومبت الرئيسي.',
    negativeHandlingEn: 'Avoidance rules are integrated directly into the final section of the prompt.',
    recommendedSettingsAr: 'اطلب صراحةً نسبة 16:9 أفقية داخل الرسالة.',
    recommendedSettingsEn: 'Explicitly request 16:9 widescreen orientation inside the prompt.',
  },
  {
    id: 'nano-banana',
    category: 'google',
    name: 'Nano Banana',
    badgeText: 'NB',
    shortDescAr:
      'محرك سريع للصور والتعديلات اللحظية من منظومة Google يتميز بمرونة عالية في تعديل الخلفيات والتعابير بالاعتماد على المرجع.',
    shortDescEn:
      'Fast Google image generation & editing engine tuned for agile scene changes and reference-guided composition.',
    usageTypeAr: 'توليد سريع وتعديلات بصرية مباشرة',
    usageTypeEn: 'Fast generation & direct reference-guided edits',
    referenceHandlingAr:
      'أرفق صورة المرجع الأساسية أولاً مع جملة حصر واضحة لما يتغير (الخلفية/الإضاءة) وما يبقى ثابتاً (الوجه والملامح).',
    referenceHandlingEn:
      'Attach primary portraits first with explicit keep-fixed vs change-only directives.',
    promptStyleAr:
      'صياغة مركّزة وواضحة ومباشرة بدون حشو، تركّز على ما يُحفظ مقابل ما يتغيّر في المشهد.',
    promptStyleEn:
      'Focused, concise direct instructions separating what must stay unchanged from what should change.',
    identitySupportSummaryAr:
      'جيّد في الحفاظ على الملامح عندما تكون الجمل قصيرة ومحددة بوضوح دون تشتيت.',
    identitySupportSummaryEn:
      'Preserves key identity cues well when directives are concise and unambiguous.',
    supportsSeparateNegative: false,
    negativeHandlingAr: 'يعتمد تعليمات التجنب المدمجة المباشرة (Do not change / Avoid).',
    negativeHandlingEn: 'Relies on concise inline "Do not / Avoid" constraints.',
    recommendedSettingsAr: 'نسبة 16:9 | إبقاء المرجع واضحاً ومواجهاً للكاميرا.',
    recommendedSettingsEn: '16:9 widescreen | Front-facing clear portrait reference.',
  },
  {
    id: 'nano-banana-pro',
    category: 'google',
    name: 'Nano Banana Pro',
    badgeText: 'NBP',
    shortDescAr:
      'إصدار احترافي من Nano Banana يدعم دقة تفاصيل أعلى، نصوصاً أوضح، وربطاً أدق لعدة صور مرجعية عند توفره في حسابك أو Flow.',
    shortDescEn:
      'Pro tier when available in Flow/Google accounts, offering sharper detail, cleaner short text rendering, and tighter multi-reference control.',
    usageTypeAr: 'إخراج احترافي عالي الدقة + نصوص + تعدد المراجع',
    usageTypeEn: 'High-craft output + cleaner typography + multi-reference anchoring',
    referenceHandlingAr:
      'اربط كل صورة رقمية باسم الشخص وسماته الظاهرة ودوره في الصورة المصغرة لتفادي التداخل.',
    referenceHandlingEn:
      'Anchor every numbered photo with visible traits and explicit thumbnail role.',
    promptStyleAr:
      'توجيه إخراجي احترافي (Art Direction) يجمع دقة الهوية وتفاصيل الإضاءة الاستوديوية والعدسة.',
    promptStyleEn:
      'High-precision art-director prose covering identity lock, sculpted lighting, lens perspective, and crisp text.',
    identitySupportSummaryAr:
      'دعم متقدم للربط متعدد الأشخاص عند توفر النموذج واستخدام صور أساسية واضحة.',
    identitySupportSummaryEn:
      'Strong multi-person anchoring when available and paired with clean primary portraits.',
    supportsSeparateNegative: false,
    negativeHandlingAr: 'تعليمات منع أخطاء مدمجة ومفصّلة ضمن البرومبت.',
    negativeHandlingEn: 'Detailed inline avoidance section integrated into the prompt.',
    recommendedSettingsAr: '16:9 widescreen | High Detail / Pro Tier when available.',
    recommendedSettingsEn: '16:9 widescreen | High Detail / Pro Tier when available.',
  },

  // ===================== OTHER TOOLS =====================
  {
    id: 'chatgpt',
    category: 'other',
    name: 'ChatGPT Image',
    badgeText: 'GPT',
    shortDescAr:
      'محرك GPT لتوليد الصور مع قدرة ممتازة على فهم التعليمات التفصيلية، تعدد الأشخاص، وكتابة النصوص القصيرة.',
    shortDescEn:
      'GPT Image generation model strong at following structured instructions, multi-person scenes, and short crisp headlines.',
    usageTypeAr: 'توليد بالمحادثة + نصوص + صور مرجعية',
    usageTypeEn: 'Conversational image synthesis + typography + portrait references',
    referenceHandlingAr:
      'ارفع صور كل شخص بالترتيب داخل المحادثة واكتب "Image 1 is Person 1, Image 2 is Person 2".',
    referenceHandlingEn:
      'Upload portraits in order in chat and state "Image 1 is Person 1, Image 2 is Person 2".',
    promptStyleAr: 'وصف حواري واضح يحدد التكوين والمشاعر والنص مع تعليمات منع تشويه الوجوه.',
    promptStyleEn: 'Clear conversational scene instructions specifying layout, emotion, text, and face rules.',
    identitySupportSummaryAr: 'قوي في اتباع وصف السمات، وقد يميل أحياناً للتنعيم ما لم يُمنع صراحةً.',
    identitySupportSummaryEn: 'Follows trait descriptions well; needs explicit instruction against skin smoothing.',
    supportsSeparateNegative: false,
    negativeHandlingAr: 'تُكتب الممنوعات في فقرة "Avoid / Do Not" داخل البرومبت نفسه.',
    negativeHandlingEn: 'Negative terms are embedded inside a clear "Avoid / Do Not" paragraph.',
    recommendedSettingsAr: 'اطلب نسبة 16:9 (Landscape widescreen) في نهاية الطلب.',
    recommendedSettingsEn: 'Specify 16:9 landscape output explicitly in the prompt.',
  },
  {
    id: 'midjourney',
    category: 'other',
    name: 'Midjourney',
    badgeText: 'MJ',
    shortDescAr:
      'أحد أقوى محركات الإخراج السينمائي والجمالي باستخدام صياغة مركّزة ومعاملات الأبعاد والأسلوب الرسمية.',
    shortDescEn:
      'Industry-favorite cinematic image generator driven by concise descriptive phrases and documented CLI flags.',
    usageTypeAr: 'إخراج فني وسينمائي عالي الجودة',
    usageTypeEn: 'High-impact cinematic & editorial visual rendering',
    referenceHandlingAr:
      'يعتمد على روابط الصور المرفقة عبر المعاملات الموثقة (--cref / --oref أو روابط الصور) لكل شخصية.',
    referenceHandlingEn:
      'Uses hosted image URLs with Midjourney’s character/omni reference workflow per person.',
    promptStyleAr:
      'جمل إنجليزية قصيرة ومكثّفة مفصولة بفواصل متبوعة بـ --ar 16:9 و --style raw و --no فقط.',
    promptStyleEn:
      'Concise comma-separated visual phrases ending with documented flags (--ar 16:9, --style raw, --no).',
    identitySupportSummaryAr:
      'يحافظ على التشابه العام عند استخدام مرجع واحد؛ وقد يحتاج دمجاً أو تعديلاً خارجياً لعدة وجوه معقدة.',
    identitySupportSummaryEn:
      'Good single-subject likeness via character ref; multi-person swaps may need compositing or careful refs.',
    supportsSeparateNegative: true,
    negativeHandlingAr: 'يدعم معامل --no بعد البرومبت بالإضافة لعرض القائمة بشكل منفصل للنسخ.',
    negativeHandlingEn: 'Supports documented --no flag inline plus copyable exclusion list.',
    recommendedSettingsAr: '--ar 16:9 --style raw (مع تجنّب أي معاملات غير موثقة).',
    recommendedSettingsEn: '--ar 16:9 --style raw (only documented parameters included).',
  },
  {
    id: 'flux',
    category: 'other',
    name: 'FLUX',
    badgeText: 'FX',
    shortDescAr:
      'نموذج حديث متميز في الواقعية الفوتوغرافية، فهم الفيزياء والإضاءة، وكتابة النصوص الدقيقة دون حشو كلمات مفتاحية.',
    shortDescEn:
      'Modern photorealistic diffusion/flow-matching model excelling at natural lighting, lens physics, and legible text.',
    usageTypeAr: 'تصوير واقعي فائق الدقة + FLUX Kontext للتعديل بالمرجع',
    usageTypeEn: 'Photorealism & FLUX Kontext reference-based composition',
    referenceHandlingAr:
      'في FLUX Kontext / LoRA، صِف كل شخص باسمه وصفاته الظاهرة بوضوح في جمل سردية طبيعية.',
    referenceHandlingEn:
      'In FLUX Kontext / LoRA workflows, describe each person in crisp natural photographic prose.',
    promptStyleAr:
      'نثر فوتوغرافي طبيعي بالكامل خالٍ من وسوم الجودة مثل (masterpiece, 8k:1.3).',
    promptStyleEn:
      'Pure natural photographic prose free of weighted tag spam like (masterpiece:1.3).',
    identitySupportSummaryAr: 'عالي في FLUX Kontext / LoRA، ومتوازن في التوليد النصي الصرف.',
    identitySupportSummaryEn: 'Strong with FLUX Kontext / LoRA; prompt-only mode follows detailed trait prose.',
    supportsSeparateNegative: true,
    negativeHandlingAr: 'يدعم حقل Negative في بعض الواجهات (مثل ComfyUI) بينما يعتمد FLUX الأساسي على الوصف الإيجابي.',
    negativeHandlingEn: 'Optional separate Negative box in ComfyUI/UI wrappers; base FLUX favors positive prose.',
    recommendedSettingsAr: '1280×720 أو 1344×768 (16:9) | Guidance 3.0–3.5',
    recommendedSettingsEn: '1280×720 or 1344×768 (16:9) | Guidance 3.0–3.5',
  },
  {
    id: 'stable-diffusion',
    category: 'other',
    name: 'Stable Diffusion',
    badgeText: 'SD',
    shortDescAr:
      'بيئة SDXL / ComfyUI / Automatic1111 المفتوحة التي توفر تحكماً هندسياً كاملاً عبر Positive وNegative Prompt منفصلين.',
    shortDescEn:
      'Open ecosystem (SDXL / ComfyUI / A1111) giving granular weight syntax, separate Negative Prompt, and ControlNet/IP-Adapter.',
    usageTypeAr: 'توليد محلي/سحابي متقدم عبر ComfyUI وIP-Adapter',
    usageTypeEn: 'Advanced ComfyUI / SDXL pipelines with separate Positive & Negative inputs',
    referenceHandlingAr:
      'يُربط كل شخص عبر IP-Adapter FaceID أو InstantID بقناع منطقة مستقل في ComfyUI.',
    referenceHandlingEn:
      'Route Person 1 and Person 2 via separate IP-Adapter FaceID / InstantID regional masks.',
    promptStyleAr:
      'أوزان موثقة (tag:1.2) + بنية موضوع/إضاءة/عدسة واضحة + حقل Negative Prompt منفصل.',
    promptStyleEn:
      'Documented emphasis weights (phrase:1.2), structured lighting/lens tags, plus dedicated Negative Prompt.',
    identitySupportSummaryAr: 'عالي جداً عند اقترانه بـ InstantID / FaceID لكل قناع شخص.',
    identitySupportSummaryEn: 'Very high when paired with per-person FaceID / InstantID regional conditioning.',
    supportsSeparateNegative: true,
    negativeHandlingAr: 'حقل Negative Prompt مستقل إلزامي ومفصّل لمنع التشوهات.',
    negativeHandlingEn: 'Dedicated separate Negative Prompt field optimized for SDXL/SD anatomy guards.',
    recommendedSettingsAr: '1344×768 أو 1280×720 (16:9) | CFG 5.5–7 | 28–35 Steps',
    recommendedSettingsEn: '1344×768 or 1280×720 (16:9) | CFG 5.5–7 | 28–35 Steps',
  },
  {
    id: 'adobe-firefly',
    category: 'other',
    name: 'Adobe Firefly',
    badgeText: 'AF',
    shortDescAr:
      'أداة Adobe الآمنة تجارياً لإنتاج صور إعلانية واستوديوية نظيفة مع استخدام Structure / Style Reference في الواجهة.',
    shortDescEn:
      'Adobe’s commercially clean visual studio featuring intuitive Structure & Style Reference sliders.',
    usageTypeAr: 'تصميم تجاري نظيف + مراجع تكوين وأسلوب',
    usageTypeEn: 'Commercial-clean photography + visual structure/style sliders',
    referenceHandlingAr:
      'استخدم خانة Composition / Style Reference في Firefly، وتجنّب ذكر أسماء المشاهير أو العلامات المحمية.',
    referenceHandlingEn:
      'Use Firefly’s Composition & Style Reference slots; avoid celebrity names or trademarked tokens.',
    promptStyleAr: 'وصف تصويري احترافي نظيف يحدد الموضوع والإضاءة والعدسة بدون أوامر تقنية.',
    promptStyleEn: 'Clean commercial-photography prose specifying subject, lighting, and camera framing.',
    identitySupportSummaryAr:
      'محدود لهويات الأشخاص الحقيقية الدقيقة مقارنة بـ Flow/Gemini؛ مناسب أكثر للتكوين والخلفيات.',
    identitySupportSummaryEn:
      'Limited exact real-face identity lock compared to Flow/Gemini; strongest for scenes & commercial lighting.',
    supportsSeparateNegative: true,
    negativeHandlingAr: 'يتوفر في بعض واجهات Firefly حقل Exclude أو يُكتب كوصف إيجابي نظيف.',
    negativeHandlingEn: 'Supports Firefly Exclude terms separately where available alongside clean framing.',
    recommendedSettingsAr: 'Aspect Ratio: Widescreen (16:9) | Content Type: Photo',
    recommendedSettingsEn: 'Aspect Ratio: Widescreen (16:9) | Content Type: Photo',
  },
  {
    id: 'ideogram',
    category: 'other',
    name: 'Ideogram',
    badgeText: 'ID',
    shortDescAr:
      'متخصص في دمج النصوص والخطوط الدقيقة داخل الصورة مع تكوينات يوتيوب نظيفة وعالية التباين.',
    shortDescEn:
      'Typography-specialized generator celebrated for crisp text rendering inside high-contrast layouts.',
    usageTypeAr: 'صور مصغّرة تتضمن نصوصاً وعناوين داخل الصورة',
    usageTypeEn: 'Text-heavy thumbnails, crisp poster typography, and bold graphic layouts',
    referenceHandlingAr:
      'يدعم Image Reference / Character في الخطط المدعومة؛ ضع النص المطلوب بين علامتي تنصيص واضحتين.',
    referenceHandlingEn:
      'Supports reference conditioning where enabled; place exact thumbnail text in double quotes.',
    promptStyleAr:
      'إبراز النص المطلوب داخل علامات تنصيص مع تحديد نمط الخط وموقعه في المساحة الفارغة.',
    promptStyleEn:
      'Quote exact headline text clearly with font style, contrast outline, and safe placement zone.',
    identitySupportSummaryAr:
      'جيد مع الميزة المرجعية؛ يتميز أساساً في دقة الحروف اللاتينية والأرقام.',
    identitySupportSummaryEn: 'Moderate character consistency; standout strength is crisp headline lettering.',
    supportsSeparateNegative: true,
    negativeHandlingAr: 'يدعم حقل Negative Prompt في واجهة Ideogram لمنع الأخطاء البصرية.',
    negativeHandlingEn: 'Supports Ideogram’s dedicated Negative Prompt input box.',
    recommendedSettingsAr: 'Aspect Ratio: 16:9 | Magic Prompt: Off (للحفاظ على دقة النص)',
    recommendedSettingsEn: 'Aspect Ratio: 16:9 | Magic Prompt: Off for strict wording fidelity',
  },
  {
    id: 'leonardo',
    category: 'other',
    name: 'Leonardo AI',
    badgeText: 'LN',
    shortDescAr:
      'منصة إبداعية غنية بنماذج مثل Phoenix وKino XL مع تحكم في Character Reference وحقل Negative منفصل.',
    shortDescEn:
      'Versatile creative platform (Phoenix, Kino XL) with built-in Character Reference guidance and Negative Prompt.',
    usageTypeAr: 'إنتاج استوديوي + Character Reference',
    usageTypeEn: 'Stylized or photorealistic studio scenes + Character Reference',
    referenceHandlingAr:
      'ارفع صورة الشخص في Image Guidance -> Character Reference وحدد قوة التطابق في واجهة Leonardo.',
    referenceHandlingEn:
      'Attach portrait under Image Guidance -> Character Reference and tune reference strength.',
    promptStyleAr:
      'وصف بصري غني بالإضاءة والعمق والتفاصيل متبوعاً بحقل Negative Prompt مستقل.',
    promptStyleEn:
      'Descriptive scene + studio lighting prose paired with Leonardo’s separate Negative Prompt box.',
    identitySupportSummaryAr: 'جيّد عبر Character Reference في النماذج الداعمة له.',
    identitySupportSummaryEn: 'Good via Character Reference guidance on compatible models.',
    supportsSeparateNegative: true,
    negativeHandlingAr: 'يدعم Negative Prompt منفصلاً داخل المحرر.',
    negativeHandlingEn: 'Built-in separate Negative Prompt field supported.',
    recommendedSettingsAr: '16:9 (1360×768 أو 1280×720) | Alchemy / PhotoReal عند التوفر',
    recommendedSettingsEn: '16:9 (1360×768 or 1280×720) | Alchemy / PhotoReal if enabled',
  },
  {
    id: 'recraft',
    category: 'other',
    name: 'Recraft',
    badgeText: 'RC',
    shortDescAr:
      'أداة تصميم دقيقة تمنح تحكماً صارماً في لوحة الألوان، التوزيع التجاري، والتصوير النظيف الخالي من الفوضى.',
    shortDescEn:
      'Design-native image generator built for crisp visual hierarchy, strict color palettes, and editorial photography.',
    usageTypeAr: 'تكوين نظيف وتحكم بالألوان والهوية البصرية',
    usageTypeEn: 'Structured graphic/photo compositions with disciplined color palettes',
    referenceHandlingAr:
      'استخدم لوحة الألوان المحددة وأسلوب Photorealism؛ ركّز على توزيع العناصر ومساحات النص.',
    referenceHandlingEn:
      'Pair Photorealism preset with explicit color-palette tokens and clean spatial zones.',
    promptStyleAr: 'جمل تصميمية هندسية واضحة تحدد الألوان وموضع كل عنصر بدقة.',
    promptStyleEn: 'Design-precise sentences defining color swatches, zone placement, and subject clarity.',
    identitySupportSummaryAr: 'أقوى في التكوين والألوان والأغراض مقارنة بوجوه الأشخاص الحقيقيين.',
    identitySupportSummaryEn: 'Stronger at layout, objects, and color fidelity than exact multi-person likeness.',
    supportsSeparateNegative: true,
    negativeHandlingAr: 'يدعم عناصر الاستبعاد (Avoid/Negative) في واجهة التصميم.',
    negativeHandlingEn: 'Supports exclusion/negative phrasing cleanly.',
    recommendedSettingsAr: 'Size: 16:9 | Style: Photorealistic Studio',
    recommendedSettingsEn: 'Size: 16:9 | Style: Photorealistic Studio',
  },
  {
    id: 'generic',
    category: 'other',
    name: 'Generic Image Generator',
    badgeText: 'ANY',
    shortDescAr:
      'صيغة احترافية شاملة متوافقة مع أي مولد صور آخر مع فصل واضح لقواعد التجنّب ومراجع الأشخاص.',
    shortDescEn:
      'Universal, well-structured prompt architecture compatible with any external image generation tool.',
    usageTypeAr: 'متوافق مع جميع الأدوات العامة',
    usageTypeEn: 'Universal compatibility across any platform',
    referenceHandlingAr: 'ارفع صور الأشخاص بالترتيب المرقّم في أداتك الخارجية.',
    referenceHandlingEn: 'Upload numbered person photos in sequence inside your external tool.',
    promptStyleAr: 'وصف منظم من 16 نقطة بالإنجليزية يغطي الهوية والمشهد والإضاءة والنص.',
    promptStyleEn: '16-point English art-direction sheet covering identity, scene, lighting, and text.',
    identitySupportSummaryAr: 'يعتمد كلياً على قدرات الأداة المستهدفة في قراءة الصور المرجعية.',
    identitySupportSummaryEn: 'Depends entirely on the target tool’s reference-image support.',
    supportsSeparateNegative: true,
    negativeHandlingAr: 'يوفر حقلاً منفصلاً للـ Negative Prompt عند دعمه في الأداة.',
    negativeHandlingEn: 'Includes a copyable separate Negative Prompt for tools that support it.',
    recommendedSettingsAr: '16:9 Landscape | 1280×720 YouTube Standard',
    recommendedSettingsEn: '16:9 Landscape | 1280×720 YouTube Standard',
  },
];

export function getAllGeneratorTools(settings?: Pick<AppSettings, 'customTools' | 'toolOverrides'>): ExternalGeneratorTool[] {
  const overrides = settings?.toolOverrides ?? {};
  const mergedBuiltIns = BUILTIN_GENERATOR_TOOLS.map((tool) =>
    overrides[tool.id] ? { ...tool, ...overrides[tool.id], id: tool.id } : tool
  );
  const custom = (settings?.customTools ?? []).map((tool) =>
    overrides[tool.id] ? { ...tool, ...overrides[tool.id], id: tool.id } : tool
  );
  return [...mergedBuiltIns, ...custom];
}

export function getGeneratorToolById(
  id: string,
  settings?: Pick<AppSettings, 'customTools' | 'toolOverrides'>
): ExternalGeneratorTool {
  const all = getAllGeneratorTools(settings);
  return all.find((t) => t.id === id) ?? BUILTIN_GENERATOR_TOOLS[0];
}
