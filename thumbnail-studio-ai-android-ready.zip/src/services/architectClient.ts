import { Capacitor } from '@capacitor/core';
import type { IdeaAnalysis, IdeaInputs, Language, VisualConcept } from '../types/architect';

export interface ServerArchitectStatus {
  hasRuntimeTextModel: boolean;
  mode: 'hybrid-optional-llm' | 'local-architect-only';
}

export async function getOptionalArchitectStatus(): Promise<ServerArchitectStatus> {
  if (Capacitor.isNativePlatform()) {
    return { hasRuntimeTextModel: false, mode: 'local-architect-only' };
  }
  try {
    const res = await fetch('/api/architect/status');
    if (!res.ok) {
      return { hasRuntimeTextModel: false, mode: 'local-architect-only' };
    }
    return (await res.json()) as ServerArchitectStatus;
  } catch {
    return { hasRuntimeTextModel: false, mode: 'local-architect-only' };
  }
}

export async function tryOptionalServerIdeaAnalysis(params: {
  inputs: IdeaInputs;
  styleSummary: string;
  lang: Language;
}): Promise<{ available: boolean; analysis?: IdeaAnalysis; concepts?: VisualConcept[] }> {
  if (Capacitor.isNativePlatform()) return { available: false };
  try {
    const res = await fetch('/api/architect/analyze-idea', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'ThumbnailPromptArchitectAI',
      },
      body: JSON.stringify({
        ...params.inputs,
        styleSummary: params.styleSummary,
        lang: params.lang,
      }),
    });
    if (!res.ok) return { available: false };
    const data = (await res.json()) as {
      available?: boolean;
      analysis?: IdeaAnalysis;
      concepts?: VisualConcept[];
    };
    if (data.available && data.analysis && Array.isArray(data.concepts) && data.concepts.length >= 3) {
      return {
        available: true,
        analysis: data.analysis,
        concepts: data.concepts,
      };
    }
    return { available: false };
  } catch {
    return { available: false };
  }
}
