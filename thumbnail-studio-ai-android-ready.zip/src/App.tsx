import React, { useEffect, useState } from 'react';
import { ExternalGeneratorsPage } from './components/ExternalGeneratorsPage';
import { HomePage } from './components/HomePage';
import { NewProjectModal, type NewProjectCreationConfig } from './components/NewProjectModal';
import { ProjectsPage } from './components/ProjectsPage';
import { ProjectWorkspace } from './components/ProjectWorkspace';
import { SavedPromptsPage } from './components/SavedPromptsPage';
import { SettingsPage } from './components/SettingsPage';
import { SidebarNav } from './components/SidebarNav';
import { VisualLibraryPage } from './components/VisualLibraryPage';
import { buildStyleSummaryLabel, synthesizePromptBundle } from './engine/localArchitectEngine';
import {
  clearAllStorageData,
  DEFAULT_SETTINGS,
  deleteProjectById,
  deleteSavedPromptById,
  getAllProjects,
  getAllSavedPrompts,
  loadSettings,
  saveProject,
  savePromptEntry,
  saveSettings,
} from './storage/architectDb';
import type {
  AppSettings,
  ArchitectProject,
  GoogleFlowConfig,
  Language,
  NavSection,
  SavedPromptEntry,
  TargetGenerator,
} from './types/architect';

export function App() {
  const [settings, setSettings] = useState<AppSettings>(() => loadSettings());
  const [activeSection, setActiveSection] = useState<NavSection>('dashboard');
  const [generatorsTab, setGeneratorsTab] = useState<'library' | 'flow' | 'compare' | 'custom'>(
    'library'
  );
  const [projects, setProjects] = useState<ArchitectProject[]>([]);
  const [savedPrompts, setSavedPrompts] = useState<SavedPromptEntry[]>([]);
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);

  // Library blend staging state (used both before starting a project or syncing with active project)
  const [stagedCreatorIds, setStagedCreatorIds] = useState<string[]>([]);
  const [stagedGeneralIds, setStagedGeneralIds] = useState<string[]>([]);

  const lang: Language = settings.language;

  // Keep HTML dir & lang synchronized cleanly without resetting project state
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  // Load local IndexedDB projects & saved prompts (clean empty start on first visit)
  useEffect(() => {
    void (async () => {
      const [loadedProjects, loadedPrompts] = await Promise.all([
        getAllProjects(),
        getAllSavedPrompts(),
      ]);
      setProjects(loadedProjects);
      setSavedPrompts(loadedPrompts);
    })();
  }, []);

  const activeProject = projects.find((p) => p.id === activeProjectId) ?? null;

  const handleUpdateSettings = (next: AppSettings) => {
    setSettings(next);
    saveSettings(next);
  };

  const handleToggleLanguage = () => {
    handleUpdateSettings({
      ...settings,
      language: settings.language === 'ar' ? 'en' : 'ar',
    });
  };

  const createNewProject = async (
    config: NewProjectCreationConfig,
    creatorIds: string[] = stagedCreatorIds,
    generalIds: string[] = stagedGeneralIds
  ) => {
    const now = Date.now();
    const newProj: ArchitectProject = {
      id: `proj-${now}-${Math.random().toString(36).slice(2, 7)}`,
      name: config.name,
      createdAt: now,
      updatedAt: now,
      phase: 'idea',
      wizardStepIndex: 0,
      selectedCreatorIds: [...creatorIds],
      selectedGeneralIds: [...generalIds],
      ideaInputs: {
        videoTitle: '',
        ideaDescription: '',
        contentType: '',
        participantsDescription: '',
        coreMessage: '',
      },
      concepts: [],
      wizardAnswers: {
        selectedConceptId: 'concept-clash',
        expressionChoice: 'shocked-extreme',
        poseChoice: 'closeup-dominant',
        backgroundChoice: 'studio-dual-neon',
        colorChoice: 'electric-blue-crimson',
        textMode: 'no',
        thumbnailText: '',
        elementsSelected: ['none'],
        targetGenerator: config.targetGenerator,
        identityMode: config.identityMode,
        googleFlowConfig: {
          ...settings.googleFlowDefaults,
          mode: config.flowMode,
          modelChoice: config.flowModel,
        },
      },
      referenceImages: [],
    };

    setProjects((prev) => [newProj, ...prev]);
    setActiveProjectId(newProj.id);
    setActiveSection('workspace');
    setIsNewModalOpen(false);

    if (settings.autoSaveEnabled) {
      await saveProject(newProj);
    }
  };

  const handleUpdateProject = (updated: ArchitectProject) => {
    setProjects((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    if (settings.autoSaveEnabled) {
      void saveProject(updated);
    }
  };

  const handleOpenProject = (id: string) => {
    const target = projects.find((p) => p.id === id);
    if (!target) return;
    setActiveProjectId(id);
    setStagedCreatorIds(target.selectedCreatorIds);
    setStagedGeneralIds(target.selectedGeneralIds);
    setActiveSection('workspace');
  };

  const handleRenameProject = (id: string, newName: string) => {
    const target = projects.find((p) => p.id === id);
    if (!target) return;
    handleUpdateProject({ ...target, name: newName, updatedAt: Date.now() });
  };

  const handleDuplicateProject = async (id: string) => {
    const target = projects.find((p) => p.id === id);
    if (!target) return;
    const now = Date.now();
    const copy: ArchitectProject = {
      ...target,
      id: `proj-${now}-${Math.random().toString(36).slice(2, 7)}`,
      name: `${target.name} (${lang === 'ar' ? 'نسخة' : 'Copy'})`,
      createdAt: now,
      updatedAt: now,
    };
    setProjects((prev) => [copy, ...prev]);
    if (settings.autoSaveEnabled) {
      await saveProject(copy);
    }
  };

  const handleDeleteProject = async (id: string) => {
    setProjects((prev) => prev.filter((p) => p.id !== id));
    if (activeProjectId === id) {
      setActiveProjectId(null);
    }
    await deleteProjectById(id);
  };

  const handleSavePromptToLibrary = async (proj: ArchitectProject) => {
    if (!proj.promptResult) return;
    const entry: SavedPromptEntry = {
      id: `saved-${Date.now()}`,
      projectId: proj.id,
      projectName: proj.name,
      videoTitle: proj.ideaInputs.videoTitle || proj.name,
      targetGenerator: proj.promptResult.targetGenerator,
      mainPrompt: proj.customEditedPrompt ?? proj.promptResult.mainPrompt,
      negativePrompt: proj.promptResult.negativePrompt,
      arabicTranslation: proj.promptResult.arabicTranslation,
      visualDirectionLabel: buildStyleSummaryLabel(
        proj.selectedCreatorIds,
        proj.selectedGeneralIds,
        lang
      ),
      createdAt: Date.now(),
    };
    setSavedPrompts((prev) => [entry, ...prev]);
    await savePromptEntry(entry);
  };

  const handleDeleteSavedPrompt = async (id: string) => {
    setSavedPrompts((prev) => prev.filter((p) => p.id !== id));
    await deleteSavedPromptById(id);
  };

  const handleClearAllData = async () => {
    await clearAllStorageData();
    setProjects([]);
    setSavedPrompts([]);
    setActiveProjectId(null);
    setStagedCreatorIds([]);
    setStagedGeneralIds([]);
  };

  const toggleCreatorSelection = (id: string) => {
    setStagedCreatorIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const toggleGeneralSelection = (id: string) => {
    setStagedGeneralIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleApplyBlendToActiveProject = () => {
    if (!activeProject) return;
    handleUpdateProject({
      ...activeProject,
      selectedCreatorIds: [...stagedCreatorIds],
      selectedGeneralIds: [...stagedGeneralIds],
      updatedAt: Date.now(),
    });
    setActiveSection('workspace');
  };

  const handleOpenLibraryFromWorkspace = () => {
    if (activeProject) {
      setStagedCreatorIds(activeProject.selectedCreatorIds);
      setStagedGeneralIds(activeProject.selectedGeneralIds);
    }
    setActiveSection('library');
  };

  const handleOpenGeneratorsTab = (tab: 'library' | 'flow' | 'compare' | 'custom') => {
    setGeneratorsTab(tab);
    setActiveSection('generators');
  };

  const handleApplyToolToProject = (
    toolId: TargetGenerator,
    flowConfig?: GoogleFlowConfig
  ) => {
    if (!activeProject) return;
    const updated: ArchitectProject = {
      ...activeProject,
      updatedAt: Date.now(),
      customEditedPrompt: undefined,
      wizardAnswers: {
        ...activeProject.wizardAnswers,
        targetGenerator: toolId,
        googleFlowConfig:
          flowConfig ??
          activeProject.wizardAnswers.googleFlowConfig ??
          settings.googleFlowDefaults,
      },
    };
    if (updated.phase === 'result' || updated.promptResult) {
      updated.promptResult = synthesizePromptBundle(
        updated,
        updated.promptResult?.variationSeed ?? 0,
        lang,
        undefined,
        settings
      );
    }
    handleUpdateProject(updated);
    setActiveSection('workspace');
  };

  return (
    <div className="min-h-screen bg-[#090A0F] text-slate-100 flex flex-col lg:flex-row">
      <SidebarNav
        activeSection={activeSection}
        onSelectSection={(sec) => {
          if (sec === 'generators') setGeneratorsTab('library');
          setActiveSection(sec);
        }}
        onNewProject={() => setIsNewModalOpen(true)}
        lang={lang}
        onToggleLanguage={handleToggleLanguage}
        hasActiveProject={Boolean(activeProject)}
        projectsCount={projects.length}
        savedPromptsCount={savedPrompts.length}
      />

      <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-8 overflow-y-auto">
        {activeSection === 'dashboard' && (
          <HomePage
            lang={lang}
            projects={projects}
            savedPromptsCount={savedPrompts.length}
            onNewProject={() => setIsNewModalOpen(true)}
            onOpenProject={handleOpenProject}
            onNavigate={(sec) => {
              if (sec === 'generators') setGeneratorsTab('library');
              setActiveSection(sec);
            }}
          />
        )}

        {activeSection === 'library' && (
          <VisualLibraryPage
            lang={lang}
            selectedCreatorIds={stagedCreatorIds}
            selectedGeneralIds={stagedGeneralIds}
            hasActiveProject={Boolean(activeProject)}
            onToggleCreator={toggleCreatorSelection}
            onToggleGeneral={toggleGeneralSelection}
            onClearBlend={() => {
              setStagedCreatorIds([]);
              setStagedGeneralIds([]);
            }}
            onStartProjectWithBlend={() => setIsNewModalOpen(true)}
            onApplyBlendToActiveProject={handleApplyBlendToActiveProject}
          />
        )}

        {activeSection === 'generators' && (
          <ExternalGeneratorsPage
            key={generatorsTab}
            settings={settings}
            activeProject={activeProject}
            initialTab={generatorsTab}
            onUpdateSettings={handleUpdateSettings}
            onApplyToolToProject={handleApplyToolToProject}
          />
        )}

        {activeSection === 'workspace' && (
          <ProjectWorkspace
            project={activeProject}
            lang={lang}
            settings={settings}
            useOptionalServerAI={settings.useOptionalServerAI}
            onUpdateProject={handleUpdateProject}
            onOpenLibrary={handleOpenLibraryFromWorkspace}
            onOpenGeneratorsTab={handleOpenGeneratorsTab}
            onNewProject={() => setIsNewModalOpen(true)}
            onSavePromptToLibrary={handleSavePromptToLibrary}
          />
        )}

        {activeSection === 'projects' && (
          <ProjectsPage
            lang={lang}
            projects={projects}
            activeProjectId={activeProjectId}
            onNewProject={() => setIsNewModalOpen(true)}
            onOpenProject={handleOpenProject}
            onRenameProject={handleRenameProject}
            onDuplicateProject={(id) => void handleDuplicateProject(id)}
            onDeleteProject={(id) => void handleDeleteProject(id)}
          />
        )}

        {activeSection === 'saved-prompts' && (
          <SavedPromptsPage
            lang={lang}
            savedPrompts={savedPrompts}
            onDeletePrompt={(id) => void handleDeleteSavedPrompt(id)}
            onOpenProject={handleOpenProject}
          />
        )}

        {activeSection === 'settings' && (
          <SettingsPage
            settings={settings ?? DEFAULT_SETTINGS}
            onUpdateSettings={handleUpdateSettings}
            onClearAllData={handleClearAllData}
            onNavigate={(sec) => {
              if (sec === 'generators') setGeneratorsTab('library');
              setActiveSection(sec);
            }}
          />
        )}
      </main>

      <NewProjectModal
        isOpen={isNewModalOpen}
        settings={settings}
        onClose={() => setIsNewModalOpen(false)}
        onCreate={(config) => void createNewProject(config)}
      />
    </div>
  );
}

export default App;
