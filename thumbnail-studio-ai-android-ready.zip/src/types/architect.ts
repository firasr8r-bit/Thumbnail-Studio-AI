export type Language = 'ar' | 'en';

export type NavSection =
  | 'dashboard'
  | 'workspace'
  | 'projects'
  | 'library'
  | 'generators'
  | 'saved-prompts'
  | 'settings';

export type BuiltInGeneratorId =
  | 'google-flow'
  | 'gemini'
  | 'nano-banana'
  | 'nano-banana-pro'
  | 'chatgpt'
  | 'midjourney'
  | 'flux'
  | 'stable-diffusion'
  | 'adobe-firefly'
  | 'ideogram'
  | 'leonardo'
  | 'recraft'
  | 'generic';

export type TargetGenerator = BuiltInGeneratorId | (string & {});

export type ProjectPhase = 'idea' | 'wizard' | 'result';

export type IdentityMode = 'max-priority' | 'creative-transform';

export type GoogleFlowMode = 'image' | 'agent' | 'editing';

export interface GoogleFlowConfig {
  mode: GoogleFlowMode;
  modelChoice: string;
  customModelName?: string;
  aspectRatio: '16:9';
  qualityLevel: 'high' | 'ultra-crisp';
  compositionFocus: 'high-ctr' | 'balanced-story';
  textSpace: 'none' | 'clean-negative-space';
  realismLevel: 'photorealistic' | 'natural-cinematic' | 'stylized-ctr';
}

export interface ExternalGeneratorTool {
  id: TargetGenerator;
  category: 'google' | 'other' | 'custom';
  name: string;
  badgeText: string;
  shortDescAr: string;
  shortDescEn: string;
  usageTypeAr: string;
  usageTypeEn: string;
  referenceHandlingAr: string;
  referenceHandlingEn: string;
  promptStyleAr: string;
  promptStyleEn: string;
  identitySupportSummaryAr: string;
  identitySupportSummaryEn: string;
  supportsSeparateNegative: boolean;
  negativeHandlingAr: string;
  negativeHandlingEn: string;
  recommendedSettingsAr: string;
  recommendedSettingsEn: string;
  isFeatured?: boolean;
  isCustom?: boolean;
  customTemplate?: string;
}

export interface CustomPromptTemplate {
  id: string;
  name: string;
  toolId: TargetGenerator;
  template: string;
  createdAt: number;
}

export type RefinementAction =
  | 'variation'
  | 'professional'
  | 'comedic'
  | 'stronger-expression'
  | 'change-colors'
  | 'change-background'
  | 'less-elements'
  | 'more-excitement';

export interface CreatorReference {
  id: string;
  region: 'arab' | 'global';
  nameAr: string;
  nameEn: string;
  styleDescAr: string;
  styleDescEn: string;
  colorsAr: string;
  colorsEn: string;
  paletteSwatches: string[];
  expressionStyleAr: string;
  expressionStyleEn: string;
  placementAr: string;
  placementEn: string;
  backgroundNatureAr: string;
  backgroundNatureEn: string;
  exaggerationLevel: 'low' | 'medium' | 'high' | 'extreme';
  bestContentAr: string;
  bestContentEn: string;
  exampleCompositionAr: string;
  exampleCompositionEn: string;
  promptStyleTokens: string;
}

export interface GeneralStyleDirection {
  id: string;
  nameAr: string;
  nameEn: string;
  descAr: string;
  descEn: string;
  colorsHintAr: string;
  colorsHintEn: string;
  paletteSwatches: string[];
  lightingTokens: string;
  compositionTokens: string;
  moodTokens: string;
}

export type ReferenceRole = 'person' | 'clothing' | 'pose' | 'scene';

export interface ImageDiagnostics {
  width: number;
  height: number;
  avgBrightness: number; // 0-255
  sharpnessScore: number; // 0-100 edge variance heuristic
}

export interface ReferenceImageItem {
  id: string;
  personGroupId: string;
  personLabel: string;
  role: ReferenceRole;
  fileName: string;
  dataUrl: string;
  mimeType: string;
  note?: string;
  isPrimary?: boolean;
  diagnostics?: ImageDiagnostics;
  manualWarnings?: {
    faceSmall?: boolean;
    faceObscured?: boolean;
    angleMismatch?: boolean;
  };
}

export interface PersonProfile {
  groupId: string;
  label: string;
  visibleTraits: string;
  thumbnailRole: string;
  primaryImageId?: string;
}

export interface IdeaInputs {
  videoTitle: string;
  ideaDescription: string;
  contentType: string;
  participantsDescription: string;
  coreMessage: string;
}

export interface IdeaAnalysis {
  mostExcitingElement: string;
  attentionMoment: string;
  targetEmotions: string;
  viewerQuestion: string;
  bestVisualAngle: string;
  detectedCategory: string;
  analysisSource: 'gemini-text' | 'local-architect';
}

export interface VisualConcept {
  id: string;
  name: string;
  sceneDescription: string;
  peoplePose: string;
  facialExpressions: string;
  background: string;
  extraElements: string;
  colors: string;
  lighting: string;
  whyItFits: string;
  inspiredBy: string;
  sceneTokensEn: string;
  poseTokensEn: string;
  expressionTokensEn: string;
  backgroundTokensEn: string;
  colorTokensEn: string;
  lightingTokensEn: string;
  elementsTokensEn: string;
}

export interface WizardAnswers {
  selectedConceptId: string;
  customConceptNote?: string;
  expressionChoice: string;
  perPersonExpressions?: Record<string, string>;
  poseChoice: string;
  backgroundChoice: string;
  colorChoice: string;
  textMode: 'yes' | 'no' | 'suggest';
  thumbnailText: string;
  elementsSelected: string[];
  customElementNote?: string;
  clothingNote?: string;
  targetGenerator: TargetGenerator;
  identityMode?: IdentityMode;
  googleFlowConfig?: GoogleFlowConfig;
}

export interface GoogleFlowPromptSections {
  mainFlowPrompt: string;
  identityProtectionInstructions: string;
  compositionInstructions: string;
  textInstructions: string;
  avoidInstructions: string;
  referenceUploadGuide: string;
}

export interface GeneratedPromptBundle {
  id: string;
  createdAt: number;
  targetGenerator: TargetGenerator;
  targetGeneratorName: string;
  identityMode: IdentityMode;
  mainPrompt: string;
  negativePrompt: string;
  supportsSeparateNegative: boolean;
  arabicTranslation: string;
  flowSections?: GoogleFlowPromptSections;
  designSummary: {
    ideaSummary: string;
    visualDirection: string;
    sceneSummary: string;
    colorsSummary: string;
    expressionsSummary: string;
  };
  usageInstructionsAr: string;
  usageInstructionsEn: string;
  referenceUploadGuideAr: string;
  referenceUploadGuideEn: string;
  recommendedSettingsAr: string;
  recommendedSettingsEn: string;
  variationSeed: number;
}

export interface SavedPromptEntry {
  id: string;
  projectId: string;
  projectName: string;
  videoTitle: string;
  targetGenerator: TargetGenerator;
  mainPrompt: string;
  negativePrompt: string;
  arabicTranslation: string;
  visualDirectionLabel: string;
  createdAt: number;
}

export interface ArchitectProject {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  phase: ProjectPhase;
  wizardStepIndex: number;
  selectedCreatorIds: string[];
  selectedGeneralIds: string[];
  ideaInputs: IdeaInputs;
  analysis?: IdeaAnalysis;
  concepts: VisualConcept[];
  wizardAnswers: WizardAnswers;
  referenceImages: ReferenceImageItem[];
  personProfiles?: Record<string, PersonProfile>;
  promptResult?: GeneratedPromptBundle;
  customEditedPrompt?: string;
}

export interface AppSettings {
  language: Language;
  defaultGenerator: TargetGenerator;
  defaultIdentityMode: IdentityMode;
  googleFlowDefaults: GoogleFlowConfig;
  flowModelsCatalog: string[];
  customTools: ExternalGeneratorTool[];
  toolOverrides: Record<string, Partial<ExternalGeneratorTool>>;
  promptTemplates: CustomPromptTemplate[];
  autoSaveEnabled: boolean;
  useOptionalServerAI: boolean;
  referenceMinResolution: number;
}
