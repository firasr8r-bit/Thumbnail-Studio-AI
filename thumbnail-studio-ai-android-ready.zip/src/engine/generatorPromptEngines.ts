import { getGeneratorToolById } from '../data/externalGenerators';
import { getCreatorById, getGeneralStyleById } from '../data/visualDirections';
import type {
  AppSettings,
  ArchitectProject,
  GeneratedPromptBundle,
  GoogleFlowConfig,
  GoogleFlowPromptSections,
  IdentityMode,
  Language,
  PersonProfile,
  ReferenceImageItem,
  RefinementAction,
  TargetGenerator,
} from '../types/architect';

export interface RefinementModifier {
  action: RefinementAction;
  extraPromptEn: string;
  extraArabicNote: string;
}

export interface PersonGroupSummary {
  groupId: string;
  label: string;
  refs: ReferenceImageItem[];
  primaryRef?: ReferenceImageItem;
  extraRefs: ReferenceImageItem[];
  profile: PersonProfile;
}

export interface ReferencePreflightAlert {
  id: string;
  severity: 'warning' | 'info';
  refId?: string;
  groupId?: string;
  messageAr: string;
  messageEn: string;
}

export interface ReferencePreflightReport {
  totalImages: number;
  personGroupCount: number;
  hasBlockingConflict: boolean;
  alerts: ReferencePreflightAlert[];
  groups: PersonGroupSummary[];
  assetRefs: ReferenceImageItem[];
}

export function buildPersonGroupsWithProfiles(project: ArchitectProject): {
  personGroups: PersonGroupSummary[];
  assetRefs: ReferenceImageItem[];
} {
  const map = new Map<string, ReferenceImageItem[]>();
  const assetRefs: ReferenceImageItem[] = [];

  project.referenceImages.forEach((item) => {
    if (item.role === 'person') {
      const list = map.get(item.personGroupId);
      if (list) list.push(item);
      else map.set(item.personGroupId, [item]);
    } else {
      assetRefs.push(item);
    }
  });

  const profiles = project.personProfiles ?? {};
  let idx = 1;
  const personGroups: PersonGroupSummary[] = [];

  map.forEach((refs, groupId) => {
    const prof = profiles[groupId];
    const fallbackLabel = refs[0]?.personLabel || `Person ${idx}`;
    const primaryRef =
      refs.find((r) => r.id === prof?.primaryImageId) ||
      refs.find((r) => r.isPrimary) ||
      refs[0];
    const extraRefs = refs.filter((r) => r.id !== primaryRef?.id);

    personGroups.push({
      groupId,
      label: prof?.label?.trim() || fallbackLabel,
      refs,
      primaryRef,
      extraRefs,
      profile: {
        groupId,
        label: prof?.label?.trim() || fallbackLabel,
        visibleTraits: prof?.visibleTraits ?? '',
        thumbnailRole: prof?.thumbnailRole ?? '',
        primaryImageId: primaryRef?.id,
      },
    });
    idx++;
  });

  return { personGroups, assetRefs };
}

export function analyzeReferencesPreflight(
  project: ArchitectProject,
  minResolution = 480
): ReferencePreflightReport {
  const { personGroups, assetRefs } = buildPersonGroupsWithProfiles(project);
  const alerts: ReferencePreflightAlert[] = [];

  // Check duplicate or empty person labels
  const seenLabels = new Set<string>();
  personGroups.forEach((group, idx) => {
    const norm = group.label.trim().toLowerCase();
    if (!norm) {
      alerts.push({
        id: `empty-label-${group.groupId}`,
        severity: 'warning',
        groupId: group.groupId,
        messageAr: `المجموعة رقم ${idx + 1} لا تحتوي على اسم واضح؛ يُفضّل تسميتها بوضوح لمنع التباس الهوية.`,
        messageEn: `Group #${idx + 1} has no clear label; name each person clearly to avoid confusion.`,
      });
    } else if (seenLabels.has(norm)) {
      alerts.push({
        id: `dup-label-${group.groupId}`,
        severity: 'warning',
        groupId: group.groupId,
        messageAr: `اسم "${group.label}" مكرر في أكثر من بطاقة شخص؛ استخدم أسماء مختلفة مثل Person 1 و Person 2.`,
        messageEn: `Duplicate label "${group.label}" across groups; use distinct identifiers like Person 1 and Person 2.`,
      });
    } else {
      seenLabels.add(norm);
    }

    if (group.refs.length === 0) {
      alerts.push({
        id: `no-imgs-${group.groupId}`,
        severity: 'info',
        groupId: group.groupId,
        messageAr: `لا توجد صور مرفوعة بعد لـ "${group.label}".`,
        messageEn: `No photos uploaded yet for "${group.label}".`,
      });
    }

    group.refs.forEach((ref) => {
      const diag = ref.diagnostics;
      if (diag) {
        if (Math.min(diag.width, diag.height) < minResolution) {
          alerts.push({
            id: `lowres-${ref.id}`,
            severity: 'warning',
            refId: ref.id,
            groupId: group.groupId,
            messageAr: `الصورة "${ref.fileName}" (${group.label}) دقتها منخفضة (${diag.width}×${diag.height})؛ قد تضعف مطابقة الملامح.`,
            messageEn: `"${ref.fileName}" (${group.label}) has low pixel resolution (${diag.width}×${diag.height}), which can weaken facial fidelity.`,
          });
        }
        if (diag.avgBrightness < 55) {
          alerts.push({
            id: `dark-${ref.id}`,
            severity: 'warning',
            refId: ref.id,
            groupId: group.groupId,
            messageAr: `الصورة "${ref.fileName}" إضاءتها داكنة جداً (متوسط السطوع ${diag.avgBrightness}/255)؛ يُنصح بصورة أوضح.`,
            messageEn: `"${ref.fileName}" appears quite dark (luminance ${diag.avgBrightness}/255); a better-lit portrait is recommended.`,
          });
        } else if (diag.avgBrightness > 228) {
          alerts.push({
            id: `overexp-${ref.id}`,
            severity: 'warning',
            refId: ref.id,
            groupId: group.groupId,
            messageAr: `الصورة "${ref.fileName}" ساطعة أكثر من اللازم وقد تفقد تفاصيل الوجه.`,
            messageEn: `"${ref.fileName}" is very bright/overexposed and may lose facial skin detail.`,
          });
        }
        if (diag.sharpnessScore < 20) {
          alerts.push({
            id: `blur-${ref.id}`,
            severity: 'warning',
            refId: ref.id,
            groupId: group.groupId,
            messageAr: `الصورة "${ref.fileName}" تبدو منخفضة الحدّة أو مموّهة نسبياً.`,
            messageEn: `"${ref.fileName}" scored low on edge sharpness and may appear slightly blurry.`,
          });
        }
      }

      if (ref.manualWarnings?.faceSmall) {
        alerts.push({
          id: `small-${ref.id}`,
          severity: 'warning',
          refId: ref.id,
          groupId: group.groupId,
          messageAr: `تنبيهك للصورة "${ref.fileName}": الوجه صغير جداً داخل الإطار — يُفضّل قص الوجه أو رفع لقطة أقرب.`,
          messageEn: `Marked on "${ref.fileName}": Face appears very small — cropping or using a closer portrait is recommended.`,
        });
      }
      if (ref.manualWarnings?.faceObscured) {
        alerts.push({
          id: `obscured-${ref.id}`,
          severity: 'warning',
          refId: ref.id,
          groupId: group.groupId,
          messageAr: `تنبيهك للصورة "${ref.fileName}": الوجه محجوب جزئياً (نظارة/يد/ظل) مما يضعف حماية الهوية.`,
          messageEn: `Marked on "${ref.fileName}": Face is partially obscured, which reduces likeness accuracy.`,
        });
      }
      if (ref.manualWarnings?.angleMismatch) {
        alerts.push({
          id: `angle-${ref.id}`,
          severity: 'warning',
          refId: ref.id,
          groupId: group.groupId,
          messageAr: `تنبيهك للصورة "${ref.fileName}": زاوية الوجه بعيدة جداً عن المطلوب في الصورة المصغّرة.`,
          messageEn: `Marked on "${ref.fileName}": Face angle differs significantly from the planned thumbnail angle.`,
        });
      }
    });
  });

  return {
    totalImages: project.referenceImages.length,
    personGroupCount: personGroups.length,
    hasBlockingConflict: seenLabels.size < personGroups.filter((g) => g.label.trim()).length,
    alerts,
    groups: personGroups,
    assetRefs,
  };
}

function buildStyleTokens(
  selectedCreatorIds: string[],
  selectedGeneralIds: string[],
  identityMode: IdentityMode
): string {
  const tokens: string[] = [];
  selectedCreatorIds.forEach((id) => {
    const c = getCreatorById(id);
    if (c) tokens.push(c.promptStyleTokens);
  });
  selectedGeneralIds.forEach((id) => {
    const g = getGeneralStyleById(id);
    if (g) tokens.push(`${g.lightingTokens}, ${g.compositionTokens}, ${g.moodTokens}`);
  });

  if (tokens.length === 0) {
    tokens.push(
      'high-CTR professional YouTube thumbnail art direction, crisp three-point studio lighting, vibrant color contrast, sharp subject separation'
    );
  }

  if (identityMode === 'max-priority') {
    return `${tokens.join('; ')} — apply color, lighting, framing, and energy ONLY to composition and mood while strictly forbidding any exaggeration or stylistic distortion of real facial anatomy`;
  }
  return tokens.join('; ');
}

function buildStyleSummaryLabelLocal(
  selectedCreatorIds: string[],
  selectedGeneralIds: string[],
  lang: Language
): string {
  const creators = selectedCreatorIds
    .map((id) => getCreatorById(id))
    .filter(Boolean)
    .map((c) => (lang === 'ar' ? c!.nameAr : c!.nameEn));

  const generals = selectedGeneralIds
    .map((id) => getGeneralStyleById(id))
    .filter(Boolean)
    .map((g) => (lang === 'ar' ? g!.nameAr : g!.nameEn));

  const all = [...creators, ...generals];
  if (all.length === 0) {
    return lang === 'ar' ? 'أسلوب استوديو يوتيوب احترافي متوازن' : 'Balanced Pro YouTube Studio Style';
  }
  return all.join(' + ');
}

interface PromptContext {
  toolId: TargetGenerator;
  toolName: string;
  identityMode: IdentityMode;
  flowConfig: GoogleFlowConfig;
  personGroups: PersonGroupSummary[];
  assetRefs: ReferenceImageItem[];
  conceptScene: string;
  poseSpec: string;
  expressionSpec: string;
  clothingSpec: string;
  bgSpec: string;
  colorSpec: string;
  elementsLineEn: string;
  textDirectiveEn: string;
  textContent: string;
  hasText: boolean;
  styleTokensEn: string;
  lensAngle: string;
  negativeCore: string;
  refinement?: RefinementModifier;
  uploadGuideStepsAr: string[];
  uploadGuideStepsEn: string[];
  personNumberingMap: Array<{
    personNumber: number;
    group: PersonGroupSummary;
    primaryIndex: number;
    extraIndices: number[];
    rangeLabelEn: string;
  }>;
}

function buildGoogleFlowIdentityBlock(ctx: PromptContext): string {
  const { personGroups, personNumberingMap, identityMode, flowConfig } = ctx;
  const lines: string[] = [
    'IDENTITY PRESERVATION IS THE HIGHEST PRIORITY.',
    'Use the uploaded reference images as the authoritative identity references for each person.',
  ];

  if (personNumberingMap.length > 0) {
    personNumberingMap.forEach(({ personNumber, group, primaryIndex, extraIndices, rangeLabelEn }) => {
      const traitsClause = group.profile.visibleTraits.trim()
        ? ` Key visible facial traits to retain: ${group.profile.visibleTraits.trim()}.`
        : '';
      const roleClause = group.profile.thumbnailRole.trim()
        ? ` Role in thumbnail: ${group.profile.thumbnailRole.trim()}.`
        : '';
      const perPersonExpr = group.refs[0] ? undefined : undefined;
      void perPersonExpr;
      const extraClause =
        extraIndices.length > 0
          ? ` Use Reference Image(s) #${extraIndices.join(', #')} as supporting identity angles for ${group.label}.`
          : '';

      lines.push(
        `Person ${personNumber} ("${group.label}") must retain the exact recognizable real-world identity shown in Reference Image ${primaryIndex} (${rangeLabelEn}).${traitsClause}${roleClause}${extraClause}`
      );
    });
  } else {
    lines.push(
      'No personal reference photos are attached inside this project; if you upload personal reference photos inside Google Flow, map Person 1 to Reference Image 1 (and Person 2 to Reference Image 2) explicitly.'
    );
  }

  if (personGroups.length > 1) {
    lines.push(
      'Do not swap, merge, mix, reinterpret, or transfer facial features between people.'
    );
  }

  lines.push(
    "Preserve each person's original facial structure, face shape, eyes, eyebrows, nose, lips, jawline, skin tone, hairstyle, hairline, and distinctive facial characteristics.",
    'Do not beautify, redesign, reconstruct, or replace the original faces.',
    'Do not generate lookalike people or substitute AI-created faces.',
    'Maintain natural facial proportions and realistic skin texture.'
  );

  if (identityMode === 'max-priority') {
    lines.push(
      'IDENTITY PROTECTION MODE: MAXIMUM PRIORITY — Keep facial geometry strictly faithful above any stylistic exaggeration. Do NOT alter natural facial expression into grotesque distortion, do NOT alter skin tone or hairstyle unless explicitly requested, and do NOT let creator-inspired lighting/color stylization reshape anyone’s face.'
    );
  } else {
    lines.push(
      'CREATIVE TRANSFORMATION MODE — Allow bold changes to wardrobe, background, studio lighting, and dramatic pose while keeping every person’s real facial identity locked verbatim to their uploaded reference photo.'
    );
  }

  if (flowConfig.mode === 'editing') {
    lines.push(
      'FLOW IMAGE EDITING RULE: Modify ONLY the requested scene, background, lighting, pose, and explicitly added elements while leaving original facial identities untouched.'
    );
  } else {
    lines.push(
      'Only modify the requested scene, background, lighting, composition, pose, and other explicitly requested elements.',
      'The final image must clearly depict the same real individuals shown in their respective reference photographs.'
    );
  }

  return lines.join('\n');
}

function buildGoogleFlowSections(
  project: ArchitectProject,
  ctx: PromptContext
): GoogleFlowPromptSections {
  const { flowConfig, personNumberingMap, assetRefs } = ctx;
  const modeLabel =
    flowConfig.mode === 'image'
      ? 'Google Flow — Image Mode (Static High-CTR YouTube Thumbnail)'
      : flowConfig.mode === 'agent'
      ? 'Google Flow — Agent Mode (Guided Multi-Reference Scene Execution)'
      : 'Google Flow — Image Editing Mode (Reference-Locked Scene & Backdrop Edit)';

  const modelLabel =
    flowConfig.modelChoice === 'auto-available'
      ? 'Active available Flow image model in your account'
      : flowConfig.modelChoice === 'custom' && flowConfig.customModelName?.trim()
      ? flowConfig.customModelName.trim()
      : flowConfig.modelChoice;

  const identityProtectionInstructions = buildGoogleFlowIdentityBlock(ctx);

  const perPersonRolesSummary =
    personNumberingMap.length > 0
      ? personNumberingMap
          .map(({ personNumber, group }) => {
            const expr = project.wizardAnswers.perPersonExpressions?.[group.groupId];
            const roleStr = group.profile.thumbnailRole.trim()
              ? `Role: ${group.profile.thumbnailRole.trim()}. `
              : '';
            const exprStr = expr ? `Facial expression: ${expr}.` : `Expression: ${ctx.expressionSpec}.`;
            return `- Person ${personNumber} (${group.label}): ${roleStr}${exprStr}`;
          })
          .join('\n')
      : `- Expression focus: ${ctx.expressionSpec}.`;

  const assetLine =
    assetRefs.length > 0
      ? `\nAdditional Visual Assets:\n${assetRefs
          .map(
            (a, i) =>
              `- Reference Image #${ctx.personGroups.reduce((acc, g) => acc + g.refs.length, 0) + i + 1} (${a.personLabel}): follow as ${a.role} reference.`
          )
          .join('\n')}`
      : '';

  const realismClause =
    flowConfig.realismLevel === 'photorealistic'
      ? 'True-to-life 8K DSLR photographic realism with authentic skin micro-texture, natural pores, and crisp eyes.'
      : flowConfig.realismLevel === 'natural-cinematic'
      ? 'Natural cinema-still realism (35mm lens, organic dynamic range, authentic filmic skin rendering).'
      : 'Punchy commercial YouTube studio photography with high clarity while keeping human skin and anatomy realistic.';

  const compositionInstructions = [
    `Mode & Output Spec: ${modeLabel} | Model target: ${modelLabel} | Aspect Ratio: 16:9 widescreen YouTube thumbnail (1280x720 composition), ${flowConfig.qualityLevel === 'ultra-crisp' ? 'ultra-crisp maximum subject detail' : 'high clarity'}.`,
    `Scene Hook: ${ctx.conceptScene}.`,
    `Subjects & Pose: ${ctx.poseSpec}.`,
    `Per-Subject Emotion & Framing:\n${perPersonRolesSummary}`,
    `Wardrobe: ${ctx.clothingSpec}.`,
    `Background Environment: ${ctx.bgSpec} with clean depth-of-field separation so foreground people stand out immediately.`,
    `Lighting & Color Palette: ${ctx.colorSpec}; sculpted softbox frontal key illumination with sharp directional rim light separating subjects from backdrop.`,
    `Camera & Focal Hierarchy: ${ctx.lensAngle}. Composition priority: ${flowConfig.compositionFocus === 'high-ctr' ? 'instant 0.3-second mobile click clarity' : 'balanced cinematic storytelling'}.`,
    `Visual Elements & Props: ${ctx.elementsLineEn}.`,
    `Visual Direction Principles (mood/lighting/color only — never altering face likeness): ${ctx.styleTokensEn}.`,
    `Realism Standard: ${realismClause}${assetLine}`,
    ctx.refinement ? `Refinement Focus: ${ctx.refinement.extraPromptEn}.` : '',
  ]
    .filter(Boolean)
    .join('\n\n');

  const textInstructions = !ctx.hasText
    ? 'STRICT ZERO-TEXT RULE: Do not place any words, letters, titles, numbers, watermarks, or captions anywhere in the image.'
    : `TEXT OVERLAY INSTRUCTIONS: Leave ${flowConfig.textSpace === 'clean-negative-space' ? 'a clean unobstructed negative-space zone' : 'an uncluttered corner'} without covering any person’s face or eyes. Render bold, high-contrast YouTube display text reading "${ctx.textContent}" with crisp thick outline and clean drop shadow.`;

  const avoidInstructions = [
    'AVOIDANCE INSTRUCTIONS (CRITICAL QUALITY & IDENTITY GUARDS):',
    '- Do NOT swap Person 1’s face with Person 2’s face or mix identities between people.',
    '- Do NOT merge, blend, average, or morph facial features across subjects.',
    '- Do NOT change eye shape, nose structure, mouth shape, jawline, or natural skin tone.',
    '- Do NOT change hairstyle or hairline unless explicitly requested.',
    '- Do NOT add unwanted extra people, background crowd faces, or duplicate faces.',
    '- Do NOT deform faces, hands, or fingers (no extra fingers or warped limbs).',
    '- Do NOT replace real faces with generic, airbrushed, or lookalike AI faces.',
    '- Avoid cluttered backgrounds, low contrast, flat lighting, cropped heads, or garbled text.',
  ].join('\n');

  const uploadSteps = [
    ...ctx.uploadGuideStepsEn,
    'NOTE: Reference images uploaded inside Thumbnail Prompt Architect AI are NOT automatically transferred into Google Flow — you must upload them inside Google Flow manually before generating.',
    'HONEST LIKENESS NOTE: Even with strict identity-preservation instructions, final face accuracy depends on the selected Flow model and the clarity/lighting/angle of your uploaded reference photos.',
  ];

  const mainFlowPrompt = [
    `[TARGET: ${modeLabel} | 16:9 YouTube Thumbnail]`,
    identityProtectionInstructions,
    `[SCENE, COMPOSITION & LIGHTING]\n${compositionInstructions}`,
    `[TEXT OVERLAY]\n${textInstructions}`,
    avoidInstructions,
  ].join('\n\n');

  return {
    mainFlowPrompt,
    identityProtectionInstructions,
    compositionInstructions,
    textInstructions,
    avoidInstructions,
    referenceUploadGuide: uploadSteps.join('\n'),
  };
}

export function synthesizePromptForTool(
  project: ArchitectProject,
  targetToolId: TargetGenerator,
  variationSeed: number,
  lang: Language,
  settings?: Pick<AppSettings, 'customTools' | 'toolOverrides' | 'googleFlowDefaults' | 'defaultIdentityMode' | 'promptTemplates'>,
  refinement?: RefinementModifier
): GeneratedPromptBundle {
  const tool = getGeneratorToolById(targetToolId, settings);
  const answers = project.wizardAnswers;
  const identityMode: IdentityMode =
    answers.identityMode ?? settings?.defaultIdentityMode ?? 'max-priority';
  const flowConfig: GoogleFlowConfig = answers.googleFlowConfig ??
    settings?.googleFlowDefaults ?? {
      mode: 'image',
      modelChoice: 'auto-available',
      aspectRatio: '16:9',
      qualityLevel: 'high',
      compositionFocus: 'high-ctr',
      textSpace: 'clean-negative-space',
      realismLevel: 'photorealistic',
    };

  const selectedConcept =
    project.concepts.find((c) => c.id === answers.selectedConceptId) ?? project.concepts[0];

  const exprMap: Record<string, string> = {
    'shocked-extreme':
      identityMode === 'max-priority'
        ? 'natural surprised expression with alert eyes while keeping authentic facial proportions intact'
        : 'extreme wide-eyed shock, open-mouth astonishment, raised eyebrows',
    'laughing-comedy': 'contagious open laugh and playful amused grin',
    'contrast-duo':
      'contrasting emotions: one person stunned and wide-eyed while the second smirks confidently',
    'intense-serious': 'intense dramatic focus, determined gaze, expressive eyes',
  };

  const poseMap: Record<string, string> = {
    'closeup-dominant':
      'tight expressive foreground close-up with hand pointing clearly toward the main focal element',
    'side-by-side-duel':
      'two subjects framed clearly on opposing left and right thirds facing slightly inward',
    'hands-on-head': 'upper-body shot with hands raised in dramatic disbelief',
    'cinematic-natural': 'natural unforced cinematic posture integrated authentically into the environment',
  };

  const bgMap: Record<string, string> = {
    'studio-dual-neon':
      'sleek dark professional YouTube studio backdrop split with soft opposing neon glow and subtle bokeh',
    'real-location-bokeh':
      'authentic real-world environment matching the video topic with creamy shallow depth-of-field separation',
    'mystery-dark-spotlight':
      'deep moody dark studio backdrop illuminated by one dramatic overhead spotlight beam',
    'vibrant-action-set': 'bright immaculate sunlit set or vibrant colorful arena with crisp clarity',
  };

  const colorMap: Record<string, string> = {
    'electric-blue-crimson':
      'electric cobalt blue and punchy crimson red dual-tone contrast with crisp white highlights',
    'violet-blue-studio':
      'rich royal violet and electric cyan-blue tones accented with crisp warm gold edge glow',
    'teal-amber-cinema':
      'blockbuster cinematic teal shadows balanced against warm golden-amber key light',
    'bright-yellow-cyan':
      'hyper-saturated vibrant yellow and crisp sky-blue studio palette for maximum pop',
  };

  const elemLabels: Record<string, string> = {
    arrow: 'one sleek glowing directional arrow pointing sharply at the focal detail',
    circle: 'crisp glowing highlight circle isolating the key detail',
    'question-mark': 'stylized 3D glowing question mark heightening curiosity',
    emojis: 'one subtle crisp 3D reaction emoji near the edge without blocking faces',
    props: 'tactile real-world props directly related to the video story held or visible in scene',
    vfx: 'subtle cinematic glow rim sparks and light flare accents',
  };

  const selectedElementValues = answers.elementsSelected
    .filter((id) => id !== 'none')
    .map((id) => elemLabels[id])
    .filter(Boolean);
  if (answers.customElementNote?.trim()) {
    selectedElementValues.push(answers.customElementNote.trim());
  }

  const elementsLineEn =
    answers.elementsSelected.includes('none') || selectedElementValues.length === 0
      ? selectedConcept?.elementsTokensEn || 'clean uncluttered scene with zero stickers or chaotic overlays'
      : selectedElementValues.join(', ');

  const hasText = answers.textMode !== 'no';
  const textContent =
    answers.thumbnailText.trim() || (lang === 'ar' ? 'من الأذكى؟!' : 'WHO WINS?!');

  const textDirectiveEn = !hasText
    ? 'TEXT RULE: ZERO TEXT anywhere in the image. Do not generate words, captions, titles, letters, numbers, watermarks, or UI badges.'
    : `THUMBNAIL TEXT OVERLAY: Include ultra-bold, clean, high-contrast 3D YouTube display typography reading "${textContent}" with crisp thick dark outline and soft drop shadow, placed in clean negative space without covering any face or eyes.`;

  const variationAngles = [
    'wide dynamic 28mm cinema lens perspective with crisp foreground subject dominance',
    'punchy 35mm medium close-up studio lens perspective with intense eye-level engagement',
    'dramatic slightly low-angle 24mm hero framing emphasizing scale and emotion',
    'razor-sharp balanced dual-thirds editorial framing optimized for 0.3s mobile clarity',
  ];
  const lensAngle = variationAngles[Math.abs(variationSeed) % variationAngles.length];

  const { personGroups, assetRefs } = buildPersonGroupsWithProfiles(project);

  // Build strict reference index map (Primary first for each person, then extras)
  let runningIdx = 1;
  const personNumberingMap: PromptContext['personNumberingMap'] = [];
  const uploadGuideStepsAr: string[] = [];
  const uploadGuideStepsEn: string[] = [];

  personGroups.forEach((group, gIdx) => {
    const orderedRefs = [
      ...(group.primaryRef ? [group.primaryRef] : []),
      ...group.extraRefs,
    ];
    const startIdx = runningIdx;
    const primaryIndex = startIdx;
    const extraIndices: number[] = [];
    orderedRefs.forEach((_, idx) => {
      if (idx > 0) extraIndices.push(startIdx + idx);
    });
    runningIdx += orderedRefs.length;

    const rangeLabelEn =
      orderedRefs.length === 1
        ? `Reference Image #${startIdx}`
        : `Reference Images #${startIdx}–#${startIdx + orderedRefs.length - 1}`;
    const rangeLabelAr =
      orderedRefs.length === 1
        ? `الصورة المرجعية رقم ${startIdx}`
        : `الصور المرجعية من ${startIdx} إلى ${startIdx + orderedRefs.length - 1}`;

    personNumberingMap.push({
      personNumber: gIdx + 1,
      group,
      primaryIndex,
      extraIndices,
      rangeLabelEn,
    });

    uploadGuideStepsAr.push(
      `${gIdx + 1}. ارفع صور "${group.label}" بالترتيب (${rangeLabelAr}) — الصورة الأساسية أولاً (${orderedRefs[0]?.fileName ?? ''}).`
    );
    uploadGuideStepsEn.push(
      `${gIdx + 1}. Upload ${group.label}'s photo(s) in order (${rangeLabelEn}) — primary portrait first (${orderedRefs[0]?.fileName ?? ''}).`
    );
  });

  assetRefs.forEach((asset) => {
    const idx = runningIdx++;
    uploadGuideStepsAr.push(
      `ارفع "${asset.personLabel || asset.fileName}" كصورة مرجعية رقم ${idx} (${asset.role}).`
    );
    uploadGuideStepsEn.push(
      `Attach "${asset.personLabel || asset.fileName}" as Reference Image #${idx} (${asset.role}).`
    );
  });

  if (personGroups.length === 0) {
    uploadGuideStepsAr.push(
      'لم ترفع صوراً شخصية داخل المشروع بعد؛ إذا أردت ظهور أشخاص حقيقيين، ارفع صورهم داخل المولد الخارجي بالترتيب وحدد اسم كل شخص.'
    );
    uploadGuideStepsEn.push(
      'No portrait references attached here; if depicting real people, upload their photos sequentially in your external tool.'
    );
  }

  const conceptScene =
    answers.customConceptNote?.trim() ||
    selectedConcept?.sceneTokensEn ||
    `high-impact YouTube thumbnail illustrating "${project.ideaInputs.videoTitle}"`;

  const expressionSpec =
    exprMap[answers.expressionChoice] ||
    selectedConcept?.expressionTokensEn ||
    'high-impact expressive emotion';
  const poseSpec =
    poseMap[answers.poseChoice] ||
    selectedConcept?.poseTokensEn ||
    'dynamic engaging YouTube foreground pose';
  const bgSpec =
    bgMap[answers.backgroundChoice] ||
    selectedConcept?.backgroundTokensEn ||
    'clean dramatic studio environment with soft depth blur';
  const colorSpec =
    colorMap[answers.colorChoice] ||
    selectedConcept?.colorTokensEn ||
    'electric blue and vivid crimson contrast with gold highlights';
  const clothingSpec =
    answers.clothingNote?.trim() ||
    (identityMode === 'max-priority'
      ? 'clean modern creator wardrobe matching natural proportions without distorting head or neck'
      : 'bold stylish creator wardrobe with crisp fabric texture and sharp color contrast against background');

  const styleTokensEn = buildStyleTokens(
    project.selectedCreatorIds,
    project.selectedGeneralIds,
    identityMode
  );

  const negativeCore =
    'swapped faces, merged faces, mixed identities, changed eye shape, changed nose, changed lips, altered skin tone, unrequested hairstyle change, extra unwanted people, duplicate faces, deformed facial features, lookalike substitute face, extra fingers, deformed hands, plastic airbrushed skin, blurry subject, cluttered background, low contrast, watermark' +
    (!hasText ? ', text, letters, typography, captions, numbers, logos' : ', garbled misspelled text');

  const ctx: PromptContext = {
    toolId: targetToolId,
    toolName: tool.name,
    identityMode,
    flowConfig,
    personGroups,
    assetRefs,
    conceptScene,
    poseSpec,
    expressionSpec,
    clothingSpec,
    bgSpec,
    colorSpec,
    elementsLineEn,
    textDirectiveEn,
    textContent,
    hasText,
    styleTokensEn,
    lensAngle,
    negativeCore,
    refinement,
    uploadGuideStepsAr,
    uploadGuideStepsEn,
    personNumberingMap,
  };

  let mainPrompt = '';
  let flowSections: GoogleFlowPromptSections | undefined;
  let usageInstructionsAr = '';
  let usageInstructionsEn = '';
  let recommendedSettingsAr = tool.recommendedSettingsAr;
  let recommendedSettingsEn = tool.recommendedSettingsEn;

  const genericIdentitySentence =
    personNumberingMap.length > 0
      ? personNumberingMap
          .map(({ personNumber, group, rangeLabelEn }) => {
            const traits = group.profile.visibleTraits.trim()
              ? ` (${group.profile.visibleTraits.trim()})`
              : '';
            const role = group.profile.thumbnailRole.trim()
              ? ` as ${group.profile.thumbnailRole.trim()}`
              : '';
            const expr = answers.perPersonExpressions?.[group.groupId]
              ? ` showing ${answers.perPersonExpressions[group.groupId]}`
              : '';
            return `Person ${personNumber} "${group.label}" strictly locked to ${rangeLabelEn}${traits}${role}${expr}`;
          })
          .join('; ') +
        '. Keep every person completely separate without swapping, merging, or beautifying faces.'
      : 'Render authentic, unmorphed realistic human faces with genuine skin texture and crisp eyes.';

  // Check if user defined a custom prompt template for this tool or if tool is custom
  const matchingTemplate = settings?.promptTemplates?.find((tpl) => tpl.toolId === targetToolId);
  const activeCustomTemplate = tool.customTemplate || matchingTemplate?.template;

  if (targetToolId === 'google-flow') {
    flowSections = buildGoogleFlowSections(project, ctx);
    mainPrompt = flowSections.mainFlowPrompt;

    if (flowConfig.mode === 'image') {
      usageInstructionsAr = [
        '1. افتح مشروعك في Google Flow.',
        '2. اختر Image عند إنشاء صورة ثابتة.',
        `3. اختر النموذج المتاح الذي تريده${flowConfig.modelChoice !== 'auto-available' ? ` (مثل ${flowConfig.modelChoice})` : ''}.`,
        '4. ارفع الصور المرجعية للأشخاص من Add Image بالترتيب المحدد في القسم F.',
        '5. تأكد أن كل صورة مضافة كمرجع بصري.',
        '6. انسخ البرومبت الرئيسي (القسم A) والصقه في مربع الكتابة.',
        '7. راجع إعدادات Aspect Ratio واختر 16:9.',
        '8. ابدأ التوليد.',
        'تنبيه مهم: الصور المرفوعة داخل تطبيقنا لا تنتقل تلقائياً إلى Google Flow — يجب رفعها داخل Flow أيضاً.',
      ].join('\n');
      usageInstructionsEn = [
        '1. Open your project in Google Flow.',
        '2. Choose Image mode to generate a static thumbnail.',
        `3. Select your desired available model${flowConfig.modelChoice !== 'auto-available' ? ` (e.g. ${flowConfig.modelChoice})` : ''}.`,
        '4. Upload each person’s reference photo via Add Image in the exact order shown in Section F.',
        '5. Confirm each uploaded photo is attached as a visual reference.',
        '6. Copy Main Flow Prompt (Section A) and paste it into the Flow prompt box.',
        '7. Verify Aspect Ratio is set to 16:9.',
        '8. Generate the image.',
        'Important: Photos uploaded inside our app do NOT transfer automatically to Google Flow — upload them inside Flow as well.',
      ].join('\n');
    } else if (flowConfig.mode === 'agent') {
      usageInstructionsAr = [
        '1. افتح مشروعك في Google Flow وانتقل إلى وضع Flow Agent.',
        '2. أضف الصور المرجعية لكل شخص مباشرة داخل مربع Agent Prompt بالترتيب المرقّم.',
        '3. اذكر بوضوح داخل Agent Prompt أن الصورة 1 تخص الشخص 1 والصورة 2 تخص الشخص 2.',
        '4. الصق البرومبت الرئيسي (القسم A) في مربع Agent Prompt.',
        '5. اطلب صراحةً نسبة عرض 16:9 وجودة صورة مصغّرة لليوتيوب.',
        '6. نفّذ الطلب وراجع مطابقة الوجوه قبل الاعتماد.',
        'تنبيه: لا تنتقل صورك تلقائياً من هنا إلى Flow Agent — أرفقها في مربع Agent Prompt يدوياً.',
      ].join('\n');
      usageInstructionsEn = [
        '1. Open your project in Google Flow and switch to Flow Agent Mode.',
        '2. Attach all person reference images directly inside the Agent Prompt box in numbered order.',
        '3. Ensure the Agent Prompt pairs Reference Image 1 -> Person 1 and Reference Image 2 -> Person 2.',
        '4. Paste Main Flow Prompt (Section A) into the Agent Prompt box.',
        '5. Confirm 16:9 widescreen framing in the Agent instructions.',
        '6. Run generation and review face fidelity.',
        'Important: References stored in this app do NOT sync automatically to Google Flow — attach them inside the Agent Prompt manually.',
      ].join('\n');
    } else {
      usageInstructionsAr = [
        '1. افتح مشروعك في Google Flow واختر Image Editing.',
        '2. حدد الصورة الأساسية أو المشهد المراد تعديله وأرفق صور المرجع للأشخاص من Add Image.',
        '3. الصق البرومبت الرئيسي الذي يحصر التغيير في الخلفية والإضاءة مع تثبيت ملامح الوجه.',
        '4. تأكد من نسبة العرض 16:9 ثم ابدأ التعديل.',
        'تنبيه: يجب رفع الصور المرجعية يدوياً داخل واجهة Google Flow أيضاً.',
      ].join('\n');
      usageInstructionsEn = [
        '1. Open your project in Google Flow and select Image Editing.',
        '2. Select your base image and attach person references via Add Image.',
        '3. Paste Main Flow Prompt so only scene/lighting/pose updates while facial identity remains locked.',
        '4. Verify 16:9 aspect ratio and run the edit.',
        'Important: You must upload the reference photos inside Google Flow manually as well.',
      ].join('\n');
    }

    recommendedSettingsAr = `الوضع: ${flowConfig.mode.toUpperCase()} | النموذج: ${flowConfig.modelChoice} | النسبة: 16:9 | الواقعية: ${flowConfig.realismLevel}`;
    recommendedSettingsEn = `Mode: ${flowConfig.mode.toUpperCase()} | Model: ${flowConfig.modelChoice} | Ratio: 16:9 | Realism: ${flowConfig.realismLevel}`;
  } else if (activeCustomTemplate) {
    mainPrompt = activeCustomTemplate
      .replace(/\{SCENE\}/g, conceptScene)
      .replace(/\{IDENTITY\}/g, genericIdentitySentence)
      .replace(/\{POSE\}/g, poseSpec)
      .replace(/\{EXPRESSION\}/g, expressionSpec)
      .replace(/\{BACKGROUND\}/g, bgSpec)
      .replace(/\{COLORS\}/g, colorSpec)
      .replace(/\{TEXT\}/g, textDirectiveEn)
      .replace(/\{ELEMENTS\}/g, elementsLineEn)
      .replace(/\{STYLE\}/g, styleTokensEn);
    usageInstructionsAr = `تم بناء هذا البرومبت باستخدام القالب المخصص لأداة ${tool.name}.`;
    usageInstructionsEn = `Built using the custom prompt template configured for ${tool.name}.`;
  } else if (targetToolId === 'nano-banana' || targetToolId === 'nano-banana-pro') {
    const isPro = targetToolId === 'nano-banana-pro';
    mainPrompt = [
      `Create a 16:9 photorealistic YouTube thumbnail (${isPro ? 'high-craft detail, crisp facial accuracy, clean typography support' : 'focused crisp scene and facial fidelity'}).`,
      `KEEP IDENTITIES FIXED: ${genericIdentitySentence} Preserve eyes, nose, lips, jawline, skin tone, and hair strictly without swapping or blending faces.`,
      `SCENE & POSE: ${conceptScene}. ${poseSpec}. Expressions: ${expressionSpec}. Wardrobe: ${clothingSpec}.`,
      `ENVIRONMENT & LIGHTING: ${bgSpec}. Color & lighting: ${colorSpec} with crisp frontal key light and rim separation. ${styleTokensEn}.`,
      `ELEMENTS & TEXT: ${elementsLineEn}. ${textDirectiveEn}`,
      `AVOID: Do not swap or blend faces, avoid plastic smoothing, deformed hands, extra people, or garbled text.${refinement ? ` Refinement: ${refinement.extraPromptEn}.` : ''}`,
    ].join('\n\n');
    usageInstructionsAr = `1) افتح ${tool.name} وأرفق صور الأشخاص المرجعية بالترتيب.\n2) الصق البرومبت الموجّه الذي يفصل بين الثابت (الهوية) والمتغير (المشهد).\n3) تأكد من اختيار نسبة 16:9.`;
    usageInstructionsEn = `1) Open ${tool.name} and attach numbered person references first.\n2) Paste the focused prompt separating fixed facial traits from scene changes.\n3) Confirm 16:9 landscape aspect ratio.`;
  } else if (targetToolId === 'midjourney') {
    const mjParts = [
      `Photorealistic 16:9 YouTube thumbnail, ${conceptScene}`,
      genericIdentitySentence,
      poseSpec,
      expressionSpec,
      clothingSpec,
      bgSpec,
      colorSpec,
      elementsLineEn,
      hasText ? `bold clean display title "${textContent}"` : 'no text anywhere',
      lensAngle,
      styleTokensEn,
      refinement?.extraPromptEn ?? '',
    ]
      .filter(Boolean)
      .join(', ');
    mainPrompt = `${mjParts} --ar 16:9 --style raw --no swapped faces, merged faces, deformed hands, extra fingers, watermark, clutter${!hasText ? ', text, letters' : ''}`;
    usageInstructionsAr =
      '1) الصق البرومبت كاملاً في Midjourney (يتضمن المعاملات الموثقة --ar 16:9 و --style raw و --no).\n2) إذا استخدمت صوراً مرجعية، أضف رابط صورة كل شخص بشكل مستقل عبر مرجع الشخصية الموثق (--cref / --oref).';
    usageInstructionsEn =
      '1) Paste the full prompt into Midjourney (uses documented --ar 16:9, --style raw, and --no flags).\n2) When using portrait references, attach separate character reference URLs per person.';
  } else if (targetToolId === 'stable-diffusion') {
    mainPrompt = `(masterpiece, photorealistic YouTube thumbnail:1.2), (16:9 widescreen framing:1.15), ${conceptScene}, ${poseSpec}, ${expressionSpec}, ${clothingSpec}, ${bgSpec}, ${colorSpec}, ${elementsLineEn}, ${styleTokensEn}, dramatic rim lighting, crisp studio catchlights, sharp focus on eyes, natural skin micro-texture${refinement ? `, ${refinement.extraPromptEn}` : ''}\n\n[Per-Person Reference Conditioning]\n${genericIdentitySentence}\n${textDirectiveEn}`;
    usageInstructionsAr =
      '1) الصق البرومبت في خانة Positive Prompt.\n2) انسخ حقل Negative Prompt في خانة Negative المخصصة.\n3) استخدم IP-Adapter FaceID أو InstantID بقناع منفصل لكل شخص لمنع دمج الوجوه.';
    usageInstructionsEn =
      '1) Paste into Positive Prompt.\n2) Paste the separate Negative Prompt into the Negative input.\n3) Use separate IP-Adapter FaceID / InstantID regional masks per person.';
  } else if (targetToolId === 'flux') {
    mainPrompt = `A razor-sharp, photorealistic 16:9 widescreen YouTube thumbnail photograph depicting ${conceptScene}. ${genericIdentitySentence} Pose and framing: ${poseSpec}. Facial emotions: ${expressionSpec}. Wardrobe: ${clothingSpec}. Setting: ${bgSpec}, softly defocused behind the subjects. Lighting and color palette: ${colorSpec}, sculpted frontal key light with crisp rim separation along shoulders and hair. Visual elements: ${elementsLineEn}. ${textDirectiveEn} Photography direction: ${lensAngle}, authentic skin pores and fabric texture, ${styleTokensEn}.${refinement ? ` ${refinement.extraPromptEn}.` : ''}`;
    usageInstructionsAr =
      '1) الصق البرومبت في واجهة FLUX أو FLUX Kontext (صياغة نثرية طبيعية بدون وسوم مبالغة).\n2) إذا استخدمت FLUX Kontext، ارفع صور المرجع واربطها بوضوح باسم كل شخص.';
    usageInstructionsEn =
      '1) Paste this natural photographic prose prompt into FLUX or FLUX Kontext (free of weighted tag spam).\n2) In FLUX Kontext, attach reference portraits matching each labeled person.';
  } else if (targetToolId === 'adobe-firefly') {
    mainPrompt = `Commercial studio YouTube thumbnail photograph in 16:9 widescreen framing: ${conceptScene}. Subjects: ${poseSpec}, ${expressionSpec}, wearing ${clothingSpec}. Background: ${bgSpec}. Lighting and color: ${colorSpec}, three-point studio softbox lighting with clean rim highlights. Visual accents: ${elementsLineEn}. ${!hasText ? 'No text, letters, or logos anywhere in frame.' : `Clean space reserved for bold headline "${textContent}".`} Authentic DSLR detail, natural skin texture.${refinement ? ` ${refinement.extraPromptEn}.` : ''}`;
    usageInstructionsAr =
      '1) افتح Adobe Firefly وحدد Aspect Ratio: Widescreen (16:9) وContent Type: Photo.\n2) استخدم Structure / Style Reference في الشريط الجانبي إذا أردت، وتجنب أسماء المشاهير.';
    usageInstructionsEn =
      '1) Open Adobe Firefly, select Widescreen (16:9) and Content Type: Photo.\n2) Use Structure/Style Reference slots if needed; prompt is kept commercially clean.';
  } else if (targetToolId === 'ideogram') {
    const textHeadline = hasText
      ? `Bold, ultra-crisp 3D YouTube display typography reading "${textContent}" with thick dark outline and clean drop shadow placed cleanly without covering any face.`
      : 'Strictly ZERO text, letters, or words anywhere in the frame.';
    mainPrompt = `16:9 widescreen YouTube thumbnail photograph: ${conceptScene}. ${textHeadline} ${genericIdentitySentence} Pose: ${poseSpec}. Expressions: ${expressionSpec}. Wardrobe: ${clothingSpec}. Background: ${bgSpec}. Colors and lighting: ${colorSpec}, sculpted rim lighting. Visual accents: ${elementsLineEn}. ${styleTokensEn}.${refinement ? ` ${refinement.extraPromptEn}.` : ''}`;
    usageInstructionsAr =
      '1) افتح Ideogram واختر نسبة 16:9.\n2) ضع Magic Prompt على Off إذا أردت التزاماً حرفياً بالنص داخل الصورة.\n3) انسخ Negative Prompt في خانة Negative.';
    usageInstructionsEn =
      '1) Select 16:9 aspect ratio in Ideogram.\n2) Keep Magic Prompt Off when exact quoted text spelling matters.\n3) Copy the separate Negative Prompt into the Negative box.';
  } else if (targetToolId === 'leonardo') {
    mainPrompt = `Photorealistic 16:9 YouTube thumbnail, ${conceptScene}. ${genericIdentitySentence} Pose: ${poseSpec}. Facial expressions: ${expressionSpec}. Wardrobe: ${clothingSpec}. Background: ${bgSpec}. Color grading and lighting: ${colorSpec}, sharp key light and dramatic rim backlight. Accents: ${elementsLineEn}. ${textDirectiveEn} Style direction: ${styleTokensEn}.${refinement ? ` ${refinement.extraPromptEn}.` : ''}`;
    usageInstructionsAr =
      '1) في Leonardo AI فعّل 16:9 وارفع صورة الشخص في Character Reference.\n2) فعّل Negative Prompt والصق الحقل المخصص لمنع تشوه الأيدي والوجوه.';
    usageInstructionsEn =
      '1) Set 16:9 in Leonardo AI and attach portrait via Image Guidance -> Character Reference.\n2) Enable Negative Prompt and paste the dedicated Negative block.';
  } else if (targetToolId === 'recraft') {
    mainPrompt = `High-clarity 16:9 YouTube thumbnail studio photograph structured with disciplined visual hierarchy: ${conceptScene}. Color palette discipline: ${colorSpec}. Foreground subjects: ${genericIdentitySentence} Pose: ${poseSpec}. Expressions: ${expressionSpec}. Wardrobe: ${clothingSpec}. Cleanly separated background: ${bgSpec}. Minimal accents: ${elementsLineEn}. ${textDirectiveEn}${refinement ? ` ${refinement.extraPromptEn}.` : ''}`;
    usageInstructionsAr =
      '1) في Recraft اختر 16:9 وأسلوب Photorealism.\n2) الصق البرومبت للاستفادة من ضبط الألوان وتوزيع المساحات.';
    usageInstructionsEn =
      '1) Choose 16:9 and Photorealism style in Recraft.\n2) Paste the layout-structured prompt for disciplined color and zone clarity.';
  } else if (targetToolId === 'chatgpt') {
    mainPrompt = `Create a photorealistic 16:9 widescreen YouTube thumbnail (${conceptScene}).\n\nIDENTITY & REFERENCE MAPPING:\n${genericIdentitySentence}\n\nSCENE & LAYOUT:\n- Pose: ${poseSpec}.\n- Facial Expressions: ${expressionSpec}.\n- Wardrobe: ${clothingSpec}.\n- Background: ${bgSpec}.\n- Colors & Lighting: ${colorSpec} with sculpted frontal key light and crisp rim separation.\n- Elements: ${elementsLineEn}.\n- ${textDirectiveEn}\n- Visual Style: ${styleTokensEn}.\n\nAVOID / DO NOT:\nDo not swap or blend faces between people, do not airbrush skin into plastic, do not distort hands/fingers, and do not crop heads.${refinement ? ` Extra direction: ${refinement.extraPromptEn}.` : ''}`;
    usageInstructionsAr =
      '1) افتح ChatGPT وارفع الصور المرجعية للأشخاص أولاً بالترتيب.\n2) الصق البرومبت مباشرة؛ تعليمات الهوية والتجنّب مدمجة بداخله.\n3) راجع الصورة الناتجة واطلب تعديلاً إذا تغير أي تفصيل في الوجه.';
    usageInstructionsEn =
      '1) Upload numbered person reference photos first in ChatGPT.\n2) Paste the prompt directly (avoidance & mapping are built inside).\n3) Confirm 16:9 landscape framing.';
  } else {
    // Google Gemini & Generic 16-point comprehensive prompt
    const identityLinesDetailed =
      personNumberingMap.length > 0
        ? personNumberingMap
            .map(({ personNumber, group, primaryIndex, extraIndices, rangeLabelEn }) => {
              const traits = group.profile.visibleTraits.trim()
                ? ` Visible traits: ${group.profile.visibleTraits.trim()}.`
                : '';
              const role = group.profile.thumbnailRole.trim()
                ? ` Role: ${group.profile.thumbnailRole.trim()}.`
                : '';
              const extra =
                extraIndices.length > 0
                  ? ` Supporting photos: #${extraIndices.join(', #')}.`
                  : '';
              const perExpr = answers.perPersonExpressions?.[group.groupId]
                ? ` Expression: ${answers.perPersonExpressions[group.groupId]}.`
                : '';
              return `- Person ${personNumber} ("${group.label}") MUST match Reference Image #${primaryIndex} (${rangeLabelEn}) strictly.${traits}${role}${extra}${perExpr} Never blend, swap, or beautify features.`;
            })
            .join('\n')
        : '- Render distinct, unmorphed realistic faces; if uploading portraits in your tool, bind Person 1 and Person 2 explicitly to their image numbers.';

    mainPrompt = [
      `1. CORE SCENE (16:9 YouTube Thumbnail): ${conceptScene}.`,
      `2. STRICT IDENTITY PRESERVATION:\n${identityLinesDetailed}`,
      `3. POSE & BODY LANGUAGE: ${poseSpec}.`,
      `4. FACIAL EXPRESSIONS: ${expressionSpec} with crisp eye catchlights.`,
      `5. WARDROBE: ${clothingSpec}.`,
      `6. BACKGROUND: ${bgSpec}, cleanly separated via shallow depth of field.`,
      `7. LIGHTING: Sculpted softbox frontal key light paired with sharp rim light.`,
      `8. COLOR PALETTE: ${colorSpec}.`,
      `9. CAMERA: ${lensAngle}.`,
      `10. VISUAL ELEMENTS: ${elementsLineEn}.`,
      `11. ${textDirectiveEn}`,
      `12. ART DIRECTION: ${styleTokensEn}.`,
      `13. REALISM: Full-frame DSLR photo detail, authentic skin pores, sharp lashes.`,
      `14. ANATOMY GUARD: Clean 5-finger hands, coherent physics, no cropped heads.`,
      refinement
        ? `15. REFINEMENT: ${refinement.extraPromptEn}.`
        : '15. FOCUS: Single clear high-CTR story beat readable on mobile.',
      !tool.supportsSeparateNegative
        ? '16. AVOIDANCE LOCK: Do NOT merge/swap faces, change eyes/nose/lips/skin tone, deform hands, or add unwanted extra people.'
        : '16. EXPORT INTENT: Optimized for 16:9 (1280x720) YouTube thumbnails.',
    ].join('\n\n');

    usageInstructionsAr =
      targetToolId === 'gemini'
        ? '1) افتح Google Gemini وأرفق صور الأشخاص بالترتيب داخل نفس الرسالة.\n2) الصق البرومبت الرئيسي مباشرة (قواعد التجنب مدمجة بنهايته).\n3) تأكد من الحفاظ على نسبة 16:9.'
        : tool.referenceHandlingAr;
    usageInstructionsEn =
      targetToolId === 'gemini'
        ? '1) Open Google Gemini and attach person photos in numbered order inside the same message.\n2) Paste the Main Prompt directly (avoidance rules are embedded).\n3) Verify 16:9 landscape aspect ratio.'
        : tool.referenceHandlingEn;
  }

  const directionSummary = buildStyleSummaryLabelLocal(
    project.selectedCreatorIds,
    project.selectedGeneralIds,
    lang
  );

  const arabicTranslation = [
    `• الأداة المختارة: ${tool.name}${targetToolId === 'google-flow' ? ` (وضع ${flowConfig.mode} - نموذج ${flowConfig.modelChoice})` : ''}.`,
    `• وضع حماية الهوية: ${identityMode === 'max-priority' ? 'أولوية قصوى لحماية الهوية الحقيقية وتقليل أي تحريف للوجه' : 'تحوّل إبداعي أوسع في الخلفية والملابس مع إبقاء قفل هوية الوجه'}.`,
    `• المشهد والفكرة: صورة مصغّرة احترافية لليوتيوب (16:9) تجسد "${project.ideaInputs.videoTitle || project.name}" بأسلوب ${buildStyleSummaryLabelLocal(project.selectedCreatorIds, project.selectedGeneralIds, 'ar')}.`,
    personNumberingMap.length > 0
      ? `• ربط الأشخاص المرجعيين (${personNumberingMap.length}): ${personNumberingMap
          .map(
            (m) =>
              `الشخص ${m.personNumber} (${m.group.label}) -> الصورة الأساسية #${m.primaryIndex}${m.group.profile.visibleTraits ? ` [${m.group.profile.visibleTraits}]` : ''}`
          )
          .join(' | ')} مع منع تبديل أو دمج الوجوه نهائياً.`
      : '• الهوية البصرية: لم تُرفع صور أشخاص بعد، والبرومبت مهيأ لإضافة مراجع بشرية دون تشويه.',
    `• النص والعناصر: ${!hasText ? 'بدون أي نص داخل الصورة' : `نص بارز "${textContent}"`}، والعناصر: ${answers.elementsSelected.includes('none') ? 'نظيفة بدون رموز زائدة' : answers.elementsSelected.join('، ')}.`,
    refinement ? `• التحسين المطبّق: ${refinement.extraArabicNote}.` : '',
  ]
    .filter(Boolean)
    .join('\n');

  return {
    id: `prompt-${Date.now()}-${variationSeed}`,
    createdAt: Date.now(),
    targetGenerator: targetToolId,
    targetGeneratorName: tool.name,
    identityMode,
    mainPrompt,
    negativePrompt: negativeCore,
    supportsSeparateNegative: tool.supportsSeparateNegative,
    arabicTranslation,
    flowSections,
    designSummary: {
      ideaSummary: project.ideaInputs.videoTitle.trim() || project.name,
      visualDirection: directionSummary,
      sceneSummary: selectedConcept?.name || (lang === 'ar' ? 'مشهد مخصص' : 'Custom Scene'),
      colorsSummary: colorSpec,
      expressionsSummary: expressionSpec,
    },
    usageInstructionsAr,
    usageInstructionsEn,
    referenceUploadGuideAr: uploadGuideStepsAr.join('\n'),
    referenceUploadGuideEn: uploadGuideStepsEn.join('\n'),
    recommendedSettingsAr,
    recommendedSettingsEn,
    variationSeed,
  };
}
