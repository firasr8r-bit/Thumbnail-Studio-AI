import { getAllGeneratorTools } from '../data/externalGenerators';
import { getCreatorById, getGeneralStyleById } from '../data/visualDirections';
import type {
  AppSettings,
  ArchitectProject,
  GeneratedPromptBundle,
  IdeaAnalysis,
  IdeaInputs,
  Language,
  RefinementAction,
  VisualConcept,
} from '../types/architect';
import {
  type RefinementModifier,
  synthesizePromptForTool,
} from './generatorPromptEngines';

export interface WizardOption {
  id: string;
  labelAr: string;
  labelEn: string;
  descAr?: string;
  descEn?: string;
  valueEn: string;
}

export interface WizardStepMeta {
  id:
    | 'concept'
    | 'expressions'
    | 'pose'
    | 'background'
    | 'colors'
    | 'text'
    | 'elements'
    | 'generator';
  titleAr: string;
  titleEn: string;
  questionAr: string;
  questionEn: string;
  options: WizardOption[];
  supportsPerPerson?: boolean;
  allowMultiple?: boolean;
}

interface DetectedTheme {
  key: 'versus' | 'prank' | 'horror' | 'vlog' | 'education' | 'gaming' | 'mystery' | 'comedy' | 'general';
  labelAr: string;
  labelEn: string;
  isDuoOrGroup: boolean;
}

export function detectIdeaTheme(inputs: IdeaInputs, selectedGeneralIds: string[]): DetectedTheme {
  const combined = `${inputs.videoTitle} ${inputs.ideaDescription} ${inputs.contentType} ${inputs.participantsDescription} ${inputs.coreMessage}`.toLowerCase();

  const hasTwoOrMore =
    /شخصين|اثنين|صديق|صديقي|اخوي|أخوي|اختي|زوجتي|زوجي|تحدي بين|مقابل|vs|duo|two|friends|couple|بعرف الثاني|أكثر|ضد/.test(
      combined
    ) ||
    selectedGeneralIds.includes('versus');

  if (
    /مين بعرف|يعرفني|صداق|مقارنة|ضد|versus|vs\b|تحدي بين/.test(combined) ||
    selectedGeneralIds.includes('versus')
  ) {
    return {
      key: 'versus',
      labelAr: 'تحدي ومواجهة تفاعلية',
      labelEn: 'Interactive Duel / Comparison Challenge',
      isDuoOrGroup: true,
    };
  }
  if (/مقلب|مقالب|خدع|فاجأ|prank/.test(combined) || selectedGeneralIds.includes('pranks')) {
    return {
      key: 'prank',
      labelAr: 'مقلب وردة فعل مفاجئة',
      labelEn: 'Prank & Surprise Reaction',
      isDuoOrGroup: hasTwoOrMore,
    };
  }
  if (/رعب|جن|شبح|مسكون|ظلام|خوف|horror|scary/.test(combined) || selectedGeneralIds.includes('horror')) {
    return {
      key: 'horror',
      labelAr: 'رعب وتشويق مظلم',
      labelEn: 'Dark Horror & Suspense',
      isDuoOrGroup: hasTwoOrMore,
    };
  }
  if (/لغز|سر|غامض|تحقيق|اختفاء|mystery|secret/.test(combined) || selectedGeneralIds.includes('mystery')) {
    return {
      key: 'mystery',
      labelAr: 'غموض واكتشاف سر',
      labelEn: 'Mystery & Investigation',
      isDuoOrGroup: hasTwoOrMore,
    };
  }
  if (/لعب|قيمنق|فورتنايت|ماينكرافت|فيفا|ببجي|gaming|stream|game/.test(combined) || selectedGeneralIds.includes('gaming')) {
    return {
      key: 'gaming',
      labelAr: 'ألعاب وتحديات رقمية',
      labelEn: 'Gaming & Competitive Play',
      isDuoOrGroup: hasTwoOrMore,
    };
  }
  if (/معلوم|شرح|تاريخ|علم|كيف|لماذا|درس|دحيح|تعليم|review|tech|ai|study/.test(combined) || selectedGeneralIds.includes('education')) {
    return {
      key: 'education',
      labelAr: 'معلومات وسرد معرفي',
      labelEn: 'Edutainment & Deep Dive',
      isDuoOrGroup: hasTwoOrMore,
    };
  }
  if (/سفر|رحلة|فلوق|يوم في|بلد|جربت|اشتريت|vlog|travel|trip/.test(combined) || selectedGeneralIds.includes('vlogs') || selectedGeneralIds.includes('adventure')) {
    return {
      key: 'vlog',
      labelAr: 'فلوق وتجربة واقعية',
      labelEn: 'Vlog & Real-World Experience',
      isDuoOrGroup: hasTwoOrMore,
    };
  }
  if (/ضحك|كوميد|مضحك|سخر|طقطق|comedy|funny/.test(combined) || selectedGeneralIds.includes('comedy')) {
    return {
      key: 'comedy',
      labelAr: 'كوميدي ترفيهي',
      labelEn: 'Comedic Entertainment',
      isDuoOrGroup: hasTwoOrMore,
    };
  }

  return {
    key: 'general',
    labelAr: inputs.contentType.trim() || 'محتوى ترفيهي مشوّق',
    labelEn: inputs.contentType.trim() || 'Engaging Story & Entertainment',
    isDuoOrGroup: hasTwoOrMore,
  };
}

export function buildStyleSummaryLabel(
  selectedCreatorIds: string[],
  selectedGeneralIds: string[],
  lang: Language
): string {
  const creators = selectedCreatorIds
    .map((id) => getCreatorById(id))
    .filter(Boolean)
    .map((c) => (lang === 'ar' ? c!.nameAr : c!.nameEn));

  const generals = selectedGeneralIds
    .map((id) => getGeneralStyleById(id))
    .filter(Boolean)
    .map((g) => (lang === 'ar' ? g!.nameAr : g!.nameEn));

  const all = [...creators, ...generals];
  if (all.length === 0) {
    return lang === 'ar' ? 'أسلوب استوديو يوتيوب احترافي متوازن' : 'Balanced Pro YouTube Studio Style';
  }
  return all.join(' + ');
}

export function analyzeIdeaLocally(
  inputs: IdeaInputs,
  selectedCreatorIds: string[],
  selectedGeneralIds: string[],
  lang: Language
): { analysis: IdeaAnalysis; concepts: VisualConcept[] } {
  const theme = detectIdeaTheme(inputs, selectedGeneralIds);
  const styleLabel = buildStyleSummaryLabel(selectedCreatorIds, selectedGeneralIds, lang);
  const titleClean = inputs.videoTitle.trim() || (lang === 'ar' ? 'الحلقة الجديدة' : 'New Episode');
  const ideaClean = inputs.ideaDescription.trim() || titleClean;
  const participants =
    inputs.participantsDescription.trim() ||
    (theme.isDuoOrGroup
      ? lang === 'ar'
        ? 'شخصان مشاركان في المواجهة أو التفاعل'
        : 'Two participants interacting on camera'
      : lang === 'ar'
      ? 'مقدم الفيديو الرئيسي'
      : 'Main video creator');
  const coreMsg = inputs.coreMessage.trim() || ideaClean;

  const creatorPalette =
    selectedCreatorIds.length > 0 ? getCreatorById(selectedCreatorIds[0]) : undefined;

  const isArabic = lang === 'ar';

  const analysis: IdeaAnalysis = {
    mostExcitingElement: isArabic
      ? theme.key === 'versus'
        ? `نقطة التصادم والتوتر بين ${participants} حول: "${titleClean}" وما إذا كانت الصداقة أو المعرفة ستصمد أمام الاختبار.`
        : `التحول المفاجئ في "${titleClean}" والنتيجة غير المتوقعة التي تبرز قلب القصة (${coreMsg.slice(0, 90)}).`
      : theme.key === 'versus'
      ? `The high-tension clash between ${participants} in "${titleClean}" testing who truly wins or knows the truth.`
      : `The dramatic turning point inside "${titleClean}" and the unexpected reveal behind ${coreMsg.slice(0, 90)}.`,
    attentionMoment: isArabic
      ? theme.key === 'versus'
        ? 'لحظة كشف الإجابة الخاطئة أو الصادمة بينما ينظر الطرف الآخر بعدم تصديق وسط التحدي.'
        : 'ثانية الذروة المباشرة التي يظهر فيها الأثر الفعلي للفكرة على تعبيرات الوجه ومحيط المشهد.'
      : theme.key === 'versus'
      ? 'The split-second reveal of an unexpected answer while the opponent reacts in disbelief.'
      : 'The peak climax moment where the core twist hits the face expression and visual prop simultaneously.',
    targetEmotions: isArabic
      ? theme.key === 'horror'
        ? 'الترقب الحذر، الفضول الجريء، وصدمة الخوف المشوق'
        : theme.key === 'education'
        ? 'الفضول المعرفي، الدهشة الذكية، والرغبة في معرفة الحقيقة'
        : 'الفضول الحاد، الحماس، الصدمة المرحة، والرغبة الفورية في النقر لمعرفة النتيجة'
      : theme.key === 'horror'
      ? 'Tense anticipation, bold curiosity, and chilling suspense'
      : theme.key === 'education'
      ? 'Intellectual curiosity, "wait really?" surprise, and urge to uncover the answer'
      : 'Sharp curiosity, energetic excitement, playful shock, and immediate click urge',
    viewerQuestion: isArabic
      ? theme.key === 'versus'
        ? `من سينتصر في "${titleClean}" ومن سيكشف السر أولاً؟`
        : `ما الذي حدث بالفعل في "${titleClean}" وكيف انتهت هذه اللحظة؟`
      : theme.key === 'versus'
      ? `Who actually comes out on top in "${titleClean}", and what went wrong?`
      : `What actually happened in "${titleClean}", and how does this twist end?`,
    bestVisualAngle: isArabic
      ? `تكوين يركز على ${participants} بتباين واضح مع ${styleLabel} بحيث تُفهم القصة في أقل من نصف ثانية حتى على شاشة الهاتف.`
      : `A razor-sharp 0.5-second readable layout centering ${participants} using ${styleLabel} contrast that pops even on small mobile screens.`,
    detectedCategory: isArabic ? theme.labelAr : theme.labelEn,
    analysisSource: 'local-architect',
  };

  const baseColorHint = creatorPalette
    ? isArabic
      ? creatorPalette.colorsAr
      : creatorPalette.colorsEn
    : isArabic
    ? 'أزرق كهربائي ونيون بنفسجي مع أصفر أو أحمر للتركيز'
    : 'Electric blue & violet neon contrasted with crisp yellow or crimson focus';

  const concepts: VisualConcept[] = [
    {
      id: 'concept-clash',
      name: isArabic ? 'المواجهة والانقسام الدرامي' : 'Dramatic Split Showdown',
      sceneDescription: isArabic
        ? `تقسيم المشهد إلى نصفين متقابلين يبرز التباين حول "${titleClean}" مع عنصر فاصل متوهج في المنتصف يربط بين ${participants}.`
        : `High-tension split-frame showdown illustrating "${titleClean}" with a glowing central divider bridging ${participants}.`,
      peoplePose: isArabic
        ? theme.isDuoOrGroup
          ? 'شخصان يميلان للخارج أو متقابلان في المقدمة بوضوح كامل مع حركة يد تشير نحو الحدث'
          : 'مقدم الفيديو في النصف الأيمن يلتفت بتحفّز ويشير بيده إلى العنصر المفاجئ في النصف الأيسر'
        : theme.isDuoOrGroup
        ? 'Two participants angled face-to-face in crisp foreground close-up with expressive pointing gestures'
        : 'Main creator leaning forward on the right third pointing intensely toward the surprise focal element on the left',
      facialExpressions: isArabic
        ? 'تباين حاد في التعابير: صدمة واسعة العينين مقابل نظرة واثقة أو ساخرة'
        : 'Contrasting emotions: wide-eyed disbelief vs confident teasing smirk',
      background: isArabic
        ? 'خلفية استوديو مقسمة بلونين متضادين مع عمق خفيف وتفاصيل مرتبطة بموضوع الحلقة'
        : 'Dual-tone split studio backdrop with subtle topic cues and shallow bokeh separation',
      extraElements: isArabic
        ? 'سهم توجيه متوهج + علامة استفهام أو أيقونة فائز/خاسر نظيفة في المنتصف'
        : 'Glowing directional arrow + crisp central question mark or score icon',
      colors: baseColorHint,
      lighting: isArabic
        ? 'إضاءة حافة قوية (Rim Light) بلونين متقابلين تفصل الوجوه تماماً عن الخلفية'
        : 'Dual-color rim lighting cleanly carving subjects out from the background',
      whyItFits: isArabic
        ? `يخلق توتراً بصرياً فورياً يجاوب على فكرة "${titleClean}" ويجبر المشاهد على التخمين قبل النقر.`
        : `Creates instant narrative tension tailored to "${titleClean}" that invites viewers to guess the outcome.`,
      inspiredBy: styleLabel,
      sceneTokensEn: `dramatic split-composition YouTube thumbnail concept representing "${titleClean}" featuring ${participants}`,
      poseTokensEn: theme.isDuoOrGroup
        ? 'two foreground subjects positioned on opposing halves leaning dynamically with expressive hand gestures'
        : 'foreground creator positioned on right third gesturing dramatically toward the opposite focal reveal',
      expressionTokensEn:
        'high-contrast dual emotion: wide-eyed shocked disbelief paired with confident knowing smirk',
      backgroundTokensEn:
        'clean split-colored studio backdrop with subtle thematic depth cues and crisp bokeh',
      colorTokensEn: creatorPalette
        ? creatorPalette.colorsEn
        : 'high-contrast electric blue against fiery crimson with warm gold accents',
      lightingTokensEn: 'sculpted opposing rim lights and sharp frontal key softbox illumination',
      elementsTokensEn: 'subtle glowing divider glow and crisp minimal focal icon',
    },
    {
      id: 'concept-shock-center',
      name: isArabic ? 'اللحظة الحاسمة في المنتصف' : 'Center Climax Reaction',
      sceneDescription: isArabic
        ? `لقطة قريبة مشبعة بالطاقة تضع العنصر المحوري لـ "${titleClean}" في بؤرة الاهتمام بينما تتوجه ردود الفعل حوله مباشرة.`
        : `High-energy close-up placing the core reveal of "${titleClean}" dead-center as reactions erupt directly around it.`,
      peoplePose: isArabic
        ? 'تواجد قريب جداً في المقدمة مع أيدٍ على الرأس أو تشير بقوة نحو العنصر المركزي'
        : 'Tight close-up framing with hands on head or pointing decisively at the center reveal',
      facialExpressions: isArabic
        ? 'دهشة قصوى وفم مفتوح مع تركيز حاد للعينين نحو الكاميرا أو الحدث'
        : 'Peak open-mouth astonishment with sharp intense eye focus',
      background: isArabic
        ? 'موقع حقيقي أو استوديو مشعّ بإضاءة عمق درامية تجعل المركز ينبض بالحياة'
        : 'Real-world location or dynamic glowing set radiating depth around the center prop',
      extraElements: isArabic
        ? 'دائرة تركيز مضيئة على العنصر المحوري + توهج خفيف حول الأطراف'
        : 'Crisp glowing highlight circle around the core prop + subtle edge flare',
      colors: isArabic
        ? 'أزرق سماوي مشعّ مع أصفر ساطع ولمسات برتقالية حارة'
        : 'Vibrant cyan blue paired with punchy yellow and warm orange accents',
      lighting: isArabic
        ? 'إضاءة استوديو ساطعة على الوجه مع أشعة خلفية (Backlight) لإبراز العمق'
        : 'Punchy studio beauty key light paired with dramatic backlighting beams',
      whyItFits: isArabic
        ? 'يحقق أعلى معدل وضوح على شاشات الموبايل الصغيرة لأن الوجه والعنصر المركزي يكبران جداً.'
        : 'Maximizes mobile readability with giant facial emotion locked straight onto one clear hero prop.',
      inspiredBy: styleLabel,
      sceneTokensEn: `hyper-clickable close-up reaction scene showcasing the central reveal of "${titleClean}"`,
      poseTokensEn: 'tight foreground portrait framing hands raised in shock toward a central hero prop',
      expressionTokensEn: 'explosive wide-eyed shock and intense comedic astonishment',
      backgroundTokensEn: 'cleanly blurred high-energy studio or location backdrop radiating depth rays',
      colorTokensEn: 'vibrant cyan, bright yellow highlights, and crisp dark slate contrast',
      lightingTokensEn: 'bright crisp frontal key light with dramatic volumetric radial backlight',
      elementsTokensEn: 'clean glowing focus highlight around hero prop with zero clutter',
    },
    {
      id: 'concept-cinematic-story',
      name: isArabic ? 'لقطة القصة السينمائية' : 'Cinematic Story Frame',
      sceneDescription: isArabic
        ? `تصوير واقعي فاخر يلتقط الجو العام لـ "${titleClean}" وكأنها بوستر فيلم حقيقي يحكي القصة بلا مبالغة مصطنعة.`
        : `Film-grade photorealistic frame capturing the authentic tension of "${titleClean}" like a high-budget movie still.`,
      peoplePose: isArabic
        ? 'وقفة واثقة أو تفاعل طبيعي داخل المشهد الواقعي مع عمق كاميرا سينمائي (35mm)'
        : 'Natural grounded posture inside the real scene captured on a 35mm cinema lens',
      facialExpressions: isArabic
        ? 'نظرة عميقة ذات معنى (تساؤل، ترقب، أو ابتسامة غامضة) تشعر المشاهد بالجدية'
        : 'Nuanced cinematic expression of quiet tension, determination, or subtle intrigue',
      background: isArabic
        ? 'بيئة حقيقية غنية بالتفاصيل الجوية (ضباب خفيف، إضاءة درامية، عمق ميدان عميق)'
        : 'Rich authentic environment with atmospheric depth, natural haze, and creamy cinema bokeh',
      extraElements: isArabic
        ? 'بدون رموز كرتونية — الاعتماد الكامل على لغة الصورة والإضاءة والبيئة'
        : 'Zero cartoonish stickers — pure visual storytelling through light, prop, and atmosphere',
      colors: isArabic
        ? 'تدرج تيل وبرتقالي سينمائي أو كحلي وذهبي دافئ'
        : 'Filmic teal & amber grading or deep navy & warm gold contrast',
      lighting: isArabic
        ? 'إضاءة ثلاثية الأبعاد واقعية تحاكي كاميرات السينما مع ظلال ناعمة متدرجة'
        : 'Sculpted theatrical film lighting with rich dynamic range and natural shadow falloff',
      whyItFits: isArabic
        ? 'يميز الفيديو عن الصور المقلّدة المزدحمة ويمنحه هيبة وثقة تجذب المشاهد الباحث عن الجودة.'
        : 'Stands out cleanly from noisy clickbait clutter with prestigious movie-poster credibility.',
      inspiredBy: styleLabel,
      sceneTokensEn: `cinematic 35mm movie-still YouTube thumbnail telling the story of "${titleClean}"`,
      poseTokensEn: 'natural grounded cinematic posture on rule-of-thirds inside real environment',
      expressionTokensEn: 'authentic dramatic nuance, focused gaze and genuine human emotion',
      backgroundTokensEn: 'rich atmospheric real-world environment with cinematic haze and deep bokeh',
      colorTokensEn: 'filmic teal and warm amber color grading with rich balanced blacks',
      lightingTokensEn: 'sculpted cinema key light, soft atmospheric rim separation, natural shadow roll-off',
      elementsTokensEn: 'zero cartoon icons, clean authentic narrative props only',
    },
    {
      id: 'concept-mystery-hook',
      name: isArabic ? 'فخ الفضول والعنصر المخفي' : 'Curiosity Hook & Hidden Clue',
      sceneDescription: isArabic
        ? `تصميم ذكي يخفي جزءاً من المفاجأة في "${titleClean}" خلف تظليل غامض أو صندوق/باب/شاشة، بينما تفضح تعابير الوجه حجم الصدمة.`
        : `Clever curiosity-gap framing concealing part of the twist behind "${titleClean}" in shadow or blur while facial reaction sells the secret.`,
      peoplePose: isArabic
        ? 'ميل للأمام نحو الكاميرا مع نظرة جانبية حذرة أو يد تشير إلى الشيء المخفي'
        : 'Leaning closer to the lens while gesturing toward a partially obscured mysterious object',
      facialExpressions: isArabic
        ? 'حاجب مرفوع بذهول، نظرة همس أو صدمة مكتومة تثير التساؤل فوراً'
        : 'Intrigued raised eyebrow and stunned knowing reaction sparking immediate curiosity',
      background: isArabic
        ? 'خلفية داكنة متدرجة تسلط بقعة ضوء مركّزة على العنصر الغامض والوجوه فقط'
        : 'Moody dark studio gradient throwing a single tight spotlight on the hidden clue and faces',
      extraElements: isArabic
        ? 'علامة استفهام أنيقة متوهجة أو طبقة تمويه/ظل خفيف فوق العنصر المجهول'
        : 'Sleek glowing question mark or subtle mystery silhouette tease over the hidden subject',
      colors: isArabic
        ? 'بنفسجي غامق، أزرق ليلي، ولمسة ضوء ذهبي أو أحمر تنبيهي'
        : 'Deep royal violet, midnight blue, and sharp gold or crimson spotlight highlight',
      lighting: isArabic
        ? 'إضاءة درامية مركّزة (Spotlight) مع حواف متوهجة خفيفة'
        : 'Tight dramatic spotlight illumination with crisp electric rim glow',
      whyItFits: isArabic
        ? 'يستغل فجوة الفضول النفسية بذكاء دون حرق مفاجأة الفيديو نفسها.'
        : 'Harnesses pure psychological curiosity gap without spoiling the video climax.',
      inspiredBy: styleLabel,
      sceneTokensEn: `high-curiosity mystery-hook thumbnail concealing the secret behind "${titleClean}"`,
      poseTokensEn: 'leaning slightly toward camera gesturing toward a mysterious shadowed silhouette or blurred object',
      expressionTokensEn: 'intrigued raised eyebrows and stunned conspiratorial shock',
      backgroundTokensEn: 'dark moody gradient environment lit by a single dramatic spotlight beam',
      colorTokensEn: 'deep midnight navy, royal violet shadows, and glowing gold spotlight accent',
      lightingTokensEn: 'tight dramatic overhead spotlight with crisp electric rim glow',
      elementsTokensEn: 'sleek glowing question mark over shadowed mystery reveal',
    },
  ];

  return { analysis, concepts };
}

export function buildAdaptiveWizardSteps(
  project: ArchitectProject,
  lang: Language,
  settings?: Pick<AppSettings, 'customTools' | 'toolOverrides'>
): WizardStepMeta[] {
  const concepts = project.concepts;
  const theme = detectIdeaTheme(project.ideaInputs, project.selectedGeneralIds);
  const personGroups = Array.from(
    new Map(
      project.referenceImages
        .filter((img) => img.role === 'person')
        .map((img) => [img.personGroupId, img.personLabel])
    ).entries()
  );
  const isMultiPerson = personGroups.length > 1 || theme.isDuoOrGroup;
  const titleHint = project.ideaInputs.videoTitle.trim() || (lang === 'ar' ? 'الفيديو' : 'the video');

  const conceptOptions: WizardOption[] = concepts.map((c, idx) => ({
    id: c.id,
    labelAr: `${idx + 1}. ${c.name}`,
    labelEn: `${idx + 1}. ${c.name}`,
    descAr: c.sceneDescription,
    descEn: c.sceneDescription,
    valueEn: c.sceneTokensEn,
  }));

  const suggestedHookTextAr =
    theme.key === 'versus'
      ? 'من الأذكى؟!'
      : theme.key === 'prank'
      ? 'انصدم!!'
      : theme.key === 'horror'
      ? 'لا تدخل!'
      : theme.key === 'mystery'
      ? 'السر المخفي'
      : 'مستحيل!!';

  const suggestedHookTextEn =
    theme.key === 'versus'
      ? 'WHO WINS?!'
      : theme.key === 'prank'
      ? 'NO WAY!!'
      : theme.key === 'horror'
      ? 'DON’T LOOK'
      : theme.key === 'mystery'
      ? 'THE SECRET'
      : 'INSANE!!';

  const toolsList = getAllGeneratorTools(settings);
  const generatorOptions: WizardOption[] = toolsList.map((tool) => ({
    id: tool.id,
    labelAr: tool.name,
    labelEn: tool.name,
    descAr: tool.shortDescAr,
    descEn: tool.shortDescEn,
    valueEn: tool.id,
  }));

  return [
    {
      id: 'concept',
      titleAr: 'اختيار التوجه البصري (الفكرة)',
      titleEn: 'Visual Concept Selection',
      questionAr: `أي فكرة بصرية تفضل أن نبني عليها الصورة المصغّرة لفيديو "${titleHint}"؟`,
      questionEn: `Which visual concept should drive the thumbnail for "${titleHint}"?`,
      options: conceptOptions,
    },
    {
      id: 'expressions',
      titleAr: 'تعابير الوجه والمشاعر',
      titleEn: 'Facial Expressions & Emotion',
      questionAr: isMultiPerson
        ? 'ما تعابير الوجه المطلوبة لكل شخص أو للمشهد بشكل عام؟'
        : 'ما التعبير الأقوى لوجه الشخص في الصورة المصغّرة؟',
      questionEn: isMultiPerson
        ? 'What facial expressions should appear overall or per person?'
        : 'What primary facial expression fits the thumbnail best?',
      supportsPerPerson: personGroups.length > 1,
      options: [
        {
          id: 'shocked-extreme',
          labelAr: 'صدمة قوية وعينان واسعتان',
          labelEn: 'Extreme Shock & Wide Eyes',
          descAr: 'الأفضل لجذب الانتباه الفوري في التحديات والمفاجآت',
          descEn: 'Best for instant mobile click appeal in surprises & challenges',
          valueEn: 'extreme wide-eyed shock, open-mouth astonishment, raised eyebrows',
        },
        {
          id: 'laughing-comedy',
          labelAr: 'ضحك هستيري / سخرية مرحة',
          labelEn: 'Hilarious Laugh / Sarcastic Grin',
          descAr: 'يعطي إحساساً خفيفاً وممتعاً فوراً',
          descEn: 'Signals fun comedic energy immediately',
          valueEn: 'contagious open laugh and playful sarcastic amusement',
        },
        {
          id: 'contrast-duo',
          labelAr: isMultiPerson ? 'تباين بين الشخصين (مصدوم vs واثق)' : 'تساؤل ذكي مع نظرة حادة',
          labelEn: isMultiPerson ? 'Contrasting Duo (Shocked vs Confident)' : 'Curious Raised Eyebrow & Sharp Gaze',
          descAr: 'يخلق قصة ومقارنة مباشرة داخل الصورة',
          descEn: 'Creates instant narrative tension in one frame',
          valueEn: isMultiPerson
            ? 'contrasting emotions: one person stunned and wide-eyed while the second smirks confidently'
            : 'skeptical raised eyebrow and sharp inquisitive gaze directly into lens',
        },
        {
          id: 'intense-serious',
          labelAr: 'توتر وحماس جاد / خوف درامي',
          labelEn: 'Intense Tension / Dramatic Focus',
          descAr: 'مثالي للغموض، الرعب، أو القصص العميقة',
          descEn: 'Ideal for mystery, horror, and serious storytelling',
          valueEn: 'intense dramatic focus, clenched jaw, high-tension expressive eyes',
        },
      ],
    },
    {
      id: 'pose',
      titleAr: 'وضعية الأشخاص والتكوين',
      titleEn: 'Subject Pose & Framing',
      questionAr: 'كيف تريد وقفة الأشخاص وتوزيعهم في الكادر؟',
      questionEn: 'How should the subject(s) be posed and framed in the shot?',
      options: [
        {
          id: 'closeup-dominant',
          labelAr: 'لقطة قريبة تملأ الكادر + إشارة باليد',
          labelEn: 'Bold Foreground Close-Up + Pointing',
          descAr: 'وضوح خارق للوجه على شاشة الهاتف',
          descEn: 'Maximum mobile readability and direct focal guidance',
          valueEn: 'tight expressive foreground close-up with hand pointing clearly toward the main focal element',
        },
        {
          id: 'side-by-side-duel',
          labelAr: isMultiPerson ? 'تواجه ثنائي (يمين مقابل يسار)' : 'نصف الجسم على الثلث الجانبي',
          labelEn: isMultiPerson ? 'Left vs Right Duel Framing' : 'Rule-of-Thirds Medium Shot',
          descAr: 'توزيع متوازن يترك مساحة لعنصر القصة',
          descEn: 'Balanced layout leaving room for the story centerpiece',
          valueEn: isMultiPerson
            ? 'two subjects framed symmetrically on opposing left and right thirds facing slightly inward'
            : 'medium upper-body framing on the rule-of-thirds side leaving space for key story element',
        },
        {
          id: 'hands-on-head',
          labelAr: 'أيدٍ على الرأس أو دهشة جسدية كاملة',
          labelEn: 'Hands on Head / Full Shock Posture',
          descAr: 'يعبّر عن كارثة مضحكة أو مفاجأة لا تُصدق',
          descEn: 'Visually communicates an unbelievable twist instantly',
          valueEn: 'upper-body shot with both hands gripping head or raised in dramatic disbelief',
        },
        {
          id: 'cinematic-natural',
          labelAr: 'وقفة طبيعية واقعية في المشهد',
          labelEn: 'Natural Grounded Cinematic Stance',
          descAr: 'بعيدة عن المبالغة الكرتونية، مناسبة للقصص والفلوقات',
          descEn: 'Authentic and grounded, great for vlogs and documentaries',
          valueEn: 'natural unforced cinematic posture integrated authentically into the environment',
        },
      ],
    },
    {
      id: 'background',
      titleAr: 'بيئة الخلفية والمكان',
      titleEn: 'Background & Environment',
      questionAr: 'ما الخلفية الأنسب التي تدعم الفكرة دون تشتيت الانتباه؟',
      questionEn: 'Which background best supports the story without distracting from the faces?',
      options: [
        {
          id: 'studio-dual-neon',
          labelAr: 'استوديو احترافي مقسوم بإضاءة نيون متباينة',
          labelEn: 'Pro Studio Split Neon Gradient',
          descAr: 'يعزل الوجوه تماماً ويجعل الصورة فائقة الوضوح',
          descEn: 'Isolates subjects cleanly with ultra-crisp separation',
          valueEn: 'sleek dark professional YouTube studio backdrop split with soft opposing neon glow and subtle bokeh',
        },
        {
          id: 'real-location-bokeh',
          labelAr: 'مكان حقيقي مرتبط بالقصة بضبابية سينمائية',
          labelEn: 'Story-Specific Real Location (Soft Bokeh)',
          descAr: 'منزل، شارع، أو موقع التصوير مع عزل عدسة احترافي',
          descEn: 'Real setting relevant to the video topic with shallow depth-of-field blur',
          valueEn: 'authentic real-world environment matching the video topic with creamy shallow depth-of-field separation',
        },
        {
          id: 'mystery-dark-spotlight',
          labelAr: 'خلفية غامضة داكنة مع بقعة ضوء مركّزة',
          labelEn: 'Moody Dark Spotlight Set',
          descAr: 'تبني الفضول والترقب في منتصف المشهد',
          descEn: 'Builds sharp curiosity and dramatic focal tension',
          valueEn: 'deep moody dark studio backdrop illuminated by one dramatic overhead spotlight beam',
        },
        {
          id: 'vibrant-action-set',
          labelAr: 'بيئة مشرقة مليئة بالطاقة والألوان',
          labelEn: 'Bright High-Energy Set / Daylight',
          descAr: 'تناسب التحديات الكبرى والفلوقات والمحتوى العائلي',
          descEn: 'Great for bright challenges, lifestyle vlogs, and family content',
          valueEn: 'bright immaculate sunlit set or vibrant colorful arena with crisp clarity',
        },
      ],
    },
    {
      id: 'colors',
      titleAr: 'لوحة الألوان والإضاءة',
      titleEn: 'Color Palette & Lighting',
      questionAr: 'ما التدرج اللوني الذي يجعل الصورة تنفجر وضوحاً على يوتيوب؟',
      questionEn: 'Which color palette & lighting tone should power the thumbnail?',
      options: [
        {
          id: 'electric-blue-crimson',
          labelAr: 'أزرق كهربائي + أحمر قرمزي (تباين قوي)',
          labelEn: 'Electric Blue + Crimson Contrast',
          valueEn: 'electric cobalt blue and punchy crimson red dual-tone contrast with crisp white highlights',
        },
        {
          id: 'violet-blue-studio',
          labelAr: 'بنفسجي ملكي + أزرق نيون + لمسة ذهبية',
          labelEn: 'Royal Violet + Neon Blue + Gold Accent',
          valueEn: 'rich royal violet and electric cyan-blue tones accented with crisp warm gold edge glow',
        },
        {
          id: 'teal-amber-cinema',
          labelAr: 'تيل سينمائي + برتقالي دافئ (هوليوودي)',
          labelEn: 'Cinematic Teal & Warm Amber',
          valueEn: 'blockbuster cinematic teal shadows balanced against warm golden-amber key light',
        },
        {
          id: 'bright-yellow-cyan',
          labelAr: 'أصفر ساطع + سماوي مشرق (أسلوب كوميدي/MrBeast)',
          labelEn: 'Bright Yellow + Saturated Sky Cyan',
          valueEn: 'hyper-saturated vibrant yellow and crisp sky-blue studio palette for maximum pop',
        },
      ],
    },
    {
      id: 'text',
      titleAr: 'النص داخل الصورة المصغّرة',
      titleEn: 'Thumbnail Text Decision',
      questionAr: 'هل تريد إضافة نص قصير داخل الصورة أم تفضّلها بدون نص تماماً؟',
      questionEn: 'Do you want short punchy text inside the thumbnail, or zero text?',
      options: [
        {
          id: 'no',
          labelAr: 'بدون أي نص (الاعتماد الكامل على الصورة)',
          labelEn: 'No Text At All (Pure Visual Impact)',
          descAr: 'موصى به غالباً لتفادي النصوص المشوّهة أو المكررة مع العنوان',
          descEn: 'Often best to avoid distorted AI text and keep visuals universal',
          valueEn: 'strictly ZERO text, no letters, no numbers, no logos anywhere in the image',
        },
        {
          id: 'suggest',
          labelAr: `اقترح لي نصاً قصيراً خاطفاً (مثل: "${suggestedHookTextAr}")`,
          labelEn: `Suggest a Short Hook Text (e.g. "${suggestedHookTextEn}")`,
          descAr: 'كلمتان أو ثلاث كلمات فقط بحجم خط ضخم',
          descEn: 'Maximum 2–3 bold words engineered for instant reading',
          valueEn: `bold ultra-readable 2-word hook text "${lang === 'ar' ? suggestedHookTextAr : suggestedHookTextEn}"`,
        },
        {
          id: 'yes',
          labelAr: 'نعم، سأكتب النص بنفسي (كلمتان – 4 كلمات)',
          labelEn: 'Yes, I Will Enter Custom Text (2–4 Words)',
          descAr: 'أدخل الكلمات الدقيقة التي تريد وضعها بالبرومبت',
          descEn: 'Type the exact short text to embed in the prompt',
          valueEn: 'custom short bold thumbnail headline text',
        },
      ],
    },
    {
      id: 'elements',
      titleAr: 'العناصر البصرية والملابس',
      titleEn: 'Visual Props & Clothing Note',
      questionAr: 'اختر العناصر الإضافية المناسبة (يمكنك اختيار أكثر من عنصر أو بدون عناصر):',
      questionEn: 'Select optional visual accents (choose one or more, or keep it clean):',
      allowMultiple: true,
      options: [
        {
          id: 'arrow',
          labelAr: 'سهم توجيه بارز',
          labelEn: 'Bold Directional Arrow',
          valueEn: 'one sleek glowing directional arrow pointing sharply at the focal detail',
        },
        {
          id: 'circle',
          labelAr: 'دائرة تركيز مضيئة',
          labelEn: 'Glowing Focus Circle',
          valueEn: 'crisp glowing highlight circle isolating the key detail',
        },
        {
          id: 'question-mark',
          labelAr: 'علامات استفهام للفضول',
          labelEn: 'Curiosity Question Mark',
          valueEn: 'stylized 3D glowing question mark heightening curiosity',
        },
        {
          id: 'emojis',
          labelAr: 'إيموجي تعبيري معزّز',
          labelEn: 'Expressive 3D Emoji Accent',
          valueEn: 'one subtle crisp 3D reaction emoji near the edge without blocking faces',
        },
        {
          id: 'props',
          labelAr: 'أدوات مرتبطة بموضوع الفيديو',
          labelEn: 'Story-Relevant Props',
          valueEn: 'tactile real-world props directly related to the video story held or visible in scene',
        },
        {
          id: 'vfx',
          labelAr: 'توهج وإضاءة طاقة خفيفة',
          labelEn: 'Light Sparks / Glow Effects',
          valueEn: 'subtle cinematic glow rim sparks and light flare accents',
        },
        {
          id: 'none',
          labelAr: 'بدون أي عناصر إضافية (تركيز كامل على الأشخاص)',
          labelEn: 'No Extra Graphic Elements (Clean Subjects)',
          valueEn: 'zero extra graphic overlays, clean uninterrupted photographic scene',
        },
      ],
    },
    {
      id: 'generator',
      titleAr: 'أداة التوليد وإعدادات الهوية',
      titleEn: 'Target Generator & Identity Protection',
      questionAr: 'اختر أداة توليد الصور الخارجية ومستوى حماية الهوية:',
      questionEn: 'Choose your external image generator and identity protection priority:',
      options: generatorOptions,
    },
  ];
}

export function synthesizePromptBundle(
  project: ArchitectProject,
  variationSeed: number,
  lang: Language,
  refinement?: RefinementModifier,
  settings?: Pick<
    AppSettings,
    'customTools' | 'toolOverrides' | 'googleFlowDefaults' | 'defaultIdentityMode' | 'promptTemplates'
  >
): GeneratedPromptBundle {
  return synthesizePromptForTool(
    project,
    project.wizardAnswers.targetGenerator || 'google-flow',
    variationSeed,
    lang,
    settings,
    refinement
  );
}

export function applyRefinementToProject(
  project: ArchitectProject,
  action: RefinementAction,
  lang: Language,
  settings?: Pick<
    AppSettings,
    'customTools' | 'toolOverrides' | 'googleFlowDefaults' | 'defaultIdentityMode' | 'promptTemplates'
  >
): ArchitectProject {
  const nextSeed = (project.promptResult?.variationSeed ?? 0) + 1;
  const nextAnswers = { ...project.wizardAnswers };
  let modifier: RefinementModifier | undefined;

  switch (action) {
    case 'variation':
      modifier = {
        action,
        extraPromptEn:
          'fresh camera angle variation with subtly re-staged foreground framing while preserving all core subjects and identities',
        extraArabicNote: 'تنويع زاوية الكاميرا وتوزيع العناصر مع الحفاظ على نفس الفكرة والهوية',
      };
      break;
    case 'professional':
      nextAnswers.backgroundChoice = 'studio-dual-neon';
      modifier = {
        action,
        extraPromptEn:
          'ultra-polished editorial studio quality, disciplined clean geometry, refined softbox grading, zero cheap clutter',
        extraArabicNote: 'رفع الاحترافية البصرية والإضاءة الاستوديوية الدقيقة وتقليل العشوائية',
      };
      break;
    case 'comedic':
      nextAnswers.expressionChoice = 'laughing-comedy';
      modifier = {
        action,
        extraPromptEn:
          'heightened comedic timing, humorous reaction energy, playful expressive eyebrows and cheerful vibrant punch without distorting facial structure',
        extraArabicNote: 'تعزيز الطابع الكوميدي والتعابير المضحكة الحيوية',
      };
      break;
    case 'stronger-expression':
      nextAnswers.expressionChoice = 'shocked-extreme';
      modifier = {
        action,
        extraPromptEn:
          'amplified facial emotion, expressive eyes and brows readable instantly even at small mobile thumbnail size',
        extraArabicNote: 'تضخيم قوة تعابير الوجه والعيون لتبرز بقوة على الموبايل',
      };
      break;
    case 'change-colors': {
      const cycle = [
        'electric-blue-crimson',
        'violet-blue-studio',
        'teal-amber-cinema',
        'bright-yellow-cyan',
      ];
      const idx = cycle.indexOf(nextAnswers.colorChoice);
      nextAnswers.colorChoice = cycle[(idx + 1) % cycle.length];
      modifier = {
        action,
        extraPromptEn: 'refreshed vibrant complementary color grading palette with sharp edge contrast',
        extraArabicNote: 'تغيير لوحة الألوان إلى تدرج متباين جديد',
      };
      break;
    }
    case 'change-background': {
      const bgCycle = [
        'studio-dual-neon',
        'real-location-bokeh',
        'mystery-dark-spotlight',
        'vibrant-action-set',
      ];
      const idx = bgCycle.indexOf(nextAnswers.backgroundChoice);
      nextAnswers.backgroundChoice = bgCycle[(idx + 1) % bgCycle.length];
      modifier = {
        action,
        extraPromptEn: 'reimagined background environment offering cleaner foreground separation',
        extraArabicNote: 'تغيير بيئة الخلفية لتحسين عزل الأشخاص والوضوح',
      };
      break;
    }
    case 'less-elements':
      nextAnswers.elementsSelected = ['none'];
      nextAnswers.customElementNote = '';
      modifier = {
        action,
        extraPromptEn:
          'minimalist high-impact decluttered layout removing secondary icons so 100% focus stays on faces and main reveal',
        extraArabicNote: 'إزالة العناصر الزائدة وحصر التركيز على الوجوه والحدث الرئيسي',
      };
      break;
    case 'more-excitement':
      modifier = {
        action,
        extraPromptEn:
          'amplified high-stakes urgency, dynamic forward tilt, dramatic backlighting beams, and electrifying climax intensity',
        extraArabicNote: 'زيادة التشويق والإضاءة الدرامية الحماسية للذروة',
      };
      break;
  }

  const updatedProject: ArchitectProject = {
    ...project,
    wizardAnswers: nextAnswers,
    customEditedPrompt: undefined,
    updatedAt: Date.now(),
  };

  updatedProject.promptResult = synthesizePromptBundle(
    updatedProject,
    nextSeed,
    lang,
    modifier,
    settings
  );

  return updatedProject;
}
