import type {
  AppSettings,
  ArchitectProject,
  GoogleFlowConfig,
  SavedPromptEntry,
} from '../types/architect';

const DB_NAME = 'thumbnail_prompt_architect_db';
const DB_VERSION = 1;
const PROJECTS_STORE = 'projects';
const PROMPTS_STORE = 'saved_prompts';
const SETTINGS_KEY = 'tpa_settings_v2';
const LEGACY_SETTINGS_KEY = 'tpa_settings_v1';

export const DEFAULT_FLOW_CONFIG: GoogleFlowConfig = {
  mode: 'image',
  modelChoice: 'auto-available',
  aspectRatio: '16:9',
  qualityLevel: 'high',
  compositionFocus: 'high-ctr',
  textSpace: 'clean-negative-space',
  realismLevel: 'photorealistic',
};

export const DEFAULT_FLOW_MODELS: string[] = [
  'auto-available',
  'Nano Banana Pro',
  'Nano Banana',
  'Imagen 4 (Flow Standard)',
];

export const DEFAULT_SETTINGS: AppSettings = {
  language: 'ar',
  defaultGenerator: 'google-flow',
  defaultIdentityMode: 'max-priority',
  googleFlowDefaults: DEFAULT_FLOW_CONFIG,
  flowModelsCatalog: DEFAULT_FLOW_MODELS,
  customTools: [],
  toolOverrides: {},
  promptTemplates: [],
  autoSaveEnabled: true,
  useOptionalServerAI: true,
  referenceMinResolution: 480,
};

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(PROJECTS_STORE)) {
        db.createObjectStore(PROJECTS_STORE, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(PROMPTS_STORE)) {
        db.createObjectStore(PROMPTS_STORE, { keyPath: 'id' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error('Failed to open IndexedDB'));
  });
}

export async function getAllProjects(): Promise<ArchitectProject[]> {
  try {
    const db = await openDb();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(PROJECTS_STORE, 'readonly');
      const store = tx.objectStore(PROJECTS_STORE);
      const req = store.getAll();
      req.onsuccess = () => {
        const list = (req.result as ArchitectProject[]) ?? [];
        list.sort((a, b) => b.updatedAt - a.updatedAt);
        resolve(list);
      };
      req.onerror = () => reject(req.error ?? new Error('Failed to load projects'));
    });
  } catch {
    return [];
  }
}

export async function saveProject(project: ArchitectProject): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(PROJECTS_STORE, 'readwrite');
    const store = tx.objectStore(PROJECTS_STORE);
    const req = store.put(project);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error ?? new Error('Failed to save project'));
  });
}

export async function deleteProjectById(id: string): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(PROJECTS_STORE, 'readwrite');
    const store = tx.objectStore(PROJECTS_STORE);
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error ?? new Error('Failed to delete project'));
  });
}

export async function getAllSavedPrompts(): Promise<SavedPromptEntry[]> {
  try {
    const db = await openDb();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(PROMPTS_STORE, 'readonly');
      const store = tx.objectStore(PROMPTS_STORE);
      const req = store.getAll();
      req.onsuccess = () => {
        const list = (req.result as SavedPromptEntry[]) ?? [];
        list.sort((a, b) => b.createdAt - a.createdAt);
        resolve(list);
      };
      req.onerror = () => reject(req.error ?? new Error('Failed to load saved prompts'));
    });
  } catch {
    return [];
  }
}

export async function savePromptEntry(entry: SavedPromptEntry): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(PROMPTS_STORE, 'readwrite');
    const store = tx.objectStore(PROMPTS_STORE);
    const req = store.put(entry);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error ?? new Error('Failed to save prompt'));
  });
}

export async function deleteSavedPromptById(id: string): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(PROMPTS_STORE, 'readwrite');
    const store = tx.objectStore(PROMPTS_STORE);
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error ?? new Error('Failed to delete prompt'));
  });
}

export async function clearAllStorageData(): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction([PROJECTS_STORE, PROMPTS_STORE], 'readwrite');
    tx.objectStore(PROJECTS_STORE).clear();
    tx.objectStore(PROMPTS_STORE).clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error('Failed to clear storage'));
  });
}

export function loadSettings(): AppSettings {
  try {
    const raw =
      localStorage.getItem(SETTINGS_KEY) || localStorage.getItem(LEGACY_SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<AppSettings>;
    return {
      ...DEFAULT_SETTINGS,
      ...parsed,
      googleFlowDefaults: {
        ...DEFAULT_FLOW_CONFIG,
        ...(parsed.googleFlowDefaults ?? {}),
      },
      flowModelsCatalog:
        Array.isArray(parsed.flowModelsCatalog) && parsed.flowModelsCatalog.length > 0
          ? parsed.flowModelsCatalog
          : DEFAULT_FLOW_MODELS,
      customTools: Array.isArray(parsed.customTools) ? parsed.customTools : [],
      toolOverrides: parsed.toolOverrides ?? {},
      promptTemplates: Array.isArray(parsed.promptTemplates) ? parsed.promptTemplates : [],
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // ignore quota errors
  }
}
