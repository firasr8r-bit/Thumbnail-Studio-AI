import type { ImageDiagnostics } from '../types/architect';

export interface OptimizedImageResult {
  dataUrl: string;
  mimeType: string;
  diagnostics: ImageDiagnostics;
}

function computeCanvasDiagnostics(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  originalWidth: number,
  originalHeight: number
): ImageDiagnostics {
  try {
    const sampleW = Math.min(width, 96);
    const sampleH = Math.min(height, 96);
    const imgData = ctx.getImageData(0, 0, sampleW, sampleH).data;

    let lumSum = 0;
    let edgeAccum = 0;
    const totalPixels = sampleW * sampleH;

    for (let y = 0; y < sampleH; y++) {
      for (let x = 0; x < sampleW; x++) {
        const idx = (y * sampleW + x) * 4;
        const lum = 0.299 * imgData[idx] + 0.587 * imgData[idx + 1] + 0.114 * imgData[idx + 2];
        lumSum += lum;

        if (x > 0 && y > 0) {
          const leftIdx = (y * sampleW + (x - 1)) * 4;
          const upIdx = ((y - 1) * sampleW + x) * 4;
          const lumLeft =
            0.299 * imgData[leftIdx] + 0.587 * imgData[leftIdx + 1] + 0.114 * imgData[leftIdx + 2];
          const lumUp =
            0.299 * imgData[upIdx] + 0.587 * imgData[upIdx + 1] + 0.114 * imgData[upIdx + 2];
          edgeAccum += Math.abs(lum - lumLeft) + Math.abs(lum - lumUp);
        }
      }
    }

    const avgBrightness = Math.round(lumSum / Math.max(1, totalPixels));
    const avgEdge = edgeAccum / Math.max(1, totalPixels);
    const sharpnessScore = Math.min(100, Math.round((avgEdge / 35) * 100));

    return {
      width: originalWidth,
      height: originalHeight,
      avgBrightness,
      sharpnessScore,
    };
  } catch {
    return {
      width: originalWidth,
      height: originalHeight,
      avgBrightness: 128,
      sharpnessScore: 60,
    };
  }
}

export async function fileToOptimizedDataUrl(
  file: File,
  maxDimension = 960
): Promise<OptimizedImageResult> {
  if (!file.type.startsWith('image/')) {
    throw new Error('Selected file is not a valid image');
  }

  const rawDataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to read image file'));
      }
    };
    reader.onerror = () => reject(reader.error ?? new Error('Image read error'));
    reader.readAsDataURL(file);
  });

  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('Failed to decode image'));
    image.src = rawDataUrl;
  });

  const scale = Math.min(1, maxDimension / Math.max(img.width, img.height, 1));
  const targetWidth = Math.max(1, Math.round(img.width * scale));
  const targetHeight = Math.max(1, Math.round(img.height * scale));

  const canvas = document.createElement('canvas');
  canvas.width = targetWidth;
  canvas.height = targetHeight;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    return {
      dataUrl: rawDataUrl,
      mimeType: file.type || 'image/jpeg',
      diagnostics: {
        width: img.width,
        height: img.height,
        avgBrightness: 128,
        sharpnessScore: 60,
      },
    };
  }

  ctx.drawImage(img, 0, 0, targetWidth, targetHeight);
  const diagnostics = computeCanvasDiagnostics(
    ctx,
    targetWidth,
    targetHeight,
    img.width,
    img.height
  );
  const outputMime = file.type === 'image/png' ? 'image/webp' : 'image/jpeg';
  const optimizedUrl = canvas.toDataURL(outputMime, 0.86);
  return {
    dataUrl: optimizedUrl,
    mimeType: outputMime,
    diagnostics,
  };
}
