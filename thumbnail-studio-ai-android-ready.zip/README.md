<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/855fdfae-ab3b-44c5-9191-d14b682ecc4b

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## Build Android APK (GitHub Actions)

This project is prepared for an Android wrapper using Capacitor 8.

### Build from a phone using GitHub

1. Upload the contents of this ZIP to a new GitHub repository (the workflow file must be at `.github/workflows/build-android-apk.yml`).
2. Open the repository's **Actions** tab.
3. Select **Build Android APK**.
4. Press **Run workflow** (or push to `main` / `master` to trigger a build).
5. When the run finishes successfully, open the run and download the artifact named `Thumbnail-Prompt-Architect-debug-apk`.
6. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. Allow installation from that source if Android asks.

### Build locally

Requirements: Node.js 22, Java 21, Android Studio and Android SDK.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

The debug APK is generated at `android/app/build/outputs/apk/debug/app-debug.apk`.

### Important notes

- The app's local projects and settings use IndexedDB / localStorage inside the app WebView. Browser data from the web preview is not automatically migrated into the installed APK.
- Uninstalling the Android app or clearing its storage may erase locally saved projects and reference images. Export/backup important work before doing so.
- The app's local prompt-building features work without a server or API key. The optional server-side AI analysis endpoint is not included in this static APK build; the app should fall back to its local prompt engine when that endpoint is unavailable.
- This workflow creates a **debug APK** for personal installation/testing, not a Play Store release.
